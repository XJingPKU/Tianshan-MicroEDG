# Analysis 1: Elevation pattern
# MPL
# 2025.12.18
# This script is to plot and fit the quadratic equation about the elevational 
# distribution of soil bacterial and fungal species richness 



###########################################################


# load library
library(dplyr)
library(tidyr)
library(purrr) # 用于分组操作
library(broom) # 用于整洁模型输出

library(ggplot2)
library(cowplot)

# load data
pattern_dat <- read.table("clipboard",header=T)#load result data


# data grouped by Datasets，standardized Diversity with z-score within study
pattern_dat1 <- pattern_dat %>%
  group_by(Dataset) %>%
  mutate(Elevation_s = scale(Elevation),
         ArticleID=factor(ArticleID)) %>%
  group_by(ArticleID, Microbe) %>%
  mutate(
    Diversity_s = scale(Diversity)
  ) %>%
  ungroup()

result <- pattern_dat1 %>%
  group_by(ArticleID, Microbe, Layer, Alpha) %>%
  summarise(
    n_obs = n(),
    .groups = "drop"
  ) %>%
  left_join(
    pattern_dat1 %>%
      group_by(ArticleID, Microbe, Layer, Alpha) %>%
      do({
        if (nrow(.) < 3) {
          return(data.frame(
            linearlope = NA,
            linear_pval = NA,
            quad_term = NA,
            quad_pval = NA,
            linear_aic = NA,
            quad_aic = NA
          ))
        }
        
        lm_linear <- lm(Diversity ~ Elevation, data = .)
        linearummary <- broom::tidy(lm_linear)
        linearlope <- linearummary$estimate[2]
        linear_pval <- linearummary$p.value[2]
        
        lm_quad <- lm(Diversity ~ Elevation + I(Elevation^2), data = .)
        quadummary <- broom::tidy(lm_quad)
        quad_term <- quadummary$estimate[3]
        quad_pval <- quadummary$p.value[3]
        
        # AIC
        linear_aic <- AIC(lm_linear)
        quad_aic <- AIC(lm_quad)
        
        data.frame(
          linearlope = linearlope,
          linear_pval = linear_pval,
          quad_term = quad_term,
          quad_pval = quad_pval,
          linear_aic = linear_aic,
          quad_aic = quad_aic
        )
      }),
    by = c("ArticleID", "Microbe", "Layer", "Alpha")
  ) %>%

  mutate(
    pattern = case_when(
      quad_pval < 0.05 & quad_term < 0 ~ "hump-shaped",
      quad_pval < 0.05 & quad_term > 0 ~ "U-shaped",
      linear_pval < 0.05 & linearlope < 0 ~ "Decrease",
      linear_pval < 0.05 & linearlope > 0 ~ "Increase",
      TRUE ~ "No pattern"
    )
  ) %>%

  select(
    ArticleID, Microbe, Layer, Alpha, n_obs, 
    linear_aic, quad_aic, linearlope, linear_pval, 
    quad_term, quad_pval,
    pattern  
  ) %>%
  arrange(ArticleID, Microbe, Layer, Alpha)


write.csv(
  result,
  "D:/Meta/Pattern_dataset_results.csv",
  row.names = FALSE
)

patternummary <- result %>%
  group_by(Microbe, Layer) %>%
  summarise(
    humphaped = sum(pattern == "hump-shaped", na.rm = TRUE),
    Uhaped = sum(pattern == "U-shaped", na.rm = TRUE),
    Decrease = sum(pattern == "Decrease", na.rm = TRUE),
    Increase = sum(pattern == "Increase", na.rm = TRUE),
    No_pattern = sum(pattern == "No pattern", na.rm = TRUE),
    .groups = "drop"
  ) %>%
  pivot_longer(
    cols = -c(Microbe, Layer),
    names_to = "pattern_type",
    values_to = "count"
  ) %>%
  mutate(pattern_type = str_remove(pattern_type, "_"))

print(patternummary,n=30)


#_______________________Chi-squared test_______________________________________
#Bacteria Surface
Bsur_data <- patternummary %>%
  filter(Microbe == "Bacteria", Layer == "Surface")
observed_counts <-Bsur_data$count
chisq.test(x = observed_counts)


#post-hoc tests
test_result_Bsur <- chisq.test(Bsur_data$count)
#  |residual| > 1.96 , p < 0.05
std_residuals_Bsur <- test_result_Bsur$stdres
print(std_residuals_Bsur)


# Bacteria Sub
Bsub_data <- patternummary %>%
  filter(Microbe == "Bacteria", Layer == "Sub")
chisq.test(Bsub_data$count)

test_result_Bsub <- chisq.test(Bsub_data$count)
std_residuals_Bsub <- test_result_Bsub$stdres
print(std_residuals_Bsub)

# Fungi Surface
Fsur_data <- patternummary %>%
  filter(Microbe == "Fungi", Layer == "Surface")
chisq.test(Fsur_data$count)

test_result_Fsur <- chisq.test(Fsur_data$count)
std_residuals_Fsur <- test_result_Fsur$stdres
print(std_residuals_Fsur)

# Fungi Sub
Fsub_data <- patternummary %>%
  filter(Microbe == "Fungi", Layer == "Sub")
chisq.test(Fsub_data$count)
test_result_Fsub <- chisq.test(Fsub_data$count)
std_residuals_Fsub <- test_result_Fsub$stdres
print(std_residuals_Fsub)


write.csv(
  chi_results,
  "D:/Meta/Chi_square_results.csv",
  row.names = FALSE
)

#________________________Plot pattern frequency______________________________________
ggplot(plot_data, aes(x = Microbe, y = Percent, fill = Pattern)) +
  geom_col_pattern(
    aes(pattern = pattern_type),
    pattern_fill = "black",
    pattern_angle = 45,
    pattern_density = 0.1,
    pattern_spacing = 0.025,
    pattern_key_scale_factor = 0.6
  ) +
  scale_fill_manual(values = color_mapping) +
  scale_pattern_manual(values = c("stripe", "stripe", "stripe", "stripe", "stripe")) +
  labs(title = "", x = "", y = "") +
  theme_minimal() +
  theme(
    axis.text.x = element_text(size = 14, face = "bold"),
    axis.text.y = element_blank(),
    axis.ticks = element_blank(),
    legend.position = "none"
  ) +
  geom_text(aes(label = paste0(Percent, "% (", Count, ")")), position = position_stack(vjust = 0.5), color = "white", size = 4) +
  coord_flip()

Signal_data <- read.table("clipboard",header=T)#load result data

pattern_colors <- c(
  "H" = "#55C4D2", # 
  "U" = "#984EA3", #
  "D" = "#E41A1C", #
  "I" = "#377EB8", # 
  "N" = "#FF7F00"  # 
)

#Plot
Signal_data <- Signal_data %>%
  mutate(Pattern = factor(Pattern, levels = names(pattern_colors)))

plot_list <- Signal_data %>% 
  split(.$Pattern) %>% # 
  lapply(function(data) {
    ggplot(data, aes(x = Elevation, y = Value)) +
      geom_line(color = pattern_colors[data$Pattern], linewidth = 1.0) +
      scale_x_continuous(breaks = c(-3, 11, 22)) +
      scale_y_continuous(breaks = c(0, 11, 22)) +
      labs(x = " ", y = NULL) +
      theme_bw(base_size = 11.5) +
      theme(panel.grid = element_blank(),
            plot.title = element_text(size = 12, hjust = 0.5),
            axis.text.x = element_blank(), # 
            axis.text.y = element_blank(), # 
            axis.ticks = element_blank(), # 
            axis.title.x.top = element_text(size = 14, face = "bold", margin = margin(b = 15) 
            ))+
      theme(axis.line = element_line(arrow = arrow(length = unit(0.2, "cm")),
                                     linewidth = 0.25)) 
  })

signal_plot <- wrap_plots(plot_list, ncol = 1) 
signal_plot

#plot results
PatternD_plot <- PatternD_dat %>%
  data.frame() %>%
  mutate(Percent = as.numeric(as.character(Percent))) %>%
  mutate(Layer = factor(Layer,
                        levels = c("Surface","Sub"),
                        labels = c("Surface","Subsurface"))) %>%
  mutate(Pattern = factor(Pattern,
                          levels = c("H","U","D","I","N"),
                          labels = c("H","U","D","I","N"))) %>%
  
  ggplot(aes(x = Layer, y = Percent, fill = Pattern)) +
  geom_bar(stat = "identity", position = position_stack(), alpha = 0.5, width = 1, 
           color = "white", linewidth =3.5) +
  
  # --- 关键步骤2: 自定义颜色，让间隔块不可见 ---
  scale_fill_manual(
    values = c(
      "H" = "#55C4D2",  #
      "U" = "#984EA3", #
      "D" = "#E41A1C", #
      "I" = "#377EB8", # 
      "N" = "#FF7F00"  # 
    ),
    name = "", guide = "none" # 
  ) +
  
  scale_y_continuous(lim = c(0, 100.12),
                     breaks = c(0, 50, 100),
                     expand = c(0, 0)) +
  labs(y = "", x = "") +
  theme_bw(base_size = 12.5) +
  theme(panel.grid = element_blank(),
        panel.background = element_blank(),
        panel.border = element_blank(),#
        strip.text = element_text(size = 12),
        strip.background = element_blank(),
        legend.position =  'none',
        axis.line = element_blank(),      
        axis.text.y = element_blank(),    
        axis.ticks = element_blank(),    
        axis.title.x = element_blank(), 
        axis.title.y = element_blank(),
        ) +
  geom_text(data = . %>% filter(!grepl("_spacer", Pattern) & Percent > 0),
            aes(label = paste0(round(Percent, 2), "% (", Count, ")")), 
            position = position_stack(vjust = 0.5), 
            color = "black", 
            size = 3.5) +
  facet_wrap(~ Microbe, ncol = 2)
PatternD_plot

plot_grid(signal_plot, PatternD_plot,
          labels = c("", ""),
          nrow = 1,
          rel_widths = c(1, 4),
          align = "h") 

ggsave("D:/Meta/Fig.3_Pattern frequency.pdf",
       width = 180, height = 165, units = "mm")