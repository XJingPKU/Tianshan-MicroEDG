# load library
library(tidyverse)
library(dplyr)
library(nlme)
library(glmm.hp)
library(Hmisc)
library(hilldiv)

library(ggplot2)
library(cowplot)
library(ggpmisc)
library(ggrepel)
library(RColorBrewer)#gradient color
library(scales)   # breaks_pretty

library(ggforce)#利用facetted_pos_scales()
# load data
# load data


#part I: The ecological factor
# Overview of ecological factors
dat_Factor <- read.table("clipboard",header=T)#load data
factors_data <- dat_Factor[, c("MAT", "MAP", "NPP", "ST", "pH", "EC", "SWC", "SOC", "lnP")]
#Table S2 Summary of ecological factors
factor_summary <- factors_data %>%
  summarise(
    across(
      .cols = everything(), 
      .fns = list(
        mean = ~mean(., na.rm = TRUE),
        sd = ~sd(., na.rm = TRUE),
        se = ~sd(.)/sqrt(n())  
      )
    )
  )

print(factor_summary)

#Table S3 Pearson correlation
cor_result <- rcorr(as.matrix(factors_data))
print(cor_result$r)
print(cor_result$P)

#Table S12 calculate quadratic regression for elevational distribution of factors
#All depths
dat_F <- read.table("clipboard",header=T)#load data
p_values_Factor1 <- dat_F %>%
  group_by(F) %>%
  do({
    fit <- lm(Factor ~ poly(Elevation/100, 2), data = .)
    summary_fit <- summary(fit)
    p_value <- summary_fit$coefficients["poly(Elevation/100, 2)2", "Pr(>|t|)"]
    r_squared <- summary_fit$r.squared
    coefficients <- coef(fit)
    data.frame(
      p_value = p_value,
      r_squared = r_squared,
      intercept = coefficients[1],         
      slope1 = coefficients[2],            
      slope2 = coefficients[3]            
    )
  })

write.csv(p_values_Factor1, "./Equ_values_Factor1.csv", row.names = TRUE)
# by soil depth

p_values_df <- dat_F %>%
  group_by(F,Depth) %>%
  do({
    fit <- lm(Factor ~ poly(Elevation/100, 2), data = .)
    p_value <- summary(fit)$coefficients["poly(Elevation/100, 2)2", "Pr(>|t|)"]
    data.frame(p_value = p_value)
  })

# Merge the original dataframe with the p-values
dat_F1 <- merge(dat_F, p_values_df, by = "F")

#_____________________pattern plot___________________________________
# Set breaks at specific percentiles of data range
percent_breaks <- function(percentages) {
  function(limits) {
    range <- limits[2] - limits[1]
    limits[1] + range * percentages
  }
}

# Figure S2 Factor patterns_All depths
p1 <- dat_F1 %>%
  mutate(F = factor(F,
                    levels = c("1MAT","2ST","3NPP","4SOC","5lnP","6EC","7pH","8SWC"),
                    labels = c("MAT (oC)","ST (oC)","NPP (kg C m-2)","SOC (g kg-1)","Plant species richness\n(in natural logarithm scale)","EC (μs cm-1)","pH","SWC (%)"))) %>%
  ggplot(aes(Elevation, Factor, linetype = "solid")) +
  geom_point(shape = 21, size = 1.2, alpha = .4) +
  geom_smooth(formula = 'y ~ x + I(x^2)',
              size = .4,
              method = "lm",
              color = "red",
              alpha = .6,
              se = TRUE) +
  stat_poly_eq(use_label(c("r2", "p")), size = 3, label.y = 0.9) +
  scale_x_continuous(lim = c(400, 3100), breaks = c(1000, 2000, 3000)) +
  scale_y_continuous(
    breaks = percent_breaks(c(0.15, 0.5, 0.85)),  
    labels = number_format(accuracy = 0.1),      
    expand = expansion(mult = c(0.10, 0.25))      
  ) +
  labs(x = "Elevation (m)",
       y = "",
       title = "") +
  theme_bw(base_size = 12.5) +
  theme(panel.grid = element_blank(),
        panel.background = element_blank(),
        axis.line = element_line(arrow = arrow(length = unit(0.2, "cm")),
                                 linewidth = 0.25),
        #panel.border = element_rect(fill = NA, color = "gray30"),
        panel.border = element_blank(),
        axis.line.x.top = element_blank(),    
        axis.line.y.right = element_blank(),  
        legend.position = "none",
      
        strip.text = element_text(size = 10, margin = margin(r = 0)),  
        strip.background = element_blank(),
        strip.placement = "outside",  
        
        axis.text.y = element_text(margin = margin(r = 3)),  
        axis.ticks.length = unit(0.15, "cm"),  
        
        plot.margin = margin(l = 10, r = 10, t = 20, b = 20)) +  
  facet_wrap(. ~ F, ncol = 4, scales = "free_y",
             strip.position = "left")

p1
ggsave("./supplement/Figure S2_Factor.pdf",
       width = 240, height = 165, units = "mm")


#Figure S3 Factor patterns_by soil depth
dat_Fdepth <- read.table("clipboard",header=T)#load result data
p2 <- dat_Fdepth %>%
  mutate(Depth = factor(Depth,
                        levels = c("D1", "D2", "D3", "D4"),
                        labels = c("0-5", "5-15", "15-30", "30-50")),
         F = factor(F,
                    levels = c("2ST","4SOC","5lnP","6EC","7pH","8SWC"),
                    labels = c("ST (oC)","SOC (g kg-1)","Plant","EC (μs cm-1)","pH","SWC (%)")),
         linetype = ifelse(p < 0.05, "solid", "dashed")) %>%
  ggplot(aes(Elevation, Factor)) +
  geom_smooth(formula = 'y ~ x + I(x^2)',
              size = 1,
              method = "lm",
              aes(color = Depth, linetype = linetype),
              alpha = .6,
              se = FALSE) +
  scale_color_manual(values = c("#7f2704", "#d94801", "#fd8d3c", "#fdd0a2")) +
  scale_linetype_identity() +
  scale_x_continuous(lim = c(400, 3100), breaks = c(1000, 2000, 3000)) +
  scale_y_continuous(
    breaks = percent_breaks(c(0.15, 0.5, 0.85)),  
    labels = number_format(accuracy = 0.1),      
    expand = expansion(mult = c(0.10, 0.25))      
  ) +
  labs(x = "Elevation (m)",
       y = "",
       title = "",
       color = "Soil depth (cm)",
       linetype = "Significance") +
  theme_bw(base_size = 12.5) +
  theme(panel.grid = element_blank(),
        panel.background = element_blank(),
        axis.line = element_line(arrow = arrow(length = unit(0.2, "cm")),
                                 linewidth = 0.25),
        panel.border = element_blank(),
        axis.line.x.top = element_blank(),    
        axis.line.y.right = element_blank(),  
        legend.position = c(0.9,0.75),
       
        strip.text = element_text(size = 10, margin = margin(r = 0)),  
        strip.background = element_blank(),
        strip.placement = "outside",  
       
        axis.text.y = element_text(margin = margin(r = 3)),  
        axis.ticks.length = unit(0.15, "cm"),  
        
        plot.margin = margin(l = 10, r = 10, t = 20, b = 20)) +  
  facet_wrap(. ~ F, ncol = 3, scales = "free_y",
             strip.position = "left")
p2
ggsave("./supplement/Figure S3_Factor_depth.pdf",
       width = 180, height = 165, units = "mm")

#____________________________Richness patterns____________
# richness patterns
dat <- read.table("clipboard",header=T)#load  data

bac_dat <- dat %>%filter(Microbe == "bacteria")
fun_dat <- dat %>%filter(Microbe == "fungi")

#Table S4 calculate AIC Values  of the linear regression models and the quadratic regression models for richness
#bacteria
bac_dat$Elevation.c <- bac_dat$Elevation/100
model1 <- lm(lnB ~ Elevation.c + I(Elevation.c^2), data = bac_dat[bac_dat$Depth == "Overall", ])
model2 <- lm(lnB ~ Elevation.c , data = bac_dat[bac_dat$Depth == "Overall", ])
AIC(model1)
AIC(model2)
summary(model1)

model1SD1 <- lm(lnB ~ Elevation.c + I(Elevation.c^2), data = bac_dat[bac_dat$Depth == "D1", ])
model2SD1 <- lm(lnB ~ Elevation.c , data = bac_dat[bac_dat$Depth == "D1", ])
AIC(model1SD1)
AIC(model2SD1)
summary(model1SD1)


model1SD2 <- lm(lnB ~ Elevation.c + I(Elevation.c^2), data = bac_dat[bac_dat$Depth == "D2", ])
model2SD2 <- lm(lnB ~ Elevation.c , data = bac_dat[bac_dat$Depth == "D2", ])
AIC(model2SD2)
AIC(model1SD2)
summary(model1SD2)

model1SD3 <- lm(lnB ~ Elevation.c + I(Elevation.c^2), data = bac_dat[bac_dat$Depth == "D3", ])
model2SD3 <- lm(lnB ~ Elevation.c , data = bac_dat[bac_dat$Depth == "D3", ])
AIC(model2SD3)
AIC(model1SD3)
summary(model1SD3)

model1SD4 <- lm(lnB ~ Elevation.c + I(Elevation.c^2), data = bac_dat[bac_dat$Depth == "D4", ])
model2SD4 <- lm(lnB ~ Elevation.c , data = bac_dat[bac_dat$Depth == "D4", ])
AIC(model2SD4)
AIC(model1SD4)
summary(model1SD4)

#fungi
fun_dat$Sdepth <- as.factor(fun_dat$Sdepth)
fun_dat$Elevation.c <- fun_dat$Elevation/100

Fmodel1 <- lm(lnB ~ Elevation.c + I(Elevation.c^2), data = fun_dat[fun_dat$Depth == "Overall", ])
Fmodel2 <- lm(lnB ~ Elevation.c , data = fun_dat[fun_dat$Depth == "Overall", ])
AIC(Fmodel1)
AIC(Fmodel2)
summary(Fmodel1)

Fmodel1SD1 <- lm(lnB ~ Elevation.c + I(Elevation.c^2), data = fun_dat[fun_dat$Depth == "D1", ])
Fmodel2SD1 <- lm(lnB ~ Elevation.c , data = fun_dat[fun_dat$Depth == "D1", ])
AIC(Fmodel1SD1)
AIC(Fmodel2SD1)
summary(Fmodel1SD1)

Fmodel1SD2 <- lm(lnB ~ Elevation.c + I(Elevation.c^2), data = fun_dat[fun_dat$Depth == "D2", ])
Fmodel2SD2 <- lm(lnB ~ Elevation.c , data = fun_dat[fun_dat$Depth == "D2", ])
AIC(Fmodel2SD2)
AIC(Fmodel1SD2)
summary(Fmodel1SD2)

Fmodel1SD3 <- lm(lnB ~ Elevation.c + I(Elevation.c^2), data = fun_dat[fun_dat$Depth == "D3", ])
Fmodel2SD3 <- lm(lnB ~ Elevation.c , data = fun_dat[fun_dat$Depth == "D3", ])
AIC(Fmodel2SD3)
AIC(Fmodel1SD3)
summary(Fmodel1SD3)

Fmodel1SD4 <- lm(lnB ~ Elevation.c + I(Elevation.c^2), data = fun_dat[fun_dat$Depth == "D4", ])
Fmodel2SD4 <- lm(lnB ~ Elevation.c , data = fun_dat[fun_dat$Depth == "D4", ])
AIC(Fmodel2SD4)
AIC(Fmodel1SD4)
summary(Fmodel1SD4)

# Table S5 calculate quadratic regression for elevational distribution of microbial richness
Equ_values_PtternDepth <- dat %>%
  group_by(Microbe,Depth) %>%
  do({
    fit <- lm(lnB ~ poly(Elevation/100, 2), data = .)
    summary_fit <- summary(fit)
    p_value <- summary_fit$coefficients["poly(Elevation/100, 2)2", "Pr(>|t|)"]
    r_squared <- summary_fit$r.squared
    coefficients <- coef(fit)
    # 创建一个数据框来保存结果
    data.frame(
      p_value = p_value,
      r_squared = r_squared,
      intercept = coefficients[1],         # 截距
      slope1 = coefficients[2],            # 一次项系数
      slope2 = coefficients[3]             # 二次项系数
    )
  })
write.csv(Equ_values_PtternDepth, "./supplement/Equ_values_PtternDepth.csv", row.names = TRUE)


#calculate hill number
#bacteria
bac_OTU <- read.table("clipboard",header=T)#load result data
fun_OTU <- read.table("clipboard",header=T)#load result data
q_values_specific <- seq(from = 0, to = 5, by = 1)

hill_bac_results <- div_profile(count = bac_OTU, qvalues = q_values_specific)
hill_bac_df <- as.data.frame(hill_bac_results)
hill_bac_df$q_value <- rownames(hill_bac_df)
bac_hilldiv_long <- hill_bac_df %>%
  pivot_longer(
    cols = -q_value,          
    names_to = "Sample_ID",   
    values_to = "hillnum"     
  )
write.csv(hill_bac_results, "./Bac_hilldiv.csv", 
          row.names = TRUE)
write.csv(bac_hilldiv_long, "./bac_hilldiv_long.csv", 
          row.names = TRUE)

#fungi
hill____results <- div_profile(count = fun_OTU, qvalues = q_values_specific)
hill____df <- as.data.frame(hill____results)
hill____df$q_value <- rownames(hill____df)
fun_hilldiv_long <- hill____df %>%
  pivot_longer(
    cols = -q_value,          
    names_to = "Sample_ID",   
    values_to = "hillnum"     
  )
write.csv(hill____results, "./fun_hilldiv.csv", 
          row.names = TRUE)
write.csv(fun_hilldiv_long, "./fun_hilldiv_long.csv", 
          row.names = TRUE)


#Table S6 calculate quadratic regression for elevational distribution of hill number
#bacteria
hilldivB_all <- read.table("clipboard",header=T)#load result data

hilldivB_all1 <- hilldivB_all %>%
  mutate(Elevation.c = Elevation / 100)
#_______________B0Over_______________________
modelB0Over<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
                 data = filter(hilldivB_all1, Depth == "Overall",Orderq == 0))
summary(modelB0Over)
aic_B0Over <- AIC(modelB0Over)
print(aic_B0Over)
#________________B1Over________________________
modelB1Over<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
                 data = filter(hilldivB_all1, Depth == "Overall",Orderq == 1))
summary(modelB1Over)
aic_B1Over <- AIC(modelB1Over)
print(aic_B1Over)

#_______________B2Over_______________________
modelB2Over<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
                 data = filter(hilldivB_all1, Depth == "Overall",Orderq == 2))
summary(modelB2Over)
aic_B2Over <- AIC(modelB2Over)
print(aic_B2Over)

#_______________B3Over_______________________
modelB3Over<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
                 data = filter(hilldivB_all1, Depth == "Overall",Orderq == 3))
summary(modelB3Over)
aic_B3Over <- AIC(modelB3Over)
print(aic_B3Over)
#_______________B4Over_______________________
modelB4Over<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
                 data = filter(hilldivB_all1, Depth == "Overall",Orderq == 4))
summary(modelB4Over)
aic_B4Over <- AIC(modelB4Over)
print(aic_B4Over)

#_______________B5Over_______________________
modelB5Over<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
                 data = filter(hilldivB_all1, Depth == "Overall",Orderq == 5))
summary(modelB5Over)
aic_B5Over <- AIC(modelB5Over)
print(aic_B5Over)

#_______________B0D1_______________________
modelB0D1<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivB_all1, Depth == "D1",Orderq == 0))
summary(modelB0D1)
aic_B0D1 <- AIC(modelB0D1)
print(aic_B0D1)
#________________B1D1________________________
modelB1D1<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivB_all1, Depth == "D1",Orderq == 1))
summary(modelB1D1)
aic_B1D1 <- AIC(modelB1D1)
print(aic_B1D1)

#_______________B2D1_______________________
modelB2D1<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivB_all1, Depth == "D1",Orderq == 2))
summary(modelB2D1)
aic_B2D1 <- AIC(modelB2D1)
print(aic_B2D1)

#_______________B3D1_______________________
modelB3D1<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivB_all1, Depth == "D1",Orderq == 3))
summary(modelB3D1)
aic_B3D1 <- AIC(modelB3D1)
print(aic_B3D1)
#_______________B4D1_______________________
modelB4D1<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivB_all1, Depth == "D1",Orderq == 4))
summary(modelB4D1)
aic_B4D1 <- AIC(modelB4D1)
print(aic_B4D1)

#_______________B5D1_______________________
modelB5D1<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivB_all1, Depth == "D1",Orderq == 5))
summary(modelB5D1)
aic_B5D1 <- AIC(modelB5D1)
print(aic_B5D1)

#_____________________D2____________________________________
#_______________B0D2_______________________
modelB0D2<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivB_all1, Depth == "D2",Orderq == 0))
summary(modelB0D2)
aic_B0D2 <- AIC(modelB0D2)
print(aic_B0D2)
#________________B1D2________________________
modelB1D2<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivB_all1, Depth == "D2",Orderq == 1))
summary(modelB1D2)
aic_B1D2 <- AIC(modelB1D2)
print(aic_B1D2)

#_______________B2D2_______________________
modelB2D2<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivB_all1, Depth == "D2",Orderq == 2))
summary(modelB2D2)
aic_B2D2 <- AIC(modelB2D2)
print(aic_B2D2)

#_______________B3D2_______________________
modelB3D2<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivB_all1, Depth == "D2",Orderq == 3))
summary(modelB3D2)
aic_B3D2 <- AIC(modelB3D2)
print(aic_B3D2)
#_______________B4D2_______________________
modelB4D2<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivB_all1, Depth == "D2",Orderq == 4))
summary(modelB4D2)
aic_B4D2 <- AIC(modelB4D2)
print(aic_B4D2)

#_______________B5D2_______________________
modelB5D2<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivB_all1, Depth == "D2",Orderq == 5))
summary(modelB5D2)
aic_B5D2 <- AIC(modelB5D2)
print(aic_B5D2)

#_____________________D3____________________________________
#_______________B0D3_______________________
modelB0D3<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivB_all1, Depth == "D3",Orderq == 0))
summary(modelB0D3)
aic_B0D3 <- AIC(modelB0D3)
print(aic_B0D3)
#________________B1D3________________________
modelB1D3<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivB_all1, Depth == "D3",Orderq == 1))
summary(modelB1D3)
aic_B1D3 <- AIC(modelB1D3)
print(aic_B1D3)

#_______________B2D3_______________________
modelB2D3<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivB_all1, Depth == "D3",Orderq == 2))
summary(modelB2D3)
aic_B2D3 <- AIC(modelB2D3)
print(aic_B2D3)

#_______________B3D3_______________________
modelB3D3<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivB_all1, Depth == "D3",Orderq == 3))
summary(modelB3D3)
aic_B3D3 <- AIC(modelB3D3)
print(aic_B3D3)
#_______________B4D3_______________________
modelB4D3<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivB_all1, Depth == "D3",Orderq == 4))
summary(modelB4D3)
aic_B4D3 <- AIC(modelB4D3)
print(aic_B4D3)

#_______________B5D3_______________________
modelB5D3<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivB_all1, Depth == "D3",Orderq == 5))
summary(modelB5D3)
aic_B5D3 <- AIC(modelB5D3)
print(aic_B5D3)
#_____________________D4____________________________________
#_______________B0D4_______________________
modelB0D4<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivB_all1, Depth == "D4",Orderq == 0))
summary(modelB0D4)
aic_B0D4 <- AIC(modelB0D4)
print(aic_B0D4)
#________________B1D4________________________
modelB1D4<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivB_all1, Depth == "D4",Orderq == 1))
summary(modelB1D4)
aic_B1D4 <- AIC(modelB1D4)
print(aic_B1D4)

#_______________B2D4_______________________
modelB2D4<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivB_all1, Depth == "D4",Orderq == 2))
summary(modelB2D4)
aic_B2D4 <- AIC(modelB2D4)
print(aic_B2D4)

#_______________B3D4_______________________
modelB3D4<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivB_all1, Depth == "D4",Orderq == 3))
summary(modelB3D4)
aic_B3D4 <- AIC(modelB3D4)
print(aic_B3D4)
#_______________B4D4_______________________
modelB4D4<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivB_all1, Depth == "D4",Orderq == 4))
summary(modelB4D4)
aic_B4D4 <- AIC(modelB4D4)
print(aic_B4D4)

#_______________B5D4_______________________
modelB5D4<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivB_all1, Depth == "D4",Orderq == 5))
summary(modelB5D4)
aic_B5D4 <- AIC(modelB5D4)
print(aic_B5D4)

#fungi
hilldivF_all <- read.table("clipboard",header=T)#load result data

hilldivF_all1 <- hilldivF_all %>%
  mutate(Elevation.c = Elevation / 100)
#_______________F0Over_______________________
modelF0Over<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
                 data = filter(hilldivF_all1, Depth == "Overall",Orderq == 0))
summary(modelF0Over)
aic_F0Over <- AIC(modelF0Over)
print(aic_F0Over)
#________________F1Over________________________
modelF1Over<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
                 data = filter(hilldivF_all1, Depth == "Overall",Orderq == 1))
summary(modelF1Over)
aic_F1Over <- AIC(modelF1Over)
print(aic_F1Over)

#_______________F2Over_______________________
modelF2Over<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
                 data = filter(hilldivF_all1, Depth == "Overall",Orderq == 2))
summary(modelF2Over)
aic_F2Over <- AIC(modelF2Over)
print(aic_F2Over)

#_______________F3Over_______________________
modelF3Over<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
                 data = filter(hilldivF_all1, Depth == "Overall",Orderq == 3))
summary(modelF3Over)
aic_F3Over <- AIC(modelF3Over)
print(aic_F3Over)
#_______________F4Over_______________________
modelF4Over<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
                 data = filter(hilldivF_all1, Depth == "Overall",Orderq == 4))
summary(modelF4Over)
aic_F4Over <- AIC(modelF4Over)
print(aic_F4Over)

#_______________F5Over_______________________
modelF5Over<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
                 data = filter(hilldivF_all1, Depth == "Overall",Orderq == 5))
summary(modelF5Over)
aic_F5Over <- AIC(modelF5Over)
print(aic_F5Over)

#_______________F0D1_______________________
modelF0D1<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivF_all1, Depth == "D1",Orderq == 0))
summary(modelF0D1)
aic_F0D1 <- AIC(modelF0D1)
print(aic_F0D1)
#________________F1D1________________________
modelF1D1<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivF_all1, Depth == "D1",Orderq == 1))
summary(modelF1D1)
aic_F1D1 <- AIC(modelF1D1)
print(aic_F1D1)

#_______________F2D1_______________________
modelF2D1<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivF_all1, Depth == "D1",Orderq == 2))
summary(modelF2D1)
aic_F2D1 <- AIC(modelF2D1)
print(aic_F2D1)

#_______________F3D1_______________________
modelF3D1<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivF_all1, Depth == "D1",Orderq == 3))
summary(modelF3D1)
aic_F3D1 <- AIC(modelF3D1)
print(aic_F3D1)
#_______________F4D1_______________________
modelF4D1<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivF_all1, Depth == "D1",Orderq == 4))
summary(modelF4D1)
aic_F4D1 <- AIC(modelF4D1)
print(aic_F4D1)

#_______________F5D1_______________________
modelF5D1<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivF_all1, Depth == "D1",Orderq == 5))
summary(modelF5D1)
aic_F5D1 <- AIC(modelF5D1)
print(aic_F5D1)

#_____________________D2____________________________________
#_______________F0D2_______________________
modelF0D2<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivF_all1, Depth == "D2",Orderq == 0))
summary(modelF0D2)
aic_F0D2 <- AIC(modelF0D2)
print(aic_F0D2)
#________________F1D2________________________
modelF1D2<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivF_all1, Depth == "D2",Orderq == 1))
summary(modelF1D2)
aic_F1D2 <- AIC(modelF1D2)
print(aic_F1D2)

#_______________F2D2_______________________
modelF2D2<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivF_all1, Depth == "D2",Orderq == 2))
summary(modelF2D2)
aic_F2D2 <- AIC(modelF2D2)
print(aic_F2D2)

#_______________F3D2_______________________
modelF3D2<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivF_all1, Depth == "D2",Orderq == 3))
summary(modelF3D2)
aic_F3D2 <- AIC(modelF3D2)
print(aic_F3D2)
#_______________F4D2_______________________
modelF4D2<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivF_all1, Depth == "D2",Orderq == 4))
summary(modelF4D2)
aic_F4D2 <- AIC(modelF4D2)
print(aic_F4D2)

#_______________F5D2_______________________
modelF5D2<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivF_all1, Depth == "D2",Orderq == 5))
summary(modelF5D2)
aic_F5D2 <- AIC(modelF5D2)
print(aic_F5D2)

#_____________________D3____________________________________
#_______________F0D3_______________________
modelF0D3<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivF_all1, Depth == "D3",Orderq == 0))
summary(modelF0D3)
aic_F0D3 <- AIC(modelF0D3)
print(aic_F0D3)
#________________F1D3________________________
modelF1D3<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivF_all1, Depth == "D3",Orderq == 1))
summary(modelF1D3)
aic_F1D3 <- AIC(modelF1D3)
print(aic_F1D3)

#_______________F2D3_______________________
modelF2D3<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivF_all1, Depth == "D3",Orderq == 2))
summary(modelF2D3)
aic_F2D3 <- AIC(modelF2D3)
print(aic_F2D3)

#_______________F3D3_______________________
modelF3D3<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivF_all1, Depth == "D3",Orderq == 3))
summary(modelF3D3)
aic_F3D3 <- AIC(modelF3D3)
print(aic_F3D3)
#_______________F4D3_______________________
modelF4D3<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivF_all1, Depth == "D3",Orderq == 4))
summary(modelF4D3)
aic_F4D3 <- AIC(modelF4D3)
print(aic_F4D3)

#_______________F5D3_______________________
modelF5D3<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivF_all1, Depth == "D3",Orderq == 5))
summary(modelF5D3)
aic_F5D3 <- AIC(modelF5D3)
print(aic_F5D3)
#_____________________D4____________________________________
#_______________F0D4_______________________
modelF0D4<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivF_all1, Depth == "D4",Orderq == 0))
summary(modelF0D4)
aic_F0D4 <- AIC(modelF0D4)
print(aic_F0D4)
#________________F1D4________________________
modelF1D4<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivF_all1, Depth == "D4",Orderq == 1))
summary(modelF1D4)
aic_F1D4 <- AIC(modelF1D4)
print(aic_F1D4)

#_______________F2D4_______________________
modelF2D4<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivF_all1, Depth == "D4",Orderq == 2))
summary(modelF2D4)
aic_F2D4 <- AIC(modelF2D4)
print(aic_F2D4)

#_______________F3D4_______________________
modelF3D4<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivF_all1, Depth == "D4",Orderq == 3))
summary(modelF3D4)
aic_F3D4 <- AIC(modelF3D4)
print(aic_F3D4)
#_______________F4D4_______________________
modelF4D4<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivF_all1, Depth == "D4",Orderq == 4))
summary(modelF4D4)
aic_F4D4 <- AIC(modelF4D4)
print(aic_F4D4)

#_______________F5D4_______________________
modelF5D4<- lm(lnHill ~ Elevation.c + I(Elevation.c^2), 
               data = filter(hilldivF_all1, Depth == "D4",Orderq == 5))
summary(modelF5D4)
aic_F5D4 <- AIC(modelF5D4)
print(aic_F5D4)

#Figure S4 plot elevational patterns of hill number
p_hill <- dat_hill %>%
  mutate(Depth = factor(Depth,
                        levels = c("Overall","D1", "D2", "D3", "D4"),
                        labels = c("All depth","0-5", "5-15", "15-30", "30-50")),
         Orderq = factor(Orderq,
                    levels = c("0","1","2","3","4","5"),
                    labels = c("Order q = 0","Order q = 1","Order q = 2","Order q = 3","Order q = 4","Order q = 5")),
         linetype = ifelse(p < 0.05, "solid", "dashed")) %>%
  ggplot(aes(Elevation, lnHill)) +
  geom_smooth(formula = 'y ~ x + I(x^2)',
              size = 0.5,
              method = "lm",
              aes(color = Depth, linetype = linetype),
              alpha = .6,
              se = FALSE) +
  scale_color_manual(values = c("black","#7f2704", "#d94801", "#fd8d3c", "#fdd0a2")) +
  scale_linetype_identity() +
  scale_x_continuous(lim = c(400, 3100), breaks = c(1000, 2000, 3000)) +
  scale_y_continuous(
    breaks = percent_breaks(c(0.15, 0.5, 0.85)),  # 15%、50%、85%位置
    labels = number_format(accuracy = 0.1),      # 保留1位小数
    expand = expansion(mult = c(0.10, 0.25))      # 上下各添加20%的空间
  ) +
  labs(x = "Elevation (m)",
       y = "Hill number\n(in natural logarithm scale)",
       title = "",
       color = "Soil depth (cm)",
       linetype = "Significance") +
  theme_bw(base_size = 12.5) +
  theme(panel.grid = element_blank(),
        panel.background = element_blank(),
        axis.line = element_line(arrow = arrow(length = unit(0.2, "cm")),
                                 linewidth = 0.25),
        panel.border = element_blank(),
        axis.line.x.top = element_blank(),    # 移除上边框
        axis.line.y.right = element_blank(),  # 移除右边框
        legend.position = c(1.30,0.5),
        # 调整分面标签
        strip.text = element_text(size = 10, margin = margin(r = 0)),  # 右侧留出8pt空间
        strip.background = element_blank(),
        strip.placement = "outside",  # 标签放在面板外侧
        # 调整Y轴
        #axis.text.y = element_text(margin = margin(r = 3)),  # Y轴标签右侧留出5pt空间
        strip.text.y.right = element_text(angle = 0, hjust = 0, size = 10),  # 右侧标签水平放置
        axis.ticks.length = unit(0.15, "cm"),  # 调整刻度线长度
        # 调整整体布局
        plot.margin = margin(l = 10, r = 100, t = 5, b = 10)) +  # 上(t)和下(b)减少到5
  facet_grid(Orderq ~ Micro, scales = "free_y", 
             switch = "y")  # 使用facet_grid并将标签放在右侧
p_hill
ggsave("./supplement/Figure S4_hill number1.pdf",
       width = 140, height = 180, units = "mm")

#_______________ecological hypothesis/mechanisms______________________________________
#Table S7 Table S7.Depth-dependent comparison of the variance of microbial elevational 
#diversity explained by environmental filtering factors
Marginal_dat <- read.table("clipboard",header=T)#load result data
tukey_depth_Marginal <- Marginal_dat %>%
                          group_by(Micro) %>%                     
  do(tukey = try(TukeyHSD(aov(MarginalR ~ Depth, data = .))))
print(tukey_depth_Marginal)


#calculate marginal R2 with bootstrap
##_____________________Single theory to mutiple theory_marginal R2________________
##______________________bacteria___________________
dat <- read.table("clipboard",header=T)#load  data

bac_dat <- dat %>%filter(Microbe == "bacteria")
fun_dat <- dat %>%filter(Microbe == "fungi")
#all depths
bacOver_dat1<- filter(bac_dat, Depth == "Overall")
bacOver_dat1 <-bacOver_dat1 %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAP = scale(MAP),
        MAT = scale(MAT),
       AET = scale(AET),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP) )

#*_________________Soil_________________
bac_Soil_Over <- lme(lnB ~ pH+ EC + SWC,
                   random = (~1|Elevation/Replicate),
                   data = bacOver_dat1)

r.squared.marginal_BOver <- r.squaredGLMM(bac_Soil_Over)
r.squared.marginal_BOver
r_squared_boot_BOver_Soil <- function(data, indices) {
  
  data_boot_BOver_Soil <- data[indices, ]
  
  model_boot_BOver_Soil <- update(bac_Soil_Over, data = data_boot_BOver_Soil)
  
  r.squared.marginal <- r.squaredGLMM(model_boot_BOver_Soil)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_BOver_Soil <- boot(data = bacOver_dat1, statistic = r_squared_boot_BOver_Soil, R = nboots)

boot_BOver_Soil <- boot_results_BOver_Soil$t
lme_BOver_Soil <- as.data.frame(boot_BOver_Soil)


savepath <- "./bootstrip"
filename <- "lme_BOver_1Soil.csv"
write.csv(lme_BOver_Soil, file = paste0(savepath, "/", filename), row.names = TRUE)
glmm.hp(bac_Soil_Over)

#*_________________Energy_________________
bac_En_Over <- lme(lnB ~MAT  + NPP + SOC + ST,
                 random = (~1|Elevation/Replicate),
                 data = bacOver_dat1)

r.squared.marginal_BOver <- r.squaredGLMM(bac_En_Over)
r_squared_boot_BOver_En <- function(data, indices) {
  
  data_boot_BOver_En <- data[indices, ]
  
  model_boot_BOver_En <- update(bac_En_Over, data = data_boot_BOver_En)
  
  r.squared.marginal <- r.squaredGLMM(model_boot_BOver_En)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_BOver_En <- boot(data = bacOver_dat1, statistic = r_squared_boot_BOver_En, R = nboots)

boot_BOver_En <- boot_results_BOver_En$t
lme_BOver_En <- as.data.frame(boot_BOver_En)


savepath <- "./bootstrip"
filename <- "lme_BOver_2En.csv"
write.csv(lme_BOver_En, file = paste0(savepath, "/", filename), row.names = TRUE)

#*_________________Plant_________________
bac_Pl_Over <- lm(lnB ~ lnP,
                random = (~1|Elevation/Replicate),
                data = bacOver_dat1)

r.squared.marginal_BOver <- r.squaredGLMM(bac_Pl_Over)
r.squared.marginal_BOver
r_squared_boot_BOver_Pl <- function(data, indices) {
  
  data_boot_BOver_Pl <- data[indices, ]
  
  model_boot_BOver_Pl <- update(bac_Pl_Over, data = data_boot_BOver_Pl)
  
  r.squared.marginal <- r.squaredGLMM(model_boot_BOver_Pl)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_BOver_Pl <- boot(data = bacOver_dat1, statistic = r_squared_boot_BOver_Pl, R = nboots)

boot_BOver_Pl <- boot_results_BOver_Pl$t
lme_BOver_Pl <- as.data.frame(boot_BOver_Pl)


savepath <- "./bootstrip"
filename <- "lme_BOver_3Pl.csv"
write.csv(lme_BOver_Pl, file = paste0(savepath, "/", filename), row.names = TRUE)

glmm.hp(bac_Pl_Over)


#*_________________Boot Plant+Soil_________________
bac_SoilPl_Over <- lmer(lnB ~ EC+pH+SWC + lnP + (1|Replicate), data = bacOver_dat1)
glmm.hp(bac_SoilPl_Over)

r.squared.marginal <- r.squaredGLMM(bac_SoilPl_Over)
r.squared.marginal
r_squared_boot_SoilPl <- function(data, indices) {
  
  data_boot <- data[indices, ]
  
  model_boot <- update(bac_SoilPl_Over, data = data_boot)
  
  r.squared.marginal <- r.squaredGLMM(model_boot)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_BacOver_SoilPl <- boot(data = bacOver_dat1, statistic = r_squared_boot_SoilPl, R = nboots)

boot_bacOver_SoilPl <-boot_results_BacOver_SoilPl$t
lme_bacOver_SoilPl <- as.data.frame(boot_bacOver_SoilPl)


savepath <- "./bootstrip"
filename <- "lme1_bacOver_SoilPl.csv"
write.csv(lme_bacOver_SoilPl, file = paste0(savepath, "/", filename), row.names = TRUE)
#all factors
bac_All_Over <- lme(lnB ~ MAT + NPP + SOC + pH 
               + EC + ST + SWC +lnP,
               random = (~1|Elevation/Replicate),
               data = bacOver_dat1)
glmm.hp(bac_All_Over)
r.squared.marginal <- r.squaredGLMM(bac_All_Over)
r.squared.marginal

#residuals 
resi_bac_Soil_Over <- resid(bac_Soil_Over, type="response",newdata = bacOver_dat1)
resi_bac_En_Over <- resid(bac_En_Over, type="response",newdata = bacOver_dat1)
resi_bac_Pl_Over <- resid(bac_Pl_Over, type="response",newdata = bacOver_dat1)
resi_bac_SoilPl_Over <- resid(bac_SoilPl_Over, type="response",newdata = bacOver_dat1)
resi_bac_All_Over <- resid(bac_All_Over, type="response",newdata = bacOver_dat1)

resi_bac_Soil_Over
resi_bac_En_Over
resi_bac_Pl_Over
resi_bac_SoilPl_Over
resi_bac_All_Over
##______________________bac D1___________________
bacD1_dat1<- filter(bac_dat, Depth == "D1")
bacD1_dat1 <-bacD1_dat1 %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAP = scale(MAP),
         MAT = scale(MAT),
         AET = scale(AET),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP) )

#*_________________Soil_________________
bac_Soil_D1 <- lme(lnB ~ pH+ EC + SWC,
                     random = (~1|Replicate),
                     data = bacD1_dat1)

r.squared.marginal_BD1 <- r.squaredGLMM(bac_Soil_D1)
r.squared.marginal_BD1
r_squared_boot_BD1_Soil <- function(data, indices) {
  
  data_boot_BD1_Soil <- data[indices, ]
  
  model_boot_BD1_Soil <- update(bac_Soil_D1, data = data_boot_BD1_Soil)
  
  r.squared.marginal <- r.squaredGLMM(model_boot_BD1_Soil)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_BD1_Soil <- boot(data = bacD1_dat1, statistic = r_squared_boot_BD1_Soil, R = nboots)

boot_BD1_Soil <- boot_results_BD1_Soil$t
lme_BD1_Soil <- as.data.frame(boot_BD1_Soil)


savepath <- "./bootstrip"
filename <- "lme_BD1_1Soil.csv"
write.csv(lme_BD1_Soil, file = paste0(savepath, "/", filename), row.names = TRUE)
glmm.hp(bac_Soil_D1)

#*_________________Energy_________________
bac_En_D1 <- lme(lnB ~MAT  + NPP + SOC + ST,
                   random = (~1|Replicate),
                   data = bacD1_dat1)

r.squared.marginal_BD1 <- r.squaredGLMM(bac_En_D1)
r_squared_boot_BD1_En <- function(data, indices) {
  
  data_boot_BD1_En <- data[indices, ]
  
  model_boot_BD1_En <- update(bac_En_D1, data = data_boot_BD1_En)
  
  r.squared.marginal <- r.squaredGLMM(model_boot_BD1_En)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_BD1_En <- boot(data = bacD1_dat1, statistic = r_squared_boot_BD1_En, R = nboots)

boot_BD1_En <- boot_results_BD1_En$t
lme_BD1_En <- as.data.frame(boot_BD1_En)


savepath <- "./bootstrip"
filename <- "lme_BD1_2En.csv"
write.csv(lme_BD1_En, file = paste0(savepath, "/", filename), row.names = TRUE)

#*_________________Plant_________________
bac_Pl_D1 <- lm(lnB ~ lnP,
                  random = (~1|Replicate),
                  data = bacD1_dat1)

r.squared.marginal_BD1 <- r.squaredGLMM(bac_Pl_D1)
r.squared.marginal_BD1
r_squared_boot_BD1_Pl <- function(data, indices) {
  
  data_boot_BD1_Pl <- data[indices, ]
  
  model_boot_BD1_Pl <- update(bac_Pl_D1, data = data_boot_BD1_Pl)
  
  r.squared.marginal <- r.squaredGLMM(model_boot_BD1_Pl)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_BD1_Pl <- boot(data = bacD1_dat1, statistic = r_squared_boot_BD1_Pl, R = nboots)

boot_BD1_Pl <- boot_results_BD1_Pl$t
lme_BD1_Pl <- as.data.frame(boot_BD1_Pl)


savepath <- "./bootstrip"
filename <- "lme_BD1_3Pl.csv"
write.csv(lme_BD1_Pl, file = paste0(savepath, "/", filename), row.names = TRUE)

glmm.hp(bac_Pl_D1)


#*_________________Boot Plant+Soil_________________
bac_SoilPl_D1 <- lmer(lnB ~ EC+pH+SWC + lnP + (1|Replicate), data = bacD1_dat1)
glmm.hp(bac_SoilPl_D1)

r.squared.marginal <- r.squaredGLMM(bac_SoilPl_D1)
r.squared.marginal
r_squared_boot_SoilPl <- function(data, indices) {
  
  data_boot <- data[indices, ]
  
  model_boot <- update(bac_SoilPl_D1, data = data_boot)
  
  r.squared.marginal <- r.squaredGLMM(model_boot)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_BacD1_SoilPl <- boot(data = bacD1_dat1, statistic = r_squared_boot_SoilPl, R = nboots)

boot_bacD1_SoilPl <-boot_results_BacD1_SoilPl$t
lme_bacD1_SoilPl <- as.data.frame(boot_bacD1_SoilPl)


savepath <- "./bootstrip"
filename <- "lme1_bacD1_SoilPl.csv"
write.csv(lme_bacD1_SoilPl, file = paste0(savepath, "/", filename), row.names = TRUE)
#all factors
bac_All_D1 <- lme(lnB ~ MAT + NPP + SOC + pH 
                    + EC + ST + SWC +lnP,
                    random = (~1|Replicate),
                    data = bacD1_dat1)
glmm.hp(bac_All_D1)
r.squared.marginal <- r.squaredGLMM(bac_All_D1)
r.squared.marginal

#residuals 
resi_bac_Soil_D1 <- resid(bac_Soil_D1, type="response",newdata = bacD1_dat1)
resi_bac_En_D1 <- resid(bac_En_D1, type="response",newdata = bacD1_dat1)
resi_bac_Pl_D1 <- resid(bac_Pl_D1, type="response",newdata = bacD1_dat1)
resi_bac_SoilPl_D1 <- resid(bac_SoilPl_D1, type="response",newdata = bacD1_dat1)
resi_bac_All_D1 <- resid(bac_All_D1, type="response",newdata = bacD1_dat1)

resi_bac_Soil_D1
resi_bac_En_D1
resi_bac_Pl_D1
resi_bac_SoilPl_D1
resi_bac_All_D1


##______________________bac D2___________________
bacD2_dat1<- filter(bac_dat, Depth == "D2")
bacD2_dat1 <-bacD2_dat1 %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAP = scale(MAP),
         MAT = scale(MAT),
         AET = scale(AET),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP) )

#*_________________Soil_________________
bac_Soil_D2 <- lme(lnB ~ pH+ EC + SWC,
                   random = (~1|Replicate),
                   data = bacD2_dat1)

r.squared.marginal_BD2 <- r.squaredGLMM(bac_Soil_D2)
r.squared.marginal_BD2
r_squared_boot_BD2_Soil <- function(data, indices) {
  
  data_boot_BD2_Soil <- data[indices, ]
  
  model_boot_BD2_Soil <- update(bac_Soil_D2, data = data_boot_BD2_Soil)
  
  r.squared.marginal <- r.squaredGLMM(model_boot_BD2_Soil)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_BD2_Soil <- boot(data = bacD2_dat1, statistic = r_squared_boot_BD2_Soil, R = nboots)

boot_BD2_Soil <- boot_results_BD2_Soil$t
lme_BD2_Soil <- as.data.frame(boot_BD2_Soil)


savepath <- "./bootstrip"
filename <- "lme_BD2_1Soil.csv"
write.csv(lme_BD2_Soil, file = paste0(savepath, "/", filename), row.names = TRUE)
glmm.hp(bac_Soil_D2)

#*_________________Energy_________________
bac_En_D2 <- lme(lnB ~MAT  + NPP + SOC + ST,
                 random = (~1|Replicate),
                 data = bacD2_dat1)

r.squared.marginal_BD2 <- r.squaredGLMM(bac_En_D2)
r_squared_boot_BD2_En <- function(data, indices) {
  
  data_boot_BD2_En <- data[indices, ]
  
  model_boot_BD2_En <- update(bac_En_D2, data = data_boot_BD2_En)
  
  r.squared.marginal <- r.squaredGLMM(model_boot_BD2_En)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_BD2_En <- boot(data = bacD2_dat1, statistic = r_squared_boot_BD2_En, R = nboots)

boot_BD2_En <- boot_results_BD2_En$t
lme_BD2_En <- as.data.frame(boot_BD2_En)


savepath <- "./bootstrip"
filename <- "lme_BD2_2En.csv"
write.csv(lme_BD2_En, file = paste0(savepath, "/", filename), row.names = TRUE)

#*_________________Plant_________________
bac_Pl_D2 <- lm(lnB ~ lnP,
                random = (~1|Replicate),
                data = bacD2_dat1)

r.squared.marginal_BD2 <- r.squaredGLMM(bac_Pl_D2)
r.squared.marginal_BD2
r_squared_boot_BD2_Pl <- function(data, indices) {
  
  data_boot_BD2_Pl <- data[indices, ]
  
  model_boot_BD2_Pl <- update(bac_Pl_D2, data = data_boot_BD2_Pl)
  
  r.squared.marginal <- r.squaredGLMM(model_boot_BD2_Pl)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_BD2_Pl <- boot(data = bacD2_dat1, statistic = r_squared_boot_BD2_Pl, R = nboots)

boot_BD2_Pl <- boot_results_BD2_Pl$t
lme_BD2_Pl <- as.data.frame(boot_BD2_Pl)


savepath <- "./bootstrip"
filename <- "lme_BD2_3Pl.csv"
write.csv(lme_BD2_Pl, file = paste0(savepath, "/", filename), row.names = TRUE)

glmm.hp(bac_Pl_D2)


#*_________________Boot Plant+Soil_________________
bac_SoilPl_D2 <- lmer(lnB ~ EC+pH+SWC + lnP + (1|Replicate), data = bacD2_dat1)
glmm.hp(bac_SoilPl_D2)

r.squared.marginal <- r.squaredGLMM(bac_SoilPl_D2)
r.squared.marginal
r_squared_boot_SoilPl <- function(data, indices) {
  
  data_boot <- data[indices, ]
  
  model_boot <- update(bac_SoilPl_D2, data = data_boot)
  
  r.squared.marginal <- r.squaredGLMM(model_boot)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_BacD2_SoilPl <- boot(data = bacD2_dat1, statistic = r_squared_boot_SoilPl, R = nboots)

boot_bacD2_SoilPl <-boot_results_BacD2_SoilPl$t
lme_bacD2_SoilPl <- as.data.frame(boot_bacD2_SoilPl)


savepath <- "./bootstrip"
filename <- "lme1_bacD2_SoilPl.csv"
write.csv(lme_bacD2_SoilPl, file = paste0(savepath, "/", filename), row.names = TRUE)
#all factors
bac_All_D2 <- lme(lnB ~ MAT + NPP + SOC + pH 
                  + EC + ST + SWC +lnP,
                  random = (~1|Replicate),
                  data = bacD2_dat1)
glmm.hp(bac_All_D2)
r.squared.marginal <- r.squaredGLMM(bac_All_D2)
r.squared.marginal

#residuals 
resi_bac_Soil_D2 <- resid(bac_Soil_D2, type="response",newdata = bacD2_dat1)
resi_bac_En_D2 <- resid(bac_En_D2, type="response",newdata = bacD2_dat1)
resi_bac_Pl_D2 <- resid(bac_Pl_D2, type="response",newdata = bacD2_dat1)
resi_bac_SoilPl_D2 <- resid(bac_SoilPl_D2, type="response",newdata = bacD2_dat1)
resi_bac_All_D2 <- resid(bac_All_D2, type="response",newdata = bacD2_dat1)

resi_bac_Soil_D2
resi_bac_En_D2
resi_bac_Pl_D2
resi_bac_SoilPl_D2
resi_bac_All_D2

##______________________bac D3___________________
bacD3_dat1<- filter(bac_dat, Depth == "D3")
bacD3_dat1 <-bacD3_dat1 %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAP = scale(MAP),
         MAT = scale(MAT),
         AET = scale(AET),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP) )

#*_________________Soil_________________
bac_Soil_D3 <- lme(lnB ~ pH+ EC + SWC,
                   random = (~1|Replicate),
                   data = bacD3_dat1)

r.squared.marginal_BD3 <- r.squaredGLMM(bac_Soil_D3)
r.squared.marginal_BD3
r_squared_boot_BD3_Soil <- function(data, indices) {
  
  data_boot_BD3_Soil <- data[indices, ]
  
  model_boot_BD3_Soil <- update(bac_Soil_D3, data = data_boot_BD3_Soil)
  
  r.squared.marginal <- r.squaredGLMM(model_boot_BD3_Soil)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_BD3_Soil <- boot(data = bacD3_dat1, statistic = r_squared_boot_BD3_Soil, R = nboots)

boot_BD3_Soil <- boot_results_BD3_Soil$t
lme_BD3_Soil <- as.data.frame(boot_BD3_Soil)


savepath <- "./bootstrip"
filename <- "lme_BD3_1Soil.csv"
write.csv(lme_BD3_Soil, file = paste0(savepath, "/", filename), row.names = TRUE)
glmm.hp(bac_Soil_D3)

#*_________________Energy_________________
bac_En_D3 <- lme(lnB ~MAT  + NPP + SOC + ST,
                 random = (~1|Replicate),
                 data = bacD3_dat1)

r.squared.marginal_BD3 <- r.squaredGLMM(bac_En_D3)
r_squared_boot_BD3_En <- function(data, indices) {
  
  data_boot_BD3_En <- data[indices, ]
  
  model_boot_BD3_En <- update(bac_En_D3, data = data_boot_BD3_En)
  
  r.squared.marginal <- r.squaredGLMM(model_boot_BD3_En)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_BD3_En <- boot(data = bacD3_dat1, statistic = r_squared_boot_BD3_En, R = nboots)

boot_BD3_En <- boot_results_BD3_En$t
lme_BD3_En <- as.data.frame(boot_BD3_En)


savepath <- "./bootstrip"
filename <- "lme_BD3_2En.csv"
write.csv(lme_BD3_En, file = paste0(savepath, "/", filename), row.names = TRUE)

#*_________________Plant_________________
bac_Pl_D3 <- lm(lnB ~ lnP,
                random = (~1|Replicate),
                data = bacD3_dat1)

r.squared.marginal_BD3 <- r.squaredGLMM(bac_Pl_D3)
r.squared.marginal_BD3
r_squared_boot_BD3_Pl <- function(data, indices) {
  
  data_boot_BD3_Pl <- data[indices, ]
  
  model_boot_BD3_Pl <- update(bac_Pl_D3, data = data_boot_BD3_Pl)
  
  r.squared.marginal <- r.squaredGLMM(model_boot_BD3_Pl)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_BD3_Pl <- boot(data = bacD3_dat1, statistic = r_squared_boot_BD3_Pl, R = nboots)

boot_BD3_Pl <- boot_results_BD3_Pl$t
lme_BD3_Pl <- as.data.frame(boot_BD3_Pl)


savepath <- "./bootstrip"
filename <- "lme_BD3_3Pl.csv"
write.csv(lme_BD3_Pl, file = paste0(savepath, "/", filename), row.names = TRUE)

glmm.hp(bac_Pl_D3)


#*_________________Boot Plant+Soil_________________
bac_SoilPl_D3 <- lmer(lnB ~ EC+pH+SWC + lnP + (1|Replicate), data = bacD3_dat1)
glmm.hp(bac_SoilPl_D3)

r.squared.marginal <- r.squaredGLMM(bac_SoilPl_D3)
r.squared.marginal
r_squared_boot_SoilPl <- function(data, indices) {
  
  data_boot <- data[indices, ]
  
  model_boot <- update(bac_SoilPl_D3, data = data_boot)
  
  r.squared.marginal <- r.squaredGLMM(model_boot)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_BacD3_SoilPl <- boot(data = bacD3_dat1, statistic = r_squared_boot_SoilPl, R = nboots)

boot_bacD3_SoilPl <-boot_results_BacD3_SoilPl$t
lme_bacD3_SoilPl <- as.data.frame(boot_bacD3_SoilPl)


savepath <- "./bootstrip"
filename <- "lme1_bacD3_SoilPl.csv"
write.csv(lme_bacD3_SoilPl, file = paste0(savepath, "/", filename), row.names = TRUE)
#all factors
bac_All_D3 <- lme(lnB ~ MAT + NPP + SOC + pH 
                  + EC + ST + SWC +lnP,
                  random = (~1|Replicate),
                  data = bacD3_dat1)
glmm.hp(bac_All_D3)
r.squared.marginal <- r.squaredGLMM(bac_All_D3)
r.squared.marginal

#residuals 
resi_bac_Soil_D3 <- resid(bac_Soil_D3, type="response",newdata = bacD3_dat1)
resi_bac_En_D3 <- resid(bac_En_D3, type="response",newdata = bacD3_dat1)
resi_bac_Pl_D3 <- resid(bac_Pl_D3, type="response",newdata = bacD3_dat1)
resi_bac_SoilPl_D3 <- resid(bac_SoilPl_D3, type="response",newdata = bacD3_dat1)
resi_bac_All_D3 <- resid(bac_All_D3, type="response",newdata = bacD3_dat1)

resi_bac_Soil_D3
resi_bac_En_D3
resi_bac_Pl_D3
resi_bac_SoilPl_D3
resi_bac_All_D3

##______________________bac D4___________________
bacD4_dat1<- filter(bac_dat, Depth == "D4")
bacD4_dat1 <-bacD4_dat1 %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAP = scale(MAP),
         MAT = scale(MAT),
         AET = scale(AET),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP) )

#*_________________Soil_________________
bac_Soil_D4 <- lme(lnB ~ pH+ EC + SWC,
                   random = (~1|Replicate),
                   data = bacD4_dat1)

r.squared.marginal_BD4 <- r.squaredGLMM(bac_Soil_D4)
r.squared.marginal_BD4
r_squared_boot_BD4_Soil <- function(data, indices) {
  
  data_boot_BD4_Soil <- data[indices, ]
  
  model_boot_BD4_Soil <- update(bac_Soil_D4, data = data_boot_BD4_Soil)
  
  r.squared.marginal <- r.squaredGLMM(model_boot_BD4_Soil)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_BD4_Soil <- boot(data = bacD4_dat1, statistic = r_squared_boot_BD4_Soil, R = nboots)

boot_BD4_Soil <- boot_results_BD4_Soil$t
lme_BD4_Soil <- as.data.frame(boot_BD4_Soil)


savepath <- "./bootstrip"
filename <- "lme_BD4_1Soil.csv"
write.csv(lme_BD4_Soil, file = paste0(savepath, "/", filename), row.names = TRUE)
glmm.hp(bac_Soil_D4)

#*_________________Energy_________________
bac_En_D4 <- lme(lnB ~MAT  + NPP + SOC + ST,
                 random = (~1|Replicate),
                 data = bacD4_dat1)

r.squared.marginal_BD4 <- r.squaredGLMM(bac_En_D4)
r_squared_boot_BD4_En <- function(data, indices) {
  
  data_boot_BD4_En <- data[indices, ]
  
  model_boot_BD4_En <- update(bac_En_D4, data = data_boot_BD4_En)
  
  r.squared.marginal <- r.squaredGLMM(model_boot_BD4_En)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_BD4_En <- boot(data = bacD4_dat1, statistic = r_squared_boot_BD4_En, R = nboots)

boot_BD4_En <- boot_results_BD4_En$t
lme_BD4_En <- as.data.frame(boot_BD4_En)


savepath <- "./bootstrip"
filename <- "lme_BD4_2En.csv"
write.csv(lme_BD4_En, file = paste0(savepath, "/", filename), row.names = TRUE)

#*_________________Plant_________________
bac_Pl_D4 <- lm(lnB ~ lnP,
                random = (~1|Replicate),
                data = bacD4_dat1)

r.squared.marginal_BD4 <- r.squaredGLMM(bac_Pl_D4)
r.squared.marginal_BD4
r_squared_boot_BD4_Pl <- function(data, indices) {
  
  data_boot_BD4_Pl <- data[indices, ]
  
  model_boot_BD4_Pl <- update(bac_Pl_D4, data = data_boot_BD4_Pl)
  
  r.squared.marginal <- r.squaredGLMM(model_boot_BD4_Pl)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_BD4_Pl <- boot(data = bacD4_dat1, statistic = r_squared_boot_BD4_Pl, R = nboots)

boot_BD4_Pl <- boot_results_BD4_Pl$t
lme_BD4_Pl <- as.data.frame(boot_BD4_Pl)


savepath <- "./bootstrip"
filename <- "lme_BD4_3Pl.csv"
write.csv(lme_BD4_Pl, file = paste0(savepath, "/", filename), row.names = TRUE)

glmm.hp(bac_Pl_D4)


#*_________________Boot Plant+Soil_________________
bac_SoilPl_D4 <- lmer(lnB ~ EC+pH+SWC + lnP + (1|Replicate), data = bacD4_dat1)
glmm.hp(bac_SoilPl_D4)

r.squared.marginal <- r.squaredGLMM(bac_SoilPl_D4)
r.squared.marginal
r_squared_boot_SoilPl <- function(data, indices) {
  
  data_boot <- data[indices, ]
  
  model_boot <- update(bac_SoilPl_D4, data = data_boot)
  
  r.squared.marginal <- r.squaredGLMM(model_boot)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_BacD4_SoilPl <- boot(data = bacD4_dat1, statistic = r_squared_boot_SoilPl, R = nboots)

boot_bacD4_SoilPl <-boot_results_BacD4_SoilPl$t
lme_bacD4_SoilPl <- as.data.frame(boot_bacD4_SoilPl)


savepath <- "./bootstrip"
filename <- "lme1_bacD4_SoilPl.csv"
write.csv(lme_bacD4_SoilPl, file = paste0(savepath, "/", filename), row.names = TRUE)
#all factors
bac_All_D4 <- lme(lnB ~ MAT + NPP + SOC + pH 
                  + EC + ST + SWC +lnP,
                  random = (~1|Replicate),
                  data = bacD4_dat1)
glmm.hp(bac_All_D4)
r.squared.marginal <- r.squaredGLMM(bac_All_D4)
r.squared.marginal

#residuals 
resi_bac_Soil_D4 <- resid(bac_Soil_D4, type="response",newdata = bacD4_dat1)
resi_bac_En_D4 <- resid(bac_En_D4, type="response",newdata = bacD4_dat1)
resi_bac_Pl_D4 <- resid(bac_Pl_D4, type="response",newdata = bacD4_dat1)
resi_bac_SoilPl_D4 <- resid(bac_SoilPl_D4, type="response",newdata = bacD4_dat1)
resi_bac_All_D4 <- resid(bac_All_D4, type="response",newdata = bacD4_dat1)

resi_bac_Soil_D4
resi_bac_En_D4
resi_bac_Pl_D4
resi_bac_SoilPl_D4
resi_bac_All_D4

#______________________________fungi______________________________________
#all depths
funOver_dat1<- filter(fun_dat, Depth == "Overall")
funOver_dat1 <-funOver_dat1 %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAP = scale(MAP),
         MAT = scale(MAT),
         AET = scale(AET),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP) )

#*_________________Soil_________________
fun_Soil_Over <- lme(lnB ~ pH+ EC + SWC,
                     random = (~1|Elevation/Replicate),
                     data = funOver_dat1)

r.squared.marginal_BOver <- r.squaredGLMM(fun_Soil_Over)
r.squared.marginal_BOver
r_squared_boot_BOver_Soil <- function(data, indices) {
  
  data_boot_BOver_Soil <- data[indices, ]
  
  model_boot_BOver_Soil <- update(fun_Soil_Over, data = data_boot_BOver_Soil)
  
  r.squared.marginal <- r.squaredGLMM(model_boot_BOver_Soil)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_BOver_Soil <- boot(data = funOver_dat1, statistic = r_squared_boot_BOver_Soil, R = nboots)

boot_BOver_Soil <- boot_results_BOver_Soil$t
lme_BOver_Soil <- as.data.frame(boot_BOver_Soil)


savepath <- "./bootstrip"
filename <- "lme_BOver_1Soil.csv"
write.csv(lme_BOver_Soil, file = paste0(savepath, "/", filename), row.names = TRUE)
glmm.hp(fun_Soil_Over)

#*_________________Energy_________________
fun_En_Over <- lme(lnB ~MAT  + NPP + SOC + ST,
                   random = (~1|Elevation/Replicate),
                   data = funOver_dat1)

r.squared.marginal_BOver <- r.squaredGLMM(fun_En_Over)
r_squared_boot_BOver_En <- function(data, indices) {
  
  data_boot_BOver_En <- data[indices, ]
  
  model_boot_BOver_En <- update(fun_En_Over, data = data_boot_BOver_En)
  
  r.squared.marginal <- r.squaredGLMM(model_boot_BOver_En)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_BOver_En <- boot(data = funOver_dat1, statistic = r_squared_boot_BOver_En, R = nboots)

boot_BOver_En <- boot_results_BOver_En$t
lme_BOver_En <- as.data.frame(boot_BOver_En)


savepath <- "./bootstrip"
filename <- "lme_BOver_2En.csv"
write.csv(lme_BOver_En, file = paste0(savepath, "/", filename), row.names = TRUE)

#*_________________Plant_________________
fun_Pl_Over <- lm(lnB ~ lnP,
                  random = (~1|Elevation/Replicate),
                  data = funOver_dat1)

r.squared.marginal_BOver <- r.squaredGLMM(fun_Pl_Over)
r.squared.marginal_BOver
r_squared_boot_BOver_Pl <- function(data, indices) {
  
  data_boot_BOver_Pl <- data[indices, ]
  
  model_boot_BOver_Pl <- update(fun_Pl_Over, data = data_boot_BOver_Pl)
  
  r.squared.marginal <- r.squaredGLMM(model_boot_BOver_Pl)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_BOver_Pl <- boot(data = funOver_dat1, statistic = r_squared_boot_BOver_Pl, R = nboots)

boot_BOver_Pl <- boot_results_BOver_Pl$t
lme_BOver_Pl <- as.data.frame(boot_BOver_Pl)


savepath <- "./bootstrip"
filename <- "lme_BOver_3Pl.csv"
write.csv(lme_BOver_Pl, file = paste0(savepath, "/", filename), row.names = TRUE)

glmm.hp(fun_Pl_Over)


#*_________________Boot Plant+Soil_________________
fun_SoilPl_Over <- lmer(lnB ~ EC+pH+SWC + lnP + (1|Replicate), data = funOver_dat1)
glmm.hp(fun_SoilPl_Over)

r.squared.marginal <- r.squaredGLMM(fun_SoilPl_Over)
r.squared.marginal
r_squared_boot_SoilPl <- function(data, indices) {
  
  data_boot <- data[indices, ]
  
  model_boot <- update(fun_SoilPl_Over, data = data_boot)
  
  r.squared.marginal <- r.squaredGLMM(model_boot)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_funOver_SoilPl <- boot(data = funOver_dat1, statistic = r_squared_boot_SoilPl, R = nboots)

boot_funOver_SoilPl <-boot_results_funOver_SoilPl$t
lme_funOver_SoilPl <- as.data.frame(boot_funOver_SoilPl)


savepath <- "./bootstrip"
filename <- "lme1_funOver_SoilPl.csv"
write.csv(lme_funOver_SoilPl, file = paste0(savepath, "/", filename), row.names = TRUE)
#all factors
fun_All_Over <- lme(lnB ~ MAT + NPP + SOC + pH 
                    + EC + ST + SWC +lnP,
                    random = (~1|Elevation/Replicate),
                    data = funOver_dat1)
glmm.hp(fun_All_Over)
r.squared.marginal <- r.squaredGLMM(fun_All_Over)
r.squared.marginal

#residuals 
resi_fun_Soil_Over <- resid(fun_Soil_Over, type="response",newdata = funOver_dat1)
resi_fun_En_Over <- resid(fun_En_Over, type="response",newdata = funOver_dat1)
resi_fun_Pl_Over <- resid(fun_Pl_Over, type="response",newdata = funOver_dat1)
resi_fun_SoilPl_Over <- resid(fun_SoilPl_Over, type="response",newdata = funOver_dat1)
resi_fun_All_Over <- resid(fun_All_Over, type="response",newdata = funOver_dat1)

resi_fun_Soil_Over
resi_fun_En_Over
resi_fun_Pl_Over
resi_fun_SoilPl_Over
resi_fun_All_Over
##______________________fun D1___________________
funD1_dat1<- filter(fun_dat, Depth == "D1")
funD1_dat1 <-funD1_dat1 %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAP = scale(MAP),
         MAT = scale(MAT),
         AET = scale(AET),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP) )

#*_________________Soil_________________
fun_Soil_D1 <- lme(lnB ~ pH+ EC + SWC,
                   random = (~1|Replicate),
                   data = funD1_dat1)

r.squared.marginal_BD1 <- r.squaredGLMM(fun_Soil_D1)
r.squared.marginal_BD1
r_squared_boot_BD1_Soil <- function(data, indices) {
  
  data_boot_BD1_Soil <- data[indices, ]
  
  model_boot_BD1_Soil <- update(fun_Soil_D1, data = data_boot_BD1_Soil)
  
  r.squared.marginal <- r.squaredGLMM(model_boot_BD1_Soil)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_BD1_Soil <- boot(data = funD1_dat1, statistic = r_squared_boot_BD1_Soil, R = nboots)

boot_BD1_Soil <- boot_results_BD1_Soil$t
lme_BD1_Soil <- as.data.frame(boot_BD1_Soil)


savepath <- "./bootstrip"
filename <- "lme_BD1_1Soil.csv"
write.csv(lme_BD1_Soil, file = paste0(savepath, "/", filename), row.names = TRUE)
glmm.hp(fun_Soil_D1)

#*_________________Energy_________________
fun_En_D1 <- lme(lnB ~MAT  + NPP + SOC + ST,
                 random = (~1|Replicate),
                 data = funD1_dat1)

r.squared.marginal_BD1 <- r.squaredGLMM(fun_En_D1)
r_squared_boot_BD1_En <- function(data, indices) {
  
  data_boot_BD1_En <- data[indices, ]
  
  model_boot_BD1_En <- update(fun_En_D1, data = data_boot_BD1_En)
  
  r.squared.marginal <- r.squaredGLMM(model_boot_BD1_En)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_BD1_En <- boot(data = funD1_dat1, statistic = r_squared_boot_BD1_En, R = nboots)

boot_BD1_En <- boot_results_BD1_En$t
lme_BD1_En <- as.data.frame(boot_BD1_En)


savepath <- "./bootstrip"
filename <- "lme_BD1_2En.csv"
write.csv(lme_BD1_En, file = paste0(savepath, "/", filename), row.names = TRUE)

#*_________________Plant_________________
fun_Pl_D1 <- lm(lnB ~ lnP,
                random = (~1|Replicate),
                data = funD1_dat1)

r.squared.marginal_BD1 <- r.squaredGLMM(fun_Pl_D1)
r.squared.marginal_BD1
r_squared_boot_BD1_Pl <- function(data, indices) {
  
  data_boot_BD1_Pl <- data[indices, ]
  
  model_boot_BD1_Pl <- update(fun_Pl_D1, data = data_boot_BD1_Pl)
  
  r.squared.marginal <- r.squaredGLMM(model_boot_BD1_Pl)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_BD1_Pl <- boot(data = funD1_dat1, statistic = r_squared_boot_BD1_Pl, R = nboots)

boot_BD1_Pl <- boot_results_BD1_Pl$t
lme_BD1_Pl <- as.data.frame(boot_BD1_Pl)


savepath <- "./bootstrip"
filename <- "lme_BD1_3Pl.csv"
write.csv(lme_BD1_Pl, file = paste0(savepath, "/", filename), row.names = TRUE)

glmm.hp(fun_Pl_D1)


#*_________________Boot Plant+Soil_________________
fun_SoilPl_D1 <- lmer(lnB ~ EC+pH+SWC + lnP + (1|Replicate), data = funD1_dat1)
glmm.hp(fun_SoilPl_D1)

r.squared.marginal <- r.squaredGLMM(fun_SoilPl_D1)
r.squared.marginal
r_squared_boot_SoilPl <- function(data, indices) {
  
  data_boot <- data[indices, ]
  
  model_boot <- update(fun_SoilPl_D1, data = data_boot)
  
  r.squared.marginal <- r.squaredGLMM(model_boot)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_funD1_SoilPl <- boot(data = funD1_dat1, statistic = r_squared_boot_SoilPl, R = nboots)

boot_funD1_SoilPl <-boot_results_funD1_SoilPl$t
lme_funD1_SoilPl <- as.data.frame(boot_funD1_SoilPl)


savepath <- "./bootstrip"
filename <- "lme1_funD1_SoilPl.csv"
write.csv(lme_funD1_SoilPl, file = paste0(savepath, "/", filename), row.names = TRUE)
#all factors
fun_All_D1 <- lme(lnB ~ MAT + NPP + SOC + pH 
                  + EC + ST + SWC +lnP,
                  random = (~1|Replicate),
                  data = funD1_dat1)
glmm.hp(fun_All_D1)
r.squared.marginal <- r.squaredGLMM(fun_All_D1)
r.squared.marginal

#residuals 
resi_fun_Soil_D1 <- resid(fun_Soil_D1, type="response",newdata = funD1_dat1)
resi_fun_En_D1 <- resid(fun_En_D1, type="response",newdata = funD1_dat1)
resi_fun_Pl_D1 <- resid(fun_Pl_D1, type="response",newdata = funD1_dat1)
resi_fun_SoilPl_D1 <- resid(fun_SoilPl_D1, type="response",newdata = funD1_dat1)
resi_fun_All_D1 <- resid(fun_All_D1, type="response",newdata = funD1_dat1)

resi_fun_Soil_D1
resi_fun_En_D1
resi_fun_Pl_D1
resi_fun_SoilPl_D1
resi_fun_All_D1


##______________________fun D2___________________
funD2_dat1<- filter(fun_dat, Depth == "D2")
funD2_dat1 <-funD2_dat1 %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAP = scale(MAP),
         MAT = scale(MAT),
         AET = scale(AET),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP) )

#*_________________Soil_________________
fun_Soil_D2 <- lme(lnB ~ pH+ EC + SWC,
                   random = (~1|Replicate),
                   data = funD2_dat1)

r.squared.marginal_BD2 <- r.squaredGLMM(fun_Soil_D2)
r.squared.marginal_BD2
r_squared_boot_BD2_Soil <- function(data, indices) {
  
  data_boot_BD2_Soil <- data[indices, ]
  
  model_boot_BD2_Soil <- update(fun_Soil_D2, data = data_boot_BD2_Soil)
  
  r.squared.marginal <- r.squaredGLMM(model_boot_BD2_Soil)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_BD2_Soil <- boot(data = funD2_dat1, statistic = r_squared_boot_BD2_Soil, R = nboots)

boot_BD2_Soil <- boot_results_BD2_Soil$t
lme_BD2_Soil <- as.data.frame(boot_BD2_Soil)


savepath <- "./bootstrip"
filename <- "lme_BD2_1Soil.csv"
write.csv(lme_BD2_Soil, file = paste0(savepath, "/", filename), row.names = TRUE)
glmm.hp(fun_Soil_D2)

#*_________________Energy_________________
fun_En_D2 <- lme(lnB ~MAT  + NPP + SOC + ST,
                 random = (~1|Replicate),
                 data = funD2_dat1)

r.squared.marginal_BD2 <- r.squaredGLMM(fun_En_D2)
r_squared_boot_BD2_En <- function(data, indices) {
  
  data_boot_BD2_En <- data[indices, ]
  
  model_boot_BD2_En <- update(fun_En_D2, data = data_boot_BD2_En)
  
  r.squared.marginal <- r.squaredGLMM(model_boot_BD2_En)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_BD2_En <- boot(data = funD2_dat1, statistic = r_squared_boot_BD2_En, R = nboots)

boot_BD2_En <- boot_results_BD2_En$t
lme_BD2_En <- as.data.frame(boot_BD2_En)


savepath <- "./bootstrip"
filename <- "lme_BD2_2En.csv"
write.csv(lme_BD2_En, file = paste0(savepath, "/", filename), row.names = TRUE)

#*_________________Plant_________________
fun_Pl_D2 <- lm(lnB ~ lnP,
                random = (~1|Replicate),
                data = funD2_dat1)

r.squared.marginal_BD2 <- r.squaredGLMM(fun_Pl_D2)
r.squared.marginal_BD2
r_squared_boot_BD2_Pl <- function(data, indices) {
  
  data_boot_BD2_Pl <- data[indices, ]
  
  model_boot_BD2_Pl <- update(fun_Pl_D2, data = data_boot_BD2_Pl)
  
  r.squared.marginal <- r.squaredGLMM(model_boot_BD2_Pl)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_BD2_Pl <- boot(data = funD2_dat1, statistic = r_squared_boot_BD2_Pl, R = nboots)

boot_BD2_Pl <- boot_results_BD2_Pl$t
lme_BD2_Pl <- as.data.frame(boot_BD2_Pl)


savepath <- "./bootstrip"
filename <- "lme_BD2_3Pl.csv"
write.csv(lme_BD2_Pl, file = paste0(savepath, "/", filename), row.names = TRUE)

glmm.hp(fun_Pl_D2)


#*_________________Boot Plant+Soil_________________
fun_SoilPl_D2 <- lmer(lnB ~ EC+pH+SWC + lnP + (1|Replicate), data = funD2_dat1)
glmm.hp(fun_SoilPl_D2)

r.squared.marginal <- r.squaredGLMM(fun_SoilPl_D2)
r.squared.marginal
r_squared_boot_SoilPl <- function(data, indices) {
  
  data_boot <- data[indices, ]
  
  model_boot <- update(fun_SoilPl_D2, data = data_boot)
  
  r.squared.marginal <- r.squaredGLMM(model_boot)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_funD2_SoilPl <- boot(data = funD2_dat1, statistic = r_squared_boot_SoilPl, R = nboots)

boot_funD2_SoilPl <-boot_results_funD2_SoilPl$t
lme_funD2_SoilPl <- as.data.frame(boot_funD2_SoilPl)


savepath <- "./bootstrip"
filename <- "lme1_funD2_SoilPl.csv"
write.csv(lme_funD2_SoilPl, file = paste0(savepath, "/", filename), row.names = TRUE)
#all factors
fun_All_D2 <- lme(lnB ~ MAT + NPP + SOC + pH 
                  + EC + ST + SWC +lnP,
                  random = (~1|Replicate),
                  data = funD2_dat1)
glmm.hp(fun_All_D2)
r.squared.marginal <- r.squaredGLMM(fun_All_D2)
r.squared.marginal

#residuals 
resi_fun_Soil_D2 <- resid(fun_Soil_D2, type="response",newdata = funD2_dat1)
resi_fun_En_D2 <- resid(fun_En_D2, type="response",newdata = funD2_dat1)
resi_fun_Pl_D2 <- resid(fun_Pl_D2, type="response",newdata = funD2_dat1)
resi_fun_SoilPl_D2 <- resid(fun_SoilPl_D2, type="response",newdata = funD2_dat1)
resi_fun_All_D2 <- resid(fun_All_D2, type="response",newdata = funD2_dat1)

resi_fun_Soil_D2
resi_fun_En_D2
resi_fun_Pl_D2
resi_fun_SoilPl_D2
resi_fun_All_D2

##______________________fun D3___________________
funD3_dat1<- filter(fun_dat, Depth == "D3")
funD3_dat1 <-funD3_dat1 %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAP = scale(MAP),
         MAT = scale(MAT),
         AET = scale(AET),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP) )

#*_________________Soil_________________
fun_Soil_D3 <- lme(lnB ~ pH+ EC + SWC,
                   random = (~1|Replicate),
                   data = funD3_dat1)

r.squared.marginal_BD3 <- r.squaredGLMM(fun_Soil_D3)
r.squared.marginal_BD3
r_squared_boot_BD3_Soil <- function(data, indices) {
  
  data_boot_BD3_Soil <- data[indices, ]
  
  model_boot_BD3_Soil <- update(fun_Soil_D3, data = data_boot_BD3_Soil)
  
  r.squared.marginal <- r.squaredGLMM(model_boot_BD3_Soil)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_BD3_Soil <- boot(data = funD3_dat1, statistic = r_squared_boot_BD3_Soil, R = nboots)

boot_BD3_Soil <- boot_results_BD3_Soil$t
lme_BD3_Soil <- as.data.frame(boot_BD3_Soil)


savepath <- "./bootstrip"
filename <- "lme_BD3_1Soil.csv"
write.csv(lme_BD3_Soil, file = paste0(savepath, "/", filename), row.names = TRUE)
glmm.hp(fun_Soil_D3)

#*_________________Energy_________________
fun_En_D3 <- lme(lnB ~MAT  + NPP + SOC + ST,
                 random = (~1|Replicate),
                 data = funD3_dat1)

r.squared.marginal_BD3 <- r.squaredGLMM(fun_En_D3)
r_squared_boot_BD3_En <- function(data, indices) {
  
  data_boot_BD3_En <- data[indices, ]
  
  model_boot_BD3_En <- update(fun_En_D3, data = data_boot_BD3_En)
  
  r.squared.marginal <- r.squaredGLMM(model_boot_BD3_En)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_BD3_En <- boot(data = funD3_dat1, statistic = r_squared_boot_BD3_En, R = nboots)

boot_BD3_En <- boot_results_BD3_En$t
lme_BD3_En <- as.data.frame(boot_BD3_En)


savepath <- "./bootstrip"
filename <- "lme_BD3_2En.csv"
write.csv(lme_BD3_En, file = paste0(savepath, "/", filename), row.names = TRUE)

#*_________________Plant_________________
fun_Pl_D3 <- lm(lnB ~ lnP,
                random = (~1|Replicate),
                data = funD3_dat1)

r.squared.marginal_BD3 <- r.squaredGLMM(fun_Pl_D3)
r.squared.marginal_BD3
r_squared_boot_BD3_Pl <- function(data, indices) {
  
  data_boot_BD3_Pl <- data[indices, ]
  
  model_boot_BD3_Pl <- update(fun_Pl_D3, data = data_boot_BD3_Pl)
  
  r.squared.marginal <- r.squaredGLMM(model_boot_BD3_Pl)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_BD3_Pl <- boot(data = funD3_dat1, statistic = r_squared_boot_BD3_Pl, R = nboots)

boot_BD3_Pl <- boot_results_BD3_Pl$t
lme_BD3_Pl <- as.data.frame(boot_BD3_Pl)


savepath <- "./bootstrip"
filename <- "lme_BD3_3Pl.csv"
write.csv(lme_BD3_Pl, file = paste0(savepath, "/", filename), row.names = TRUE)

glmm.hp(fun_Pl_D3)


#*_________________Boot Plant+Soil_________________
fun_SoilPl_D3 <- lmer(lnB ~ EC+pH+SWC + lnP + (1|Replicate), data = funD3_dat1)
glmm.hp(fun_SoilPl_D3)

r.squared.marginal <- r.squaredGLMM(fun_SoilPl_D3)
r.squared.marginal
r_squared_boot_SoilPl <- function(data, indices) {
  
  data_boot <- data[indices, ]
  
  model_boot <- update(fun_SoilPl_D3, data = data_boot)
  
  r.squared.marginal <- r.squaredGLMM(model_boot)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_funD3_SoilPl <- boot(data = funD3_dat1, statistic = r_squared_boot_SoilPl, R = nboots)

boot_funD3_SoilPl <-boot_results_funD3_SoilPl$t
lme_funD3_SoilPl <- as.data.frame(boot_funD3_SoilPl)


savepath <- "./bootstrip"
filename <- "lme1_funD3_SoilPl.csv"
write.csv(lme_funD3_SoilPl, file = paste0(savepath, "/", filename), row.names = TRUE)
#all factors
fun_All_D3 <- lme(lnB ~ MAT + NPP + SOC + pH 
                  + EC + ST + SWC +lnP,
                  random = (~1|Replicate),
                  data = funD3_dat1)
glmm.hp(fun_All_D3)
r.squared.marginal <- r.squaredGLMM(fun_All_D3)
r.squared.marginal

#residuals 
resi_fun_Soil_D3 <- resid(fun_Soil_D3, type="response",newdata = funD3_dat1)
resi_fun_En_D3 <- resid(fun_En_D3, type="response",newdata = funD3_dat1)
resi_fun_Pl_D3 <- resid(fun_Pl_D3, type="response",newdata = funD3_dat1)
resi_fun_SoilPl_D3 <- resid(fun_SoilPl_D3, type="response",newdata = funD3_dat1)
resi_fun_All_D3 <- resid(fun_All_D3, type="response",newdata = funD3_dat1)

resi_fun_Soil_D3
resi_fun_En_D3
resi_fun_Pl_D3
resi_fun_SoilPl_D3
resi_fun_All_D3

##______________________fun D4___________________
funD4_dat1<- filter(fun_dat, Depth == "D4")
funD4_dat1 <-funD4_dat1 %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAP = scale(MAP),
         MAT = scale(MAT),
         AET = scale(AET),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP) )

#*_________________Soil_________________
fun_Soil_D4 <- lme(lnB ~ pH+ EC + SWC,
                   random = (~1|Replicate),
                   data = funD4_dat1)

r.squared.marginal_BD4 <- r.squaredGLMM(fun_Soil_D4)
r.squared.marginal_BD4
r_squared_boot_BD4_Soil <- function(data, indices) {
  
  data_boot_BD4_Soil <- data[indices, ]
  
  model_boot_BD4_Soil <- update(fun_Soil_D4, data = data_boot_BD4_Soil)
  
  r.squared.marginal <- r.squaredGLMM(model_boot_BD4_Soil)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_BD4_Soil <- boot(data = funD4_dat1, statistic = r_squared_boot_BD4_Soil, R = nboots)

boot_BD4_Soil <- boot_results_BD4_Soil$t
lme_BD4_Soil <- as.data.frame(boot_BD4_Soil)


savepath <- "./bootstrip"
filename <- "lme_BD4_1Soil.csv"
write.csv(lme_BD4_Soil, file = paste0(savepath, "/", filename), row.names = TRUE)
glmm.hp(fun_Soil_D4)

#*_________________Energy_________________
fun_En_D4 <- lme(lnB ~MAT  + NPP + SOC + ST,
                 random = (~1|Replicate),
                 data = funD4_dat1)

r.squared.marginal_BD4 <- r.squaredGLMM(fun_En_D4)
r_squared_boot_BD4_En <- function(data, indices) {
  
  data_boot_BD4_En <- data[indices, ]
  
  model_boot_BD4_En <- update(fun_En_D4, data = data_boot_BD4_En)
  
  r.squared.marginal <- r.squaredGLMM(model_boot_BD4_En)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_BD4_En <- boot(data = funD4_dat1, statistic = r_squared_boot_BD4_En, R = nboots)

boot_BD4_En <- boot_results_BD4_En$t
lme_BD4_En <- as.data.frame(boot_BD4_En)


savepath <- "./bootstrip"
filename <- "lme_BD4_2En.csv"
write.csv(lme_BD4_En, file = paste0(savepath, "/", filename), row.names = TRUE)

#*_________________Plant_________________
fun_Pl_D4 <- lm(lnB ~ lnP,
                random = (~1|Replicate),
                data = funD4_dat1)

r.squared.marginal_BD4 <- r.squaredGLMM(fun_Pl_D4)
r.squared.marginal_BD4
r_squared_boot_BD4_Pl <- function(data, indices) {
  
  data_boot_BD4_Pl <- data[indices, ]
  
  model_boot_BD4_Pl <- update(fun_Pl_D4, data = data_boot_BD4_Pl)
  
  r.squared.marginal <- r.squaredGLMM(model_boot_BD4_Pl)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_BD4_Pl <- boot(data = funD4_dat1, statistic = r_squared_boot_BD4_Pl, R = nboots)

boot_BD4_Pl <- boot_results_BD4_Pl$t
lme_BD4_Pl <- as.data.frame(boot_BD4_Pl)


savepath <- "./bootstrip"
filename <- "lme_BD4_3Pl.csv"
write.csv(lme_BD4_Pl, file = paste0(savepath, "/", filename), row.names = TRUE)

glmm.hp(fun_Pl_D4)


#*_________________Boot Plant+Soil_________________
fun_SoilPl_D4 <- lmer(lnB ~ EC+pH+SWC + lnP + (1|Replicate), data = funD4_dat1)
glmm.hp(fun_SoilPl_D4)

r.squared.marginal <- r.squaredGLMM(fun_SoilPl_D4)
r.squared.marginal
r_squared_boot_SoilPl <- function(data, indices) {
  
  data_boot <- data[indices, ]
  
  model_boot <- update(fun_SoilPl_D4, data = data_boot)
  
  r.squared.marginal <- r.squaredGLMM(model_boot)
  return(r.squared.marginal)
}
nboots <- 1000
set.seed(123) 
boot_results_funD4_SoilPl <- boot(data = funD4_dat1, statistic = r_squared_boot_SoilPl, R = nboots)

boot_funD4_SoilPl <-boot_results_funD4_SoilPl$t
lme_funD4_SoilPl <- as.data.frame(boot_funD4_SoilPl)


savepath <- "./bootstrip"
filename <- "lme1_funD4_SoilPl.csv"
write.csv(lme_funD4_SoilPl, file = paste0(savepath, "/", filename), row.names = TRUE)
#all factors
fun_All_D4 <- lme(lnB ~ MAT + NPP + SOC + pH 
                  + EC + ST + SWC +lnP,
                  random = (~1|Replicate),
                  data = funD4_dat1)
glmm.hp(fun_All_D4)
r.squared.marginal <- r.squaredGLMM(fun_All_D4)
r.squared.marginal

#residuals 
resi_fun_Soil_D4 <- resid(fun_Soil_D4, type="response",newdata = funD4_dat1)
resi_fun_En_D4 <- resid(fun_En_D4, type="response",newdata = funD4_dat1)
resi_fun_Pl_D4 <- resid(fun_Pl_D4, type="response",newdata = funD4_dat1)
resi_fun_SoilPl_D4 <- resid(fun_SoilPl_D4, type="response",newdata = funD4_dat1)
resi_fun_All_D4 <- resid(fun_All_D4, type="response",newdata = funD4_dat1)

resi_fun_Soil_D4
resi_fun_En_D4
resi_fun_Pl_D4
resi_fun_SoilPl_D4
resi_fun_All_D4

#Table S8 Magurnal R-squared (R²) and Root Mean Square Error (RMSE) from the linear mixed-effects models
#RMSE
Residual_dat <- read.table("clipboard",header=T)#load  data
rmse_by_group <- Residual_dat %>%
  group_by(Micro, Depth) %>%                    
  summarise(
    RMSE = sqrt(mean(Residual^2)),              
    .groups = 'drop'                            
  )

#Maginal R2
#_______________________________bacteria_____________________________
#all depths
R2_bac_Soil_Over <- r.squaredGLMM(bac_Soil_Over)
R2_bac_En_Over <- r.squaredGLMM(bac_En_Over)
R2_bac_Pl_Over <- r.squaredGLMM(bac_Pl_Over)
R2_bac_SoilPl_Over <- r.squaredGLMM(bac_SoilPl_Over)
R2_bac_All_Over <- r.squaredGLMM(bac_All_Over)

R2_bac_Soil_Over
R2_bac_En_Over
R2_bac_Pl_Over
R2_bac_SoilPl_Over
R2_bac_All_Over

#D1
R2_bac_Soil_D1 <- r.squaredGLMM(bac_Soil_D1)
R2_bac_En_D1 <- r.squaredGLMM(bac_En_D1)
R2_bac_Pl_D1 <- r.squaredGLMM(bac_Pl_D1)
R2_bac_SoilPl_D1 <- r.squaredGLMM(bac_SoilPl_D1)
R2_bac_All_D1 <- r.squaredGLMM(bac_All_D1)

R2_bac_Soil_D1
R2_bac_En_D1
R2_bac_Pl_D1
R2_bac_SoilPl_D1
R2_bac_All_D1

#D2
R2_bac_Soil_D2 <- r.squaredGLMM(bac_Soil_D2)
R2_bac_En_D2 <- r.squaredGLMM(bac_En_D2)
R2_bac_Pl_D2 <- r.squaredGLMM(bac_Pl_D2)
R2_bac_SoilPl_D2 <- r.squaredGLMM(bac_SoilPl_D2)
R2_bac_All_D2 <- r.squaredGLMM(bac_All_D2)

R2_bac_Soil_D2
R2_bac_En_D2
R2_bac_Pl_D2
R2_bac_SoilPl_D2
R2_bac_All_D2


#D3
R2_bac_Soil_D3 <- r.squaredGLMM(bac_Soil_D3)
R2_bac_En_D3 <- r.squaredGLMM(bac_En_D3)
R2_bac_Pl_D3 <- r.squaredGLMM(bac_Pl_D3)
R2_bac_SoilPl_D3 <- r.squaredGLMM(bac_SoilPl_D3)
R2_bac_All_D3 <- r.squaredGLMM(bac_All_D3)

R2_bac_Soil_D3
R2_bac_En_D3
R2_bac_Pl_D3
R2_bac_SoilPl_D3
R2_bac_All_D3


#D4
R2_bac_Soil_D4 <- r.squaredGLMM(bac_Soil_D4)
R2_bac_En_D4 <- r.squaredGLMM(bac_En_D4)
R2_bac_Pl_D4 <- r.squaredGLMM(bac_Pl_D4)
R2_bac_SoilPl_D4 <- r.squaredGLMM(bac_SoilPl_D4)
R2_bac_All_D4 <- r.squaredGLMM(bac_All_D4)

R2_bac_Soil_D4
R2_bac_En_D4
R2_bac_Pl_D4
R2_bac_SoilPl_D4
R2_bac_All_D4

#_______________________________fungi_____________________________
#all depths
R2_fun_Soil_Over <- r.squaredGLMM(fun_Soil_Over)
R2_fun_En_Over <- r.squaredGLMM(fun_En_Over)
R2_fun_Pl_Over <- r.squaredGLMM(fun_Pl_Over)
R2_fun_SoilPl_Over <- r.squaredGLMM(fun_SoilPl_Over)
R2_fun_All_Over <- r.squaredGLMM(fun_All_Over)

R2_fun_Soil_Over
R2_fun_En_Over
R2_fun_Pl_Over
R2_fun_SoilPl_Over
R2_fun_All_Over

#D1
R2_fun_Soil_D1 <- r.squaredGLMM(fun_Soil_D1)
R2_fun_En_D1 <- r.squaredGLMM(fun_En_D1)
R2_fun_Pl_D1 <- r.squaredGLMM(fun_Pl_D1)
R2_fun_SoilPl_D1 <- r.squaredGLMM(fun_SoilPl_D1)
R2_fun_All_D1 <- r.squaredGLMM(fun_All_D1)

R2_fun_Soil_D1
R2_fun_En_D1
R2_fun_Pl_D1
R2_fun_SoilPl_D1
R2_fun_All_D1

#D2
R2_fun_Soil_D2 <- r.squaredGLMM(fun_Soil_D2)
R2_fun_En_D2 <- r.squaredGLMM(fun_En_D2)
R2_fun_Pl_D2 <- r.squaredGLMM(fun_Pl_D2)
R2_fun_SoilPl_D2 <- r.squaredGLMM(fun_SoilPl_D2)
R2_fun_All_D2 <- r.squaredGLMM(fun_All_D2)

R2_fun_Soil_D2
R2_fun_En_D2
R2_fun_Pl_D2
R2_fun_SoilPl_D2
R2_fun_All_D2


#D3
R2_fun_Soil_D3 <- r.squaredGLMM(fun_Soil_D3)
R2_fun_En_D3 <- r.squaredGLMM(fun_En_D3)
R2_fun_Pl_D3 <- r.squaredGLMM(fun_Pl_D3)
R2_fun_SoilPl_D3 <- r.squaredGLMM(fun_SoilPl_D3)
R2_fun_All_D3 <- r.squaredGLMM(fun_All_D3)

R2_fun_Soil_D3
R2_fun_En_D3
R2_fun_Pl_D3
R2_fun_SoilPl_D3
R2_fun_All_D3


#D4
R2_fun_Soil_D4 <- r.squaredGLMM(fun_Soil_D4)
R2_fun_En_D4 <- r.squaredGLMM(fun_En_D4)
R2_fun_Pl_D4 <- r.squaredGLMM(fun_Pl_D4)
R2_fun_SoilPl_D4 <- r.squaredGLMM(fun_SoilPl_D4)
R2_fun_All_D4 <- r.squaredGLMM(fun_All_D4)

R2_fun_Soil_D4
R2_fun_En_D4
R2_fun_Pl_D4
R2_fun_SoilPl_D4
R2_fun_All_D4

#Table S9 SEM Path coefficients from energy availability, plant diversity, 
#and abiotic soil filters to microbial diversity
Path_plotdata <- Path_dat %>%
  group_by(Depth, Micro) %>%
  summarize(
    n = n(),
    
    y0 = min(Path),
    Mean = mean(Path),
    y100 = max(Path),
    sd = sd(Path),
    se = sd / sqrt(n),

    p95_lower = quantile(Path, 0.025), # (1 - 0.95) / 2 = 0.025
    p95_upper = quantile(Path, 0.975), # 1 - 0.025 = 0.975
  )
write.csv(Path_plotdata, "./Path_plotdata.csv", row.names = FALSE)

#Table S10 comparison of the variance of microbial elevational diversity explained by theories
Multiple_bOver <- Multiple_dat %>%
  filter(Micro == "Bacteria", Depth == "allOver")
view(Multiple_bOver)
anova_result_bOver <- aov(Marginal ~ Theory, data = Multiple_bOver)
tukey_result_bOver <- TukeyHSD(anova_result_bOver )
print(tukey_result_bOver)

Multiple_BD1 <- Multiple_dat %>%
  filter(Micro == "Bacteria", Depth == "D1")
anova_result_BD1 <- aov(Marginal ~ Theory, data = Multiple_BD1)
tukey_result_BD1 <- TukeyHSD(anova_result_BD1 )
print(tukey_result_BD1)

Multiple_BD2 <- Multiple_dat %>%
  filter(Micro == "Bacteria", Depth == "D2")
anova_result_BD2 <- aov(Marginal ~ Theory, data = Multiple_BD2)
tukey_result_BD2 <- TukeyHSD(anova_result_BD2 )
print(tukey_result_BD2)


Multiple_BD3 <- Multiple_dat %>%
  filter(Micro == "Bacteria", Depth == "D3")
anova_result_BD3 <- aov(Marginal ~ Theory, data = Multiple_BD3)
tukey_result_BD3 <- TukeyHSD(anova_result_BD3 )
print(tukey_result_BD3)

Multiple_BD4 <- Multiple_dat %>%
  filter(Micro == "Bacteria", Depth == "D4")
anova_result_BD4 <- aov(Marginal ~ Theory, data = Multiple_BD4)
tukey_result_BD4 <- TukeyHSD(anova_result_BD4 )
print(tukey_result_BD4)

#______________________________FUNGI ANOVA________________________
Multiple_fOver <- Multiple_dat %>%
  filter(Micro == "Fungi", Depth == "allOver")
view(Multiple_fOver)
anova_result_fOver <- aov(Marginal ~ Theory, data = Multiple_fOver)
tukey_result_fOver <- TukeyHSD(anova_result_fOver )
print(tukey_result_fOver)

Multiple_FD1 <- Multiple_dat %>%
  filter(Micro == "Fungi", Depth == "D1")
anova_result_FD1 <- aov(Marginal ~ Theory, data = Multiple_FD1)
tukey_result_FD1 <- TukeyHSD(anova_result_FD1 )
print(tukey_result_FD1)

Multiple_FD2 <- Multiple_dat %>%
  filter(Micro == "Fungi", Depth == "D2")
anova_result_FD2 <- aov(Marginal ~ Theory, data = Multiple_FD2)
tukey_result_FD2 <- TukeyHSD(anova_result_FD2 )
print(tukey_result_FD2)


Multiple_FD3 <- Multiple_dat %>%
  filter(Micro == "Fungi", Depth == "D3")
anova_result_FD3 <- aov(Marginal ~ Theory, data = Multiple_FD3)
tukey_result_FD3 <- TukeyHSD(anova_result_FD3 )
print(tukey_result_FD3)

Multiple_FD4 <- Multiple_dat %>%
  filter(Micro == "Fungi", Depth == "D4")
anova_result_FD4 <- aov(Marginal ~ Theory, data = Multiple_FD4)
tukey_result_FD4 <- TukeyHSD(anova_result_FD4 )
print(tukey_result_FD4)



#Figure S5 Variance of the elevational diversity gradients of soil microbes explained by 
#environmental filtering factors
Multiple_Over <- read.table("clipboard",header=T)#load result data
Multiple_bacOver <- ggplot(Multiple_Over %>%
                             filter(Micro == "Bacteria", Depth == "allOver") %>%
                             mutate(Theory = factor(Theory,
                                                    levels = c("Energy", "Plant", "Soil", "Soilpl", "Soilenpl"),
                                                    labels = c("Energy", "Plant SR", "Soil", "Soil_Plant", "Energy_Plant_Soil"))),
                           (aes(Theory, MarginalR))) +
  
  theme(panel.background = element_rect(color = "grey70"))+
  
  stat_slab(aes(fill = after_stat(level)), .width = c(.66, .95, 1)) +
  stat_pointinterval() +
  scale_fill_manual(values = c("grey80", "grey70", "grey65"))+
  stat_summary(fun = mean, 
               geom = "line", 
               aes(group = 1), 
               color = "gray",  
               size = 0.5) +
  stat_summary(fun = mean, 
               geom = "point", 
               aes(group = 1), 
               color = "gray30", 
               shape = 19, 
               size = 3) +
  
  scale_y_continuous(limits = c(0.1, 0.94), breaks = c( 0.2,0.5, 0.8)) +
  labs(y = "Variance explained (%)\n(Bacteria)",
       x = "",
       title = "All depths") +
  theme_bw(base_size = 11.5) +
  theme(element_line(color = "grey80", size = 0.25),
        legend.position = c(0.87,0.35),
        legend.key.size = unit(5, "mm")) +
  theme(panel.grid = element_blank())+
  theme(strip.background = element_rect(colour = NA, fill = NA),
        axis.line = element_line(arrow = arrow(length = unit(0.2, "cm")),
                                 linewidth = 0.25),
        axis.text.x = element_blank(),
        axis.text.y = element_text(angle = 0, size = 10),
        plot.title = element_text(size = 12, hjust = 0.5))

Multiple_bacOver

Multiple_funOver <- ggplot(Multiple_Over %>%
                             filter(Micro == "Fungi", Depth == "allOver") %>%
                             mutate(Theory = factor(Theory,
                                                    levels = c("Energy", "Plant", "Soil", "Soilpl", "Soilenpl"),
                                                    labels = c("Energy", "Plant SR", "Soil", "Soil_Plant", "Energy_Plant_Soil"))),
                           (aes(Theory, MarginalR))) +
  
  theme(panel.background = element_rect(color = "grey70"))+
  
  stat_slab(aes(fill = after_stat(level)), .width = c(.66, .95, 1)) +
  stat_pointinterval() +
  scale_fill_manual(values = c("grey80", "grey70", "grey65"))+
  stat_summary(fun = mean, 
               geom = "line", 
               aes(group = 1), 
               color = "gray",  
               size = 0.5) +
  
  (修改后)
  stat_summary(fun = mean, 
               geom = "point", 
               aes(group = 1), 
               color = "gray30", 
               shape = 19, 
               size = 3) +
  
  scale_y_continuous(limits = c(0.0, 0.75), breaks = c( 0.0,0.3, 0.6)) +
  labs(y = "Variance explained (%)\n(Fungi)",
       x = "",
       title = "") +
  theme_bw(base_size = 11.5) +
  theme(element_line(color = "grey80", size = 0.25),
        legend.position = "none",
        legend.key.size = unit(5, "mm")) +
  theme(panel.grid = element_blank())+
  theme(strip.background = element_rect(colour = NA, fill = NA),
        axis.line = element_line(arrow = arrow(length = unit(0.2, "cm")),
                                 linewidth = 0.25),
        axis.text.x = element_text(angle = 30, size = 10,hjust = 0.5),
        axis.text.y = element_text(angle = 0, size = 10),
        plot.title = element_text(size = 12, hjust = 0.5))

Multiple_funOver

#_________________________by soil depth______________________________________________
Multiple_per <- read.table("clipboard",header=T)#load result data

Multiple_bacspec <- ggplot(Multiple_per %>% filter(Micro == "Bacteria")%>%
                             mutate(Theory = factor(Theory,
                                                    levels = c("Energy", "Plant", "Soil", "Soilpl", "Soilenpl"),
                                                    labels = c("Energy", "Plant SR", "Soil", "Soil_Plant", "Energy_Plant_Soil")))%>%
                             mutate(Depth = factor(Depth,
                                                   levels = c("D1","D2", "D3", "D4"),
                                                   labels = c( "0-5","5-15", "15-30", "30-50"))),
                           aes(SDepth1, Mean,group=Depth)) +
  geom_vline(xintercept = 3, linetype = "dashed", color = "gray", size = 0.2) +
  geom_vline(xintercept = 6.5, linetype = "dashed", color = "gray", size = 0.2) +
  geom_vline(xintercept = 10, linetype = "dashed", color = "gray", size = 0.2) +
  geom_vline(xintercept = 13.5, linetype = "dashed", color = "gray", size = 0.2) +
 
  geom_line(aes(group = Depth, color = Depth), size = 0.5) +
 
  geom_point(aes(color = Depth), size = 2, alpha = 0.8, shape = 16, stroke = 1.2) +
  
  #geom_errorbar(aes(ymin = ci_lower, ymax = ci_upper, color = Depth), width = 0.45) +
  geom_linerange(data = . %>% filter(conf_level == "0.66"), 
                 aes(ymin = ci_lower, ymax = ci_upper, color = Depth), 
                 size = 1.3) + 
  
  geom_linerange(data = . %>% filter(conf_level == "0.95"), 
                 aes(ymin = ci_lower, ymax = ci_upper, color = Depth), 
                 size = 0.3) + 
  
  scale_color_manual(values = c("0-5"="#7f2704", "5-15"="#d94801", "15-30"="#fd8d3c",
                                "30-50"="#fdd0a2"),
                     name = "Soil depth (cm)") +
  scale_y_continuous(limits = c(0.1, 0.94), breaks = c(0.2, 0.5, 0.8)) +
  scale_x_continuous(limits = c(0.0, 16.5), breaks = c( 3,6.5, 10,13.5)) +
  #scale_shape_manual(values = c(16, 17, 15),  
  # name = "Theory") +
  labs(x = "",
       y = " ",
       title = "By soil depth") +
  theme_bw(base_size = 11.5) +
  theme(panel.grid = element_blank(),
        legend.position = c(0.8,0.2),
        legend.key.size = unit(5, "mm")) +
  theme(strip.background = element_rect(colour = NA, fill = NA),
        axis.line = element_line(arrow = arrow(length = unit(0.2, "cm")),
                                 linewidth = 0.25),
        axis.text.x = element_blank(),
        axis.text.y = element_blank(),
        plot.title = element_text(size = 12, hjust = 0.5))


Multiple_bacspec
print(Multiple_bacspec)


Multiple_funspec <- ggplot(Multiple_per %>% filter(Micro == "Fungi")%>%
                             mutate(Theory = factor(Theory,
                                                    levels = c("Energy", "Plant", "Soil", "Soilpl", "Soilenpl"),
                                                    labels = c("Energy", "Plant SR", "Soil", "Soil_Plant", "Energy_Plant_Soil")))%>%
                             mutate(Depth = factor(Depth,
                                                   levels = c("D1","D2", "D3", "D4"),
                                                   labels = c( "0-5","5-15", "15-30", "30-50"))),
                           aes(SDepth1, Mean,group=Depth)) +
  geom_vline(xintercept = 3, linetype = "dashed", color = "gray", size = 0.2) +
  geom_vline(xintercept = 6.5, linetype = "dashed", color = "gray", size = 0.2) +
  geom_vline(xintercept = 10, linetype = "dashed", color = "gray", size = 0.2) +
  geom_vline(xintercept = 13.5, linetype = "dashed", color = "gray", size = 0.2) +
 
  geom_line(aes(group = Depth, color = Depth), size = 0.5) +
 
  geom_point(aes(color = Depth), size = 2, alpha = 0.8, shape = 16, stroke = 1.2) +
  
  #geom_errorbar(aes(ymin = ci_lower, ymax = ci_upper, color = Depth), width = 0.45) +
  geom_linerange(data = . %>% filter(conf_level == "0.66"), 
                 aes(ymin = ci_lower, ymax = ci_upper, color = Depth), 
                 size = 1.3) + 
  
  geom_linerange(data = . %>% filter(conf_level == "0.95"), 
                 aes(ymin = ci_lower, ymax = ci_upper, color = Depth), 
                 size = 0.3) + 
  
  scale_color_manual(values = c("0-5"="#7f2704", "5-15"="#d94801", "15-30"="#fd8d3c",
                                "30-50"="#fdd0a2"),
                     name = "Soil depth (cm)") +
  scale_y_continuous(limits = c(0.0, 0.75), breaks = c( 0.0,0.3, 0.6)) +
  scale_x_continuous(limits = c(0.0, 16.5), breaks = c( 3,6.5, 10,13.5)) +
  #scale_shape_manual(values = c(16, 17, 15),  
  # name = "Theory") +
  labs(x = "",
       y = " ",
       title = "") +
  theme_bw(base_size = 11.5) +
  theme(panel.grid = element_blank(),
        legend.position = "none",
        legend.key.size = unit(5, "mm")) +
  theme(strip.background = element_rect(colour = NA, fill = NA),
        axis.line = element_line(arrow = arrow(length = unit(0.2, "cm")),
                                 linewidth = 0.25),
        axis.text.x = element_text(angle = 30, size = 10,hjust = 0.5),
        axis.text.y = element_blank(),
        plot.title = element_text(size = 12, hjust = 0.5))


Multiple_funspec
print(Multiple_funspec)

plot_grid(Multiple_bacOver, Multiple_bacspec, Multiple_funOver, Multiple_funspec,
          labels = c("a)", "b)", "c)", "d)"),
          label_x = .2,
          label_y = .95,
          align = "hv")

ggsave("./supplement/Figure S5 Multiple theory maginal R2 by bootstrap.pdf",
       width = 180, height = 195, units = "mm")
#Figure S6 Relative importance of environmental filtering factors to the elevational 
#diversity gradients of soil microbes across soil depths

HypR2 <- read.table("clipboard",header=T)#load result data

HypR2a <- HypR2 %>%
  data.frame() %>%
  mutate(Factor = factor(Theory,
                         levels = c( "PlantSR", "Energy","Soil"),
                         labels = c("Plant SR", "Energy","Soil"))) %>%
  mutate(Depth = factor(Depth,
                        levels = c("Overall", "0-5cm", "5-15cm", 
                                   "15-30cm", "30-50cm"),
                        labels = c("All depth","0-5 cm", "5-15 cm", 
                                   "15-30 cm","30-50 cm"))) %>%
  ggplot(aes(Factor, Individual)) +
  geom_bar(stat = "identity", position = "stack", alpha = .66,
           width = .75) +
  coord_flip() +
  scale_color_manual(values = c("grey40")) +
  scale_fill_manual(values = c("grey40"),
                    name = "") +
  scale_y_continuous(lim = c(0, 0.6),
                     breaks = c(0, 0.3, 0.6)) +
  labs(y = "Individual importance", x = "",
       title = "",
       subtitle = "") +
  theme_bw(base_size = 12.5) +
  theme(panel.grid = element_blank(),
        axis.text.y.left = element_text(size = 12, angle = 0),
        axis.text.y = element_text(size = 10, angle = 0),
        axis.ticks.y.right = element_line(),
        axis.text = element_text(size = 12),
        axis.line.x.top = element_blank(),
        axis.text.x.top = element_text(size = 10, angle = 0),  
        #axis.text.x = element_text(size = 10,angle=180),
        plot.title = element_text(hjust = 0.5)) +
  geom_text(aes(x = Factor , y = .53, label = round(Individual, 2))) +
  theme(panel.grid = element_blank(),
        panel.background = element_blank(),
        panel.border = element_rect(fill = NA, color = "grey40"),
        strip.text = element_text(size = 12),
        strip.background = element_blank(),
        legend.position =  "none") +
  facet_grid(rows = vars(Depth),cols = vars(Micro))

HypR2a

ggsave("./supplement/Figure S6_Theoritical R2.pdf",
       width = 180, height = 165, units = "mm")

#___________________R2 Hierarchical partitioning for specific factor________________________

#___________________energy___________________________
#Figure S7 Relative importance of different energy factors to the elevational diversity 
#gradients of soil microbes across soil depths.
#_________________Thermal and chemical energy availability______________________

EnergyFactor1 <- read.table("clipboard",header=T)#load result data

EnergyfactorP1B <- EnergyFactor1 %>%filter(Micro == "Bacteria") %>%
  data.frame() %>%
  mutate(Factor = factor(Factor,
                         levels = c(  "Chemical","Thermal"),
                         labels = c( "Chemical","Thermal"))) %>%
  mutate(Depth = factor(Depth,
                        levels = c("Overall", "0-5cm", "5-15cm", 
                                   "15-30cm", "30-50cm"),
                        labels = c("Overall","0-5 cm", "5-15 cm", 
                                   "15-30 cm","30-50 cm"))) %>%
  ggplot(aes(Factor, Individual)) +
  geom_bar(stat = "identity", position = "stack", alpha = .66,
           width = .75) +
  coord_flip() +
  scale_color_manual(values = c("grey40")) +
  scale_fill_manual(values = c("grey40"),
                    name = "") +
  scale_y_continuous(lim = c(-0.05, 0.5),
                     breaks = c(0, 0.2, 0.4)) +
  labs(y = "Individual importance", x = "",
       title = "",
       subtitle = "") +
  theme_bw(base_size = 12.5) +
  theme(panel.grid = element_blank(),
        axis.line = element_line(arrow = arrow(length = unit(0.2, "cm")),
                                 linewidth = 0.25),
        axis.text.y.left = element_text(size = 12, angle = 0),
        axis.text.y = element_text(size = 10, angle = 0),
        axis.ticks.y.right = element_line(),
        axis.text = element_text(size = 12),
        axis.line.x.top = element_blank(),
        axis.text.x.top = element_text(size = 10, angle = 0),  
        #axis.text.x = element_text(size = 10,angle=180),
        plot.title = element_text(hjust = 0.5)) +
  geom_text(aes(x = Factor , y = .43, label = round(Individual, 2))) +
  theme(panel.grid = element_blank(),
        panel.background = element_blank(),
        panel.border = element_rect(fill = NA, color = "grey40"),
        strip.text = element_text(size = 12),
        strip.text.y = element_blank(),  
        strip.background = element_blank(),
        legend.position =  "none") +
  facet_grid(rows = vars(Depth),cols = vars(Micro))
EnergyfactorP1B

###___________________fungi_______________________________________

EnergyfactorP1F <- EnergyFactor1 %>%filter(Micro == "Fungi") %>%
  data.frame() %>%
  mutate(Factor = factor(Factor,
                         levels = c(  "Chemical","Thermal"),
                         labels = c( "Chemical","Thermal"))) %>%
  mutate(Depth = factor(Depth,
                        levels = c("Overall", "0-5cm", "5-15cm", 
                                   "15-30cm", "30-50cm"),
                        labels = c("Overall","0-5 cm", "5-15 cm", 
                                   "15-30 cm","30-50 cm"))) %>%
  ggplot(aes(Factor, Individual)) +
  geom_bar(stat = "identity", position = "stack", alpha = .66,
           width = .75) +
  coord_flip() +
  scale_color_manual(values = c("grey40")) +
  scale_fill_manual(values = c("grey40"),
                    name = "") +
  scale_y_continuous(lim = c(-0.05, 0.5),
                     breaks = c(0, 0.2, 0.4)) +
  labs(y = "Individual importance", x = "",
       title = "",
       subtitle = "") +
  theme_bw(base_size = 12.5) +
  theme(panel.grid = element_blank(),
        axis.line = element_line(arrow = arrow(length = unit(0.2, "cm")),
                                 linewidth = 0.25),
        axis.text.y.left = element_text(size = 12, angle = 0),
        axis.text.y = element_text(size = 10, angle = 0),
        axis.ticks.y.right = element_line(),
        axis.text = element_text(size = 12),
        axis.line.x.top = element_blank(),
        axis.text.x.top = element_text(size = 10, angle = 0),  
        #axis.text.x = element_text(size = 10,angle=180),
        plot.title = element_text(hjust = 0.5)) +
  geom_text(aes(x = Factor , y = .43, label = round(Individual, 2))) +
  theme(panel.grid = element_blank(),
        panel.background = element_blank(),
        panel.border = element_rect(fill = NA, color = "grey40"),
        strip.text = element_text(size = 12),
        strip.text.y = element_blank(),  
        strip.background = element_blank(),
        legend.position =  "none") +
  facet_grid(rows = vars(Depth),cols = vars(Micro))
EnergyfactorP1F



ggsave("./supplement/Figure S7a_Thermal and chemical Energy factor R2.pdf",
       width = 180, height = 180, units = "mm")

#_________________Energy factors______________________

EnergyFactor <- read.table("clipboard",header=T)#load result data

EnergyfactorPB <- EnergyFactor %>%filter(Micro == "Bacteria") %>%
  data.frame() %>%
  mutate(Factor = factor(Factor,
                         levels = c(  "SOC","NPP", "ST","MAT1"),
                         labels = c( "SOC","NPP", "ST","MAT"))) %>%
  mutate(Depth = factor(Depth,
                        levels = c("Overall", "0-5cm", "5-15cm", 
                                   "15-30cm", "30-50cm"),
                        labels = c("Overall","0-5 cm", "5-15 cm", 
                                   "15-30 cm","30-50 cm"))) %>%
  ggplot(aes(Factor, Individual)) +
  geom_bar(stat = "identity", position = "stack", alpha = .66,
           width = .75) +
  coord_flip() +
  scale_color_manual(values = c("grey40")) +
  scale_fill_manual(values = c("grey40"),
                    name = "") +
  scale_y_continuous(lim = c(-0.05, 0.5),
                     breaks = c(0, 0.2, 0.4)) +
  labs(y = "Individual importance", x = "",
       title = "",
       subtitle = "") +
  theme_bw(base_size = 12.5) +
  theme(panel.grid = element_blank(),
        axis.line = element_line(arrow = arrow(length = unit(0.2, "cm")),
                                 linewidth = 0.25),
        axis.text.y.left = element_text(size = 12, angle = 0),
        axis.text.y = element_text(size = 10, angle = 0),
        axis.ticks.y.right = element_line(),
        axis.text = element_text(size = 12),
        axis.line.x.top = element_blank(),
        axis.text.x.top = element_text(size = 10, angle = 0),  
        #axis.text.x = element_text(size = 10,angle=180),
        plot.title = element_text(hjust = 0.5)) +
  geom_text(aes(x = Factor , y = .43, label = round(Individual, 2))) +
  theme(panel.grid = element_blank(),
        panel.background = element_blank(),
        panel.border = element_rect(fill = NA, color = "grey40"),
        strip.text = element_text(size = 12),
        strip.text.y = element_blank(),  
        strip.background = element_blank(),
        legend.position =  "none") +
  facet_grid(rows = vars(Depth),cols = vars(Micro))
EnergyfactorPB

#______________________________fungi_________________________________________
EnergyfactorPF <- EnergyFactor %>%filter(Micro == "Fungi") %>%
  data.frame() %>%
  mutate(Factor = factor(Factor,
                         levels = c(  "SOC","NPP", "ST","MAT1"),
                         labels = c( "SOC","NPP", "ST","MAT"))) %>%
  mutate(Depth = factor(Depth,
                        levels = c("Overall", "0-5cm", "5-15cm", 
                                   "15-30cm", "30-50cm"),
                        labels = c("Overall","0-5 cm", "5-15 cm", 
                                   "15-30 cm","30-50 cm"))) %>%
  ggplot(aes(Factor, Individual)) +
  geom_bar(stat = "identity", position = "stack", alpha = .66,
           width = .75) +
  coord_flip() +
  scale_color_manual(values = c("grey40")) +
  scale_fill_manual(values = c("grey40"),
                    name = "") +
  scale_y_continuous(lim = c(-0.05, 0.5),
                     breaks = c(0, 0.2, 0.4)) +
  labs(y = "Individual importance", x = "",
       title = "",
       subtitle = "") +
  theme_bw(base_size = 12.5) +
  theme(panel.grid = element_blank(),
        axis.line = element_line(arrow = arrow(length = unit(0.2, "cm")),
                                 linewidth = 0.25),
        axis.text.y.left = element_text(size = 12, angle = 0),
        axis.text.y = element_text(size = 10, angle = 0),
        axis.ticks.y.right = element_line(),
        axis.text = element_text(size = 12),
        axis.line.x.top = element_blank(),
        axis.text.x.top = element_text(size = 10, angle = 0),  
        #axis.text.x = element_text(size = 10,angle=180),
        plot.title = element_text(hjust = 0.5)) +
  geom_text(aes(x = Factor , y = .43, label = round(Individual, 2))) +
  theme(panel.grid = element_blank(),
        panel.background = element_blank(),
        panel.border = element_rect(fill = NA, color = "grey40"),
        strip.text = element_text(size = 12),
        strip.text.y = element_blank(),  
        strip.background = element_blank(),
        legend.position =  "none") +
  facet_grid(rows = vars(Depth),cols = vars(Micro))
EnergyfactorPF



plot_grid(EnergyfactorP1B,EnergyfactorPB,EnergyfactorP1F, EnergyfactorPF,
          labels = c("", ""),
          label_x = 0,
          label_y = 1,
          nrow = 1,    # 指定行数
          align = "4")
ggsave("./supplement/Figure S7_Energy all.pdf",
       width = 240, height = 165, units = "mm")

#______________soil______________
#Figure S8. Relative importance of different abiotic soil filters to shape the elevational 
#diversity gradients of soil microbes

#_________________________abiotic soil filter__________________________________
SoilR2 <- read.table("clipboard",header=T)#load result data

SoilR2a <- SoilR2 %>%
  data.frame() %>%
  mutate(Factor = factor(Factor,
                         levels = c(  "SWC","pH", "EC"),
                         labels = c(  "SWC","pH", "EC"))) %>%
  mutate(Depth = factor(Depth,
                        levels = c("Overall", "0-5cm", "5-15cm", 
                                   "15-30cm", "30-50cm"),
                        labels = c("Overall","0-5 cm", "5-15 cm", 
                                   "15-30 cm","30-50 cm"))) %>%
  ggplot(aes(Factor, Individual)) +
  geom_bar(stat = "identity", position = "stack", alpha = .66,
           width = .75) +
  coord_flip() +
  scale_color_manual(values = c("grey40")) +
  scale_fill_manual(values = c("grey40"),
                    name = "") +
  scale_y_continuous(lim = c(0, 0.5),
                     breaks = c(0, 0.2, 0.4)) +
  labs(y = "Individual importance", x = "",
       title = "",
       subtitle = "") +
  theme_bw(base_size = 12.5) +
  theme(panel.grid = element_blank(),
        axis.line = element_line(arrow = arrow(length = unit(0.2, "cm")),
                                 linewidth = 0.25),
        axis.text.y.left = element_text(size = 12, angle = 0),
        axis.text.y = element_text(size = 10, angle = 0),
        axis.ticks.y.right = element_line(),
        axis.text = element_text(size = 12),
        axis.line.x.top = element_blank(),
        axis.text.x.top = element_text(size = 10, angle = 0),  # 修改这里
        #axis.text.x = element_text(size = 10,angle=180),
        plot.title = element_text(hjust = 0.5)) +
  geom_text(aes(x = Factor , y = .43, label = round(Individual, 2))) +
  theme(panel.grid = element_blank(),
        panel.background = element_blank(),
        panel.border = element_rect(fill = NA, color = "grey40"),
        strip.text = element_text(size = 12),
        strip.background = element_blank(),
        legend.position =  "none") +
  facet_grid(rows = vars(Depth),cols = vars(Micro))

SoilR2a

ggsave("./supplement/Figure S8_Abiotic soil R2.pdf",
       width = 180, height = 180, units = "mm")


#__________________________Mixed coefficients____________________________
#Table S11. Summary of the linear mixed-effects models

#calculate coefficients of linear mixed-effects model
summary(bac_All_Over)
summary(bac_All_D1)
summary(bac_All_D2)
summary(bac_All_D3)
summary(bac_All_D4)

summary(fun_All_Over)
summary(fun_All_D1)
summary(fun_All_D2)
summary(fun_All_D3)
summary(fun_All_D4)

#Plot results
#Figure S9. Impacts of environmental filtering factors on the elevational diversity
Mix_plot <- read.table("clipboard",header=T)#load  data

Mix_bac <-  Mix_plot %>% filter(Micro == "Bacteria") %>%
  mutate(Depth = factor(Depth,
                        levels = c("Overall","0-5cm", "5-15cm", "15-30cm", "30-50cm"),
                        labels = c("All depths","0-5 cm", "5-15 cm", "15-30 cm", "30-50 cm"))) %>%
  mutate(Factor = factor(Factor, 
                         levels = c("8SWC","7pH", "6EC", "5PlantSR", "4SOC","3NPP","2ST","1MAT"),
                         labels = c("SWC","pH", "EC", "Plant SR Plant SR", "SOC","NPP","ST","MAT"))) %>%
  mutate(Factor1 = factor(fct_reorder(Factor1, Estimate))) %>% 
  
  mutate(sig.signs = ifelse(Estimate < 0 & Estimate + 2*Std.Error < 0, "sig.neg", 
                            ifelse(Estimate > 0 & Estimate - 2*Std.Error > 0, "sig.pos", "neut"))) %>%
  mutate(sig.signs = factor(sig.signs,
                            levels = c("sig.neg", "neut", "sig.pos"))) %>% 
  ggplot(aes(Factor, Estimate)) +
  geom_hline(aes(yintercept = 0), color = "grey") +
  geom_linerange(aes(ymin = Estimate - 2*Std.Error,
                     ymax = Estimate + 2*Std.Error),
                 size = 0.2) +
  geom_linerange(aes(ymin = Estimate - Std.Error,
                     ymax = Estimate + Std.Error),
                 size = 0.8) +
  geom_point(aes(color = sig.signs), size = 2.5) +
  scale_color_manual(values = c("red", "grey", "black")) +
  facet_grid(~ Depth) +
  coord_flip() +
  labs(x = "", y = "Standardized coefficients (Bacteria)") +
  scale_y_continuous(lim = c(-0.4, 0.3),
                     breaks = c(-0.2, 0.0, 0.2)) +
  theme_bw(base_size = 11.5) +
  theme(panel.grid = element_blank(),
        legend.position = 'none',
        strip.background = element_blank(),
        axis.line.x = element_line(arrow = arrow(length = unit(0.2, "cm")), linewidth = 0.25),
        axis.line.y = element_line(arrow = arrow(length = unit(0.2, "cm")), linewidth = 0.25)+
  facet_grid(~ Depth, scales = "free_x", space = "free_x") )
Mix_bac


Mix_fun <-  Mix_plot %>% filter(Micro == "Fungi") %>%
  mutate(Depth = factor(Depth,
                        levels = c("Overall","0-5cm", "5-15cm", "15-30cm", "30-50cm"),
                        labels = c("All depths","0-5 cm", "5-15 cm", "15-30 cm", "30-50 cm"))) %>%
  mutate(Factor = factor(Factor, 
                         levels = c("8SWC","7pH", "6EC", "5PlantSR", "4SOC","3NPP","2ST","1MAT"),
                         labels = c("SWC","pH", "EC", "Plant SR Plant SR", "SOC","NPP","ST","MAT"))) %>%
  mutate(Factor1 = factor(fct_reorder(Factor1, Estimate))) %>% 
  
  mutate(sig.signs = ifelse(Estimate < 0 & Estimate + 2*Std.Error < 0, "sig.neg", 
                            ifelse(Estimate > 0 & Estimate - 2*Std.Error > 0, "sig.pos", "neut"))) %>%
  mutate(sig.signs = factor(sig.signs,
                            levels = c("sig.neg", "neut", "sig.pos"))) %>% 
  ggplot(aes(Factor, Estimate)) +
  geom_hline(aes(yintercept = 0), color = "grey") +
  geom_linerange(aes(ymin = Estimate - 2*Std.Error,
                     ymax = Estimate + 2*Std.Error),
                 size = 0.2) +
  geom_linerange(aes(ymin = Estimate - Std.Error,
                     ymax = Estimate + Std.Error),
                 size = 0.8) +
  geom_point(aes(color = sig.signs), size = 2.5) +
  scale_color_manual(values = c("red", "grey", "black")) +
  facet_grid(~ Depth) +
  coord_flip() +
  labs(x = "", y = "Standardized coefficients (Fungi)") +
  scale_y_continuous(lim = c(-0.95, 0.84),
                     breaks = c(-0.7, 0.0, 0.7)) +
  theme_bw(base_size = 11.5) +
  theme(panel.grid = element_blank(),
        legend.position = c(0.8,0.5),
        strip.background = element_blank(),
        axis.line.x = element_line(arrow = arrow(length = unit(0.2, "cm")), linewidth = 0.25),
        axis.line.y = element_line(arrow = arrow(length = unit(0.2, "cm")), linewidth = 0.25)+  
        facet_grid(~ Depth, scales = "free_x", space = "free_x") )
Mix_fun
plot_grid(Mix_bac, Mix_fun,
          labels = c("a)", "b)"),
          label_x = 0,
          label_y = 1,
          nrow = 2,    # 指定行数
          align = "hv")

ggsave("./supplement/Figure S9_Mixed.pdf",
       width = 180, height = 165, units = "mm")

####################################################################
#Figure  S10 Bacteria SEM
#_________________________bacOver______________________________
#data Preparation
SEM_dat <- read.table("clipboard",header=T)
bac_dat = filter(SEM_dat, Micro == "Bacteria")
fun_dat = filter(SEM_dat, Micro == "Fungi")

bacOver_dat = filter(bac_dat, Depth == "Overall")
bacOver_dat1 <- bacOver_dat %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = as.vector(scale(Elevation)),
         MAT = as.vector(scale(MAT)),
         SoilCom = as.vector(SoilCom),
         EnerCom = as.vector(EnerCom),
         lnP = as.vector(scale(lnP)),
         lnB = as.vector(scale(lnB)))

bacOver_psem <- psem(
  lme(lnB ~Elevation+SoilCom+EnerCom+lnP,random = ~1|Replicate, 
      data = bacOver_dat1),
  lme(lnP~Elevation+SoilCom+EnerCom, random = ~1|Replicate, 
      data = bacOver_dat1),
  lme(EnerCom~Elevation,random = ~1|Replicate, 
      data = bacOver_dat1),
  lme(SoilCom~Elevation,random = ~1|Replicate, 
      data = bacOver_dat1))


fixed_BO <- fixef(bacOver_psem[[1]])
summary(bacOver_psem, standardized = T, rsq = T)

#_________________________bacD1___________________________________
bacD1_dat <- filter(bac_dat , Depth == "D1")

bacD1_dat1 <- bacD1_dat %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = as.vector(scale(Elevation)),
         MAT = as.vector(scale(MAT)),
         SoilCom = as.vector(SoilCom),
         EnerCom = as.vector(EnerCom),
         lnP = as.vector(scale(lnP)),
         lnB = as.vector(scale(lnB)))

bacD1_psem <- psem(
  lme(lnB ~Elevation+SoilCom+EnerCom+lnP,random = ~1|Replicate, 
      data = bacD1_dat1),
  lme(lnP~Elevation+SoilCom+EnerCom, random = ~1|Replicate, 
      data = bacD1_dat1),
  lme(EnerCom~Elevation,random = ~1|Replicate, 
      data = bacD1_dat1),
  lme(SoilCom~Elevation,random = ~1|Replicate, 
      data = bacD1_dat1))
summary(bacD1_psem, standardized = T, rsq = T)


#_________________________bacD2___________________________________
bacD2_dat <- filter(bac_dat , Depth == "D2")
bacD2_dat1 <- bacD2_dat %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = as.vector(scale(Elevation)),
         MAT = as.vector(scale(MAT)),
         SoilCom = as.vector(SoilCom),
         EnerCom = as.vector(EnerCom),
         lnP = as.vector(scale(lnP)),
         lnB = as.vector(scale(lnB)))

bacD2_psem <- psem(
  lme(lnB ~Elevation+SoilCom+EnerCom+lnP,random = ~1|Replicate, 
      data = bacD2_dat1),
  lme(lnP~Elevation+SoilCom+EnerCom, random = ~1|Replicate, 
      data = bacD2_dat1),
  lme(EnerCom~Elevation,random = ~1|Replicate, 
      data = bacD2_dat1),
  lme(SoilCom~Elevation,random = ~1|Replicate, 
      data = bacD2_dat1))
summary(bacD2_psem, standardized = T, rsq = T)

#_________________________bacD3___________________________________
bacD3_dat <- filter(bac_dat , Depth == "D3")

bacD3_dat1 <- bacD3_dat %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = as.vector(scale(Elevation)),
         MAT = as.vector(scale(MAT)),
         SoilCom = as.vector(SoilCom),
         EnerCom = as.vector(EnerCom),
         lnP = as.vector(scale(lnP)),
         lnB = as.vector(scale(lnB)))

bacD3_psem <- psem(
  lme(lnB ~Elevation+SoilCom+EnerCom+lnP,random = ~1|Replicate, 
      data = bacD3_dat1),
  lme(lnP~Elevation+SoilCom+EnerCom, random = ~1|Replicate, 
      data = bacD3_dat1),
  lme(EnerCom~Elevation,random = ~1|Replicate, 
      data = bacD3_dat1),
  lme(SoilCom~Elevation,random = ~1|Replicate, 
      data = bacD3_dat1))
summary(bacD3_psem, standardized = T, rsq = T)

#_________________________bacD4___________________________________
bacD4_dat <- filter(bac_dat , Depth == "D4")

bacD4_dat1 <- bacD4_dat %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = as.vector(scale(Elevation)),
         MAT = as.vector(scale(MAT)),
         SoilCom = as.vector(SoilCom),
         EnerCom = as.vector(EnerCom),
         lnP = as.vector(scale(lnP)),
         lnB = as.vector(scale(lnB)))

bacD4_psem <- psem(
  lme(lnB ~Elevation+SoilCom+EnerCom+lnP,random = ~1|Replicate, 
      data = bacD4_dat1),
  lme(lnP~Elevation+SoilCom+EnerCom, random = ~1|Replicate, 
      data = bacD4_dat1),
  lme(EnerCom~Elevation,random = ~1|Replicate, 
      data = bacD4_dat1),
  lme(SoilCom~Elevation,random = ~1|Replicate, 
      data = bacD4_dat1))
summary(bacD4_psem, standardized = T, rsq = T)

#Figure  S11 Fungi SEM
#__________________funOver_____________________________________
funOver_dat <- filter(fun_dat , Depth == "Overall")
##
funOver_dat1 <- funOver_dat %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = as.vector(scale(Elevation)),
         MAT = as.vector(scale(MAT)),
         SoilCom = as.vector(SoilCom),
         EnerCom = as.vector(EnerCom),
         lnP = as.vector(scale(lnP)),
         lnB = as.vector(scale(lnB)))

funOver_psem <- psem(
  lme(lnB ~Elevation+SoilCom+EnerCom+lnP,random = ~1|Replicate, 
      data = funOver_dat1),
  lme(lnP~Elevation+SoilCom+EnerCom, random = ~1|Replicate, 
      data = funOver_dat1),
  lme(EnerCom~Elevation,random = ~1|Replicate, 
      data = funOver_dat1),
  lme(SoilCom~Elevation,random = ~1|Replicate, 
      data = funOver_dat1))

summary(funOver_psem, standardized = T, rsq = T)

#_________________________funD1___________________________________
funD1_dat <- filter(fun_dat , Depth == "D1")
##
funD1_dat1 <- funD1_dat %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = as.vector(scale(Elevation)),
         MAT = as.vector(scale(MAT)),
         SoilCom = as.vector(SoilCom),
         EnerCom = as.vector(EnerCom),
         lnP = as.vector(scale(lnP)),
         lnB = as.vector(scale(lnB)))

funD1_psem <- psem(
  lme(lnB ~Elevation+SoilCom+EnerCom+lnP,random = ~1|Replicate, 
      data = funD1_dat1),
  lme(lnP~Elevation+SoilCom+EnerCom, random = ~1|Replicate, 
      data = funD1_dat1),
  lme(EnerCom~Elevation,random = ~1|Replicate, 
      data = funD1_dat1),
  lme(SoilCom~Elevation,random = ~1|Replicate, 
      data = funD1_dat1))

summary(funD1_psem, standardized = T, rsq = T)

#_________________________funD2___________________________________
funD2_dat <- filter(fun_dat , Depth == "D2")
##
funD2_dat1 <- funD2_dat %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = as.vector(scale(Elevation)),
         MAT = as.vector(scale(MAT)),
         SoilCom = as.vector(SoilCom),
         EnerCom = as.vector(EnerCom),
         lnP = as.vector(scale(lnP)),
         lnB = as.vector(scale(lnB)))

funD2_psem <- psem(
  lme(lnB ~Elevation+SoilCom+EnerCom+lnP,random = ~1|Replicate, 
      data = funD2_dat1),
  lme(lnP~Elevation+SoilCom+EnerCom, random = ~1|Replicate, 
      data = funD2_dat1),
  lme(EnerCom~Elevation,random = ~1|Replicate, 
      data = funD2_dat1),
  lme(SoilCom~Elevation,random = ~1|Replicate, 
      data = funD2_dat1))

summary(funD2_psem, standardized = T, rsq = T)

#_________________________funD3___________________________________
funD3_dat <- filter(fun_dat , Depth == "D3")

funD3_dat1 <- funD3_dat %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = as.vector(scale(Elevation)),
         MAT = as.vector(scale(MAT)),
         SoilCom = as.vector(SoilCom),
         EnerCom = as.vector(EnerCom),
         lnP = as.vector(scale(lnP)),
         lnB = as.vector(scale(lnB)))

funD3_psem <- psem(
  lme(lnB ~Elevation+SoilCom+EnerCom+lnP,random = ~1|Replicate, 
      data = funD3_dat1),
  lme(lnP~Elevation+SoilCom+EnerCom, random = ~1|Replicate, 
      data = funD3_dat1),
  lme(EnerCom~Elevation,random = ~1|Replicate, 
      data = funD3_dat1),
  lme(SoilCom~Elevation,random = ~1|Replicate, 
      data = funD3_dat1))
summary(funD3_psem, standardized = T, rsq = T)

#_________________________funD4___________________________________
funD4_dat <- filter(fun_dat , Depth == "D4")
funD4_dat1 <- funD4_dat %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = as.vector(scale(Elevation)),
         MAT = as.vector(scale(MAT)),
         SoilCom = as.vector(SoilCom),
         EnerCom = as.vector(EnerCom),
         lnP = as.vector(scale(lnP)),
         lnB = as.vector(scale(lnB)))

funD4_psem <- psem(
  lme(lnB ~Elevation+SoilCom+EnerCom+lnP,random = ~1|Replicate, 
      data = funD4_dat1),
  lme(lnP~Elevation+SoilCom+EnerCom, random = ~1|Replicate, 
      data = funD4_dat1),
  lme(EnerCom~Elevation,random = ~1|Replicate, 
      data = funD4_dat1),
  lme(SoilCom~Elevation,random = ~1|Replicate, 
      data = funD4_dat1))
summary(funD4_psem, standardized = T, rsq = T)

# stochastic and niche-based processes shaping microbial diversity
library(picante)
#stochastic processes_null model
#bacteria
B16SOTU<- read.table("clipboard",header=T)
B16SOTU<- as.matrix(B16SOTU)
set.seed(123)
null_models16S <- randomizeMatrix(B16SOTU, null.model = "frequency", iterations = 1000)
write.csv(null_models16S, "./null_models16S1.csv", row.names = TRUE)

#fungi
ITSOTU<- read.table("clipboard",header=T)
ITSOTU<- as.matrix(ITSOTU)
set.seed(123)
null_modelsITS <- randomizeMatrix(ITSOTU, null.model = "frequency", iterations = 1000)
write.csv(null_modelsITS1, "./null_modelsITS1.csv", row.names = TRUE)

#Prediction and hierarchical partitioning of maginal R2 
dat_null <- read.table("clipboard",header=T)#load  data

bac_null <- dat_null %>%filter(Microbe == "bacteria")
fun_null <- dat_null %>%filter(Microbe == "fungi")
#bacteria
#all depths
bacOver_null<- filter(bac_null, Depth == "Overall")
bacOver_null1 <-bacOver_null %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAP = scale(MAP),
         MAT = scale(MAT),
         AET = scale(AET),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP) )
#hierarchical partitioning of maginal R2
bac_Over_null <- lme(lnB ~ Null  +  MAT  + NPP + SOC + pH 
               + EC + ST + SWC +lnP,
               random = (~1|Elevation/Replicate),
               data = bacOver_null1)

glmm.hp(bac_Over_null)
(bac_Over_null1<-glmm.hp(bac_Over_null,commonality=TRUE))
#predition
bac_Over_Det <- lme(lnB ~ MAT  + NPP + SOC + pH 
                     + EC + ST + SWC +lnP,
                     random = (~1|Elevation/Replicate),
                     data = bacOver_null1)
Prbac_Over_Det <- predict(bac_Over_Det, type="response",newdata = bacOver_null1)
write.csv(Prbac_Over_Det, "./supplement/Prbac_Over_Det.csv", row.names = TRUE)

bac_Over_Sto <- lme(lnB ~ Null,
                    random = (~1|Elevation/Replicate),
                    data = bacOver_null1)
Prbac_Over_Sto <- predict(bac_Over_Sto, type="response",newdata = bacOver_null1)
write.csv(Prbac_Over_Sto, "./supplement/Prbac_Over_Sto.csv", row.names = TRUE)

#D1
bacD1_null<- filter(bac_null, Depth == "D1")
bacD1_null1 <-bacD1_null %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAP = scale(MAP),
         MAT = scale(MAT),
         AET = scale(AET),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP) )
#hierarchical partitioning of maginal R2
bac_D1_null <- lme(lnB ~ Null  +  MAT  + NPP + SOC + pH 
                     + EC + ST + SWC +lnP,
                     random = (~1|Replicate),
                     data = bacD1_null1)

glmm.hp(bac_D1_null)
(bac_D1_null1<-glmm.hp(bac_D1_null,commonality=TRUE))
#predition
bac_D1_Det <- lme(lnB ~ MAT  + NPP + SOC + pH 
                    + EC + ST + SWC +lnP,
                    random = (~1|Replicate),
                    data = bacD1_null1)
Prbac_D1_Det <- predict(bac_D1_Det, type="response",newdata = bacD1_null1)
write.csv(Prbac_D1_Det, "./supplement/Prbac_D1_Det.csv", row.names = TRUE)

bac_D1_Sto <- lme(lnB ~ Null,
                    random = (~1|Replicate),
                    data = bacD1_null1)
Prbac_D1_Sto <- predict(bac_D1_Sto, type="response",newdata = bacD1_null1)
write.csv(Prbac_D1_Sto, "./supplement/Prbac_D1_Sto.csv", row.names = TRUE)

#D2
bacD2_null<- filter(bac_null, Depth == "D2")
bacD2_null1 <-bacD2_null %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAP = scale(MAP),
         MAT = scale(MAT),
         AET = scale(AET),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP) )
#hierarchical partitioning of maginal R2
bac_D2_null <- lme(lnB ~ Null  +  MAT  + NPP + SOC + pH 
                   + EC + ST + SWC +lnP,
                   random = (~1|Replicate),
                   data = bacD2_null1)

glmm.hp(bac_D2_null)
(bac_D2_null1<-glmm.hp(bac_D2_null,commonality=TRUE))
#predition
bac_D2_Det <- lme(lnB ~ MAT  + NPP + SOC + pH 
                  + EC + ST + SWC +lnP,
                  random = (~1|Replicate),
                  data = bacD2_null1)
Prbac_D2_Det <- predict(bac_D2_Det, type="response",newdata = bacD2_null1)
write.csv(Prbac_D2_Det, "./supplement/Prbac_D2_Det.csv", row.names = TRUE)

bac_D2_Sto <- lme(lnB ~ Null,
                  random = (~1|Replicate),
                  data = bacD2_null1)
Prbac_D2_Sto <- predict(bac_D2_Sto, type="response",newdata = bacD2_null1)
write.csv(Prbac_D2_Sto, "./supplement/Prbac_D2_Sto.csv", row.names = TRUE)

#D3
bacD3_null<- filter(bac_null, Depth == "D3")
bacD3_null1 <-bacD3_null %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAP = scale(MAP),
         MAT = scale(MAT),
         AET = scale(AET),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP) )
#hierarchical partitioning of maginal R2
bac_D3_null <- lme(lnB ~ Null  +  MAT  + NPP + SOC + pH 
                   + EC + ST + SWC +lnP,
                   random = (~1|Replicate),
                   data = bacD3_null1)

glmm.hp(bac_D3_null)
(bac_D3_null1<-glmm.hp(bac_D3_null,commonality=TRUE))
#predition
bac_D3_Det <- lme(lnB ~ MAT  + NPP + SOC + pH 
                  + EC + ST + SWC +lnP,
                  random = (~1|Replicate),
                  data = bacD3_null1)
Prbac_D3_Det <- predict(bac_D3_Det, type="response",newdata = bacD3_null1)
write.csv(Prbac_D3_Det, "./supplement/Prbac_D3_Det.csv", row.names = TRUE)

bac_D3_Sto <- lme(lnB ~ Null,
                  random = (~1|Replicate),
                  data = bacD3_null1)
Prbac_D3_Sto <- predict(bac_D3_Sto, type="response",newdata = bacD3_null1)
write.csv(Prbac_D3_Sto, "./supplement/Prbac_D3_Sto.csv", row.names = TRUE)

#D4
bacD4_null<- filter(bac_null, Depth == "D4")
bacD4_null1 <-bacD4_null %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAP = scale(MAP),
         MAT = scale(MAT),
         AET = scale(AET),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP) )
#hierarchical partitioning of maginal R2
bac_D4_null <- lme(lnB ~ Null  +  MAT  + NPP + SOC + pH 
                   + EC + ST + SWC +lnP,
                   random = (~1|Replicate),
                   data = bacD4_null1)

glmm.hp(bac_D4_null)
(bac_D4_null1<-glmm.hp(bac_D4_null,commonality=TRUE))
#predition
bac_D4_Det <- lme(lnB ~ MAT  + NPP + SOC + pH 
                  + EC + ST + SWC +lnP,
                  random = (~1|Replicate),
                  data = bacD4_null1)
Prbac_D4_Det <- predict(bac_D4_Det, type="response",newdata = bacD4_null1)
write.csv(Prbac_D4_Det, "./supplement/Prbac_D4_Det.csv", row.names = TRUE)

bac_D4_Sto <- lme(lnB ~ Null,
                  random = (~1|Replicate),
                  data = bacD4_null1)
Prbac_D4_Sto <- predict(bac_D4_Sto, type="response",newdata = bacD4_null1)
write.csv(Prbac_D4_Sto, "./supplement/Prbac_D4_Sto.csv", row.names = TRUE)

#fungi
#all depths
funOver_null<- filter(fun_null, Depth == "Overall")
funOver_null1 <-funOver_null %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAP = scale(MAP),
         MAT = scale(MAT),
         AET = scale(AET),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP) )
#hierarchical partitioning of maginal R2
fun_Over_null <- lme(lnB ~ Null  +  MAT  + NPP + SOC + pH 
                     + EC + ST + SWC +lnP,
                     random = (~1|Elevation/Replicate),
                     data = funOver_null1)

glmm.hp(fun_Over_null)
(fun_Over_null1<-glmm.hp(fun_Over_null,commonality=TRUE))
#predition
fun_Over_Det <- lme(lnB ~ MAT  + NPP + SOC + pH 
                    + EC + ST + SWC +lnP,
                    random = (~1|Elevation/Replicate),
                    data = funOver_null1)
Prfun_Over_Det <- predict(fun_Over_Det, type="response",newdata = funOver_null1)
write.csv(Prfun_Over_Det, "./supplement/Prfun_Over_Det.csv", row.names = TRUE)

fun_Over_Sto <- lme(lnB ~ Null,
                    random = (~1|Elevation/Replicate),
                    data = funOver_null1)
Prfun_Over_Sto <- predict(fun_Over_Sto, type="response",newdata = funOver_null1)
write.csv(Prfun_Over_Sto, "./supplement/Prfun_Over_Sto.csv", row.names = TRUE)

#D1
funD1_null<- filter(fun_null, Depth == "D1")
funD1_null1 <-funD1_null %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAP = scale(MAP),
         MAT = scale(MAT),
         AET = scale(AET),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP) )
#hierarchical partitioning of maginal R2
fun_D1_null <- lme(lnB ~ Null  +  MAT  + NPP + SOC + pH 
                   + EC + ST + SWC +lnP,
                   random = (~1|Replicate),
                   data = funD1_null1)

glmm.hp(fun_D1_null)
(fun_D1_null1<-glmm.hp(fun_D1_null,commonality=TRUE))
#predition
fun_D1_Det <- lme(lnB ~ MAT  + NPP + SOC + pH 
                  + EC + ST + SWC +lnP,
                  random = (~1|Replicate),
                  data = funD1_null1)
Prfun_D1_Det <- predict(fun_D1_Det, type="response",newdata = funD1_null1)
write.csv(Prfun_D1_Det, "./supplement/Prfun_D1_Det.csv", row.names = TRUE)

fun_D1_Sto <- lme(lnB ~ Null,
                  random = (~1|Replicate),
                  data = funD1_null1)
Prfun_D1_Sto <- predict(fun_D1_Sto, type="response",newdata = funD1_null1)
write.csv(Prfun_D1_Sto, "./supplement/Prfun_D1_Sto.csv", row.names = TRUE)

#D2
funD2_null<- filter(fun_null, Depth == "D2")
funD2_null1 <-funD2_null %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAP = scale(MAP),
         MAT = scale(MAT),
         AET = scale(AET),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP) )
#hierarchical partitioning of maginal R2
fun_D2_null <- lme(lnB ~ Null  +  MAT  + NPP + SOC + pH 
                   + EC + ST + SWC +lnP,
                   random = (~1|Replicate),
                   data = funD2_null1)

glmm.hp(fun_D2_null)
(fun_D2_null1<-glmm.hp(fun_D2_null,commonality=TRUE))
#predition
fun_D2_Det <- lme(lnB ~ MAT  + NPP + SOC + pH 
                  + EC + ST + SWC +lnP,
                  random = (~1|Replicate),
                  data = funD2_null1)
Prfun_D2_Det <- predict(fun_D2_Det, type="response",newdata = funD2_null1)
write.csv(Prfun_D2_Det, "./supplement/Prfun_D2_Det.csv", row.names = TRUE)

fun_D2_Sto <- lme(lnB ~ Null,
                  random = (~1|Replicate),
                  data = funD2_null1)
Prfun_D2_Sto <- predict(fun_D2_Sto, type="response",newdata = funD2_null1)
write.csv(Prfun_D2_Sto, "./supplement/Prfun_D2_Sto.csv", row.names = TRUE)

#D3
funD3_null<- filter(fun_null, Depth == "D3")
funD3_null1 <-funD3_null %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAP = scale(MAP),
         MAT = scale(MAT),
         AET = scale(AET),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP) )
#hierarchical partitioning of maginal R2
fun_D3_null <- lme(lnB ~ Null  +  MAT  + NPP + SOC + pH 
                   + EC + ST + SWC +lnP,
                   random = (~1|Replicate),
                   data = funD3_null1)

glmm.hp(fun_D3_null)
(fun_D3_null1<-glmm.hp(fun_D3_null,commonality=TRUE))
#predition
fun_D3_Det <- lme(lnB ~ MAT  + NPP + SOC + pH 
                  + EC + ST + SWC +lnP,
                  random = (~1|Replicate),
                  data = funD3_null1)
Prfun_D3_Det <- predict(fun_D3_Det, type="response",newdata = funD3_null1)
write.csv(Prfun_D3_Det, "./supplement/Prfun_D3_Det.csv", row.names = TRUE)

fun_D3_Sto <- lme(lnB ~ Null,
                  random = (~1|Replicate),
                  data = funD3_null1)
Prfun_D3_Sto <- predict(fun_D3_Sto, type="response",newdata = funD3_null1)
write.csv(Prfun_D3_Sto, "./supplement/Prfun_D3_Sto.csv", row.names = TRUE)

#D4
funD4_null<- filter(fun_null, Depth == "D4")
funD4_null1 <-funD4_null %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAP = scale(MAP),
         MAT = scale(MAT),
         AET = scale(AET),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP) )
#hierarchical partitioning of maginal R2
fun_D4_null <- lme(lnB ~ Null  +  MAT  + NPP + SOC + pH 
                   + EC + ST + SWC +lnP,
                   random = (~1|Replicate),
                   data = funD4_null1)

glmm.hp(fun_D4_null)
(fun_D4_null1<-glmm.hp(fun_D4_null,commonality=TRUE))
#predition
fun_D4_Det <- lme(lnB ~ MAT  + NPP + SOC + pH 
                  + EC + ST + SWC +lnP,
                  random = (~1|Replicate),
                  data = funD4_null1)
Prfun_D4_Det <- predict(fun_D4_Det, type="response",newdata = funD4_null1)
write.csv(Prfun_D4_Det, "./supplement/Prfun_D4_Det.csv", row.names = TRUE)

fun_D4_Sto <- lme(lnB ~ Null,
                  random = (~1|Replicate),
                  data = funD4_null1)
Prfun_D4_Sto <- predict(fun_D4_Sto, type="response",newdata = funD4_null1)
write.csv(Prfun_D4_Sto, "./supplement/Prfun_D4_Sto.csv", row.names = TRUE)

#plot results
#Figure S12 Relative importance of stochastic and niche-based processes in elucidating the 
#microbial diversity
#_________________________bacteria______________________
bac_rePred <- read.table("clipboard",header=T)#load result data
prBac <- bac_rePred %>%
  mutate(Depth = factor(Depth,
                        levels = c("aOverall", "b0-5cm","c5-15cm", "d15-30cm","e30-50cm"),
                        labels = c("Overall", "0-5 cm","5-15 cm", "15-30 cm","30-50 cm"))) %>%
  ggplot(aes(lnB, Prediction, shape = Process,color = Process)) +
  geom_point(size = 1.2, alpha = .4) +
  geom_abline(slope = 1, intercept = 0, linetype = "dashed", color = "gray0") +
  scale_x_continuous(limits = c(7, 8.4), breaks = c(7.0, 7.7, 8.4)) +
  scale_y_continuous(limits = c(7, 8.4), breaks = c(7.0, 7.7, 8.4)) +
  scale_shape_manual(values = c("Deterministic" = 1, "Stochastic" = 2)) +  
  scale_color_manual(values = c("Deterministic" = "black", "Stochastic" = "grey")) +  
  labs(x = "Observed no. of bacterial OTUs\n(in natural logarithm scale)",
       y = "Predicted no. of OTUs\n(in natural logarithm scale)",
       title = "") +
  theme_bw(base_size = 12.5) +
  theme(panel.grid = element_blank(),
        panel.background = element_blank(),
        panel.border = element_rect(fill = NA, color = "gray30"),
        axis.line = element_line(arrow = arrow(length = unit(0.2, "cm")),
                                 linewidth = 0.25),
        strip.text = element_text(size = 12),
        strip.background = element_blank(),
        legend.position = "none") +
  facet_wrap(~ Depth, ncol = 5)
prBac

#_________________________fungi______________________
fun_rePred <- read.table("clipboard",header=T)#load result data
prfun <- fun_rePred %>%
  mutate(Depth = factor(Depth,
                        levels = c("aOverall", "b0-5cm","c5-15cm", "d15-30cm","e30-50cm"),
                        labels = c("Overall", "0-5 cm","5-15 cm", "15-30 cm","30-50 cm"))) %>%
  ggplot(aes(lnF, Prediction, shape = Process,color=Process)) +
  geom_point(size = 1.2, alpha = .4) +
  geom_abline(slope = 1, intercept = 0, linetype = "dashed", color = "gray0") +
  scale_x_continuous(limits = c(4, 7), breaks = c(4.0, 5.5, 7.0)) +
  scale_y_continuous(limits = c(4, 7), breaks = c(4.0, 5.5, 7.0)) +
  scale_shape_manual(values = c("Deterministic" = 1, "Stochastic" = 2)) +  
  scale_color_manual(values = c("Deterministic" = "black", "Stochastic" = "grey")) +  
  labs(x = "Observed no. of fungal OTUs\n(in natural logarithm scale)",
       y = "Predicted no. of OTUs\n(in natural logarithm scale)",
       title = "") +
  theme_bw(base_size = 12.5) +
  theme(panel.grid = element_blank(),
        panel.background = element_blank(),
        panel.border = element_rect(fill = NA, color = "gray30"),
        axis.line = element_line(arrow = arrow(length = unit(0.2, "cm")),
                                 linewidth = 0.25),
        strip.text = element_text(size = 12),
        strip.background = element_blank(),
        legend.position =  c(0.8, 0.1)) +
  facet_wrap(~ Depth, ncol = 5)
prfun
#Plot hierarchical partitioning of marginal R2 
Mic_R2 <- read.table("clipboard",header=T)#load result data
MicroR2 <- Mic_R2 %>%
  data.frame() %>%
  mutate(Iperc = as.numeric(as.character(Iperc))) %>%
  mutate(Depth = factor(Depth,
                        levels = c("aOverall", "b0-5cm","c5-15cm", "d15-30cm","e30-50cm","f"),
                        labels = c("Overall", "0-5 cm","5-15 cm", "15-30 cm","30-50 cm","f"))) %>%
  mutate(Processes = factor(Processes,
                            levels = c("1Stochastic" , "2Deterministic"),
                            labels = c( "Stochastic" , "Deterministic"))) %>%
  ggplot(aes(x= Mic, y= Iperc, color = Processes, fill = Processes)) +
  geom_bar(stat = "identity", position = "stack", alpha = .66,
           width = .75) +
  #coord_flip() +
  scale_color_manual(values = c("grey80","grey40")) +
  scale_fill_manual(values = c("grey80","grey40"),
                    name = "") +
  scale_y_continuous(lim = c(0, 100),
                     breaks = c(0, 50, 100)) +
  labs(y = "Percentage (%)", x = "",
       title = "",
       subtitle = "") +
  theme_bw(base_size = 12.5) +
  theme(panel.grid = element_blank(),
        axis.text.y.left = element_text(size = 12, angle = 90),
        axis.text.y.right = element_text(size = 12.5, angle = 90),
        axis.ticks.y.right = element_line(),
        axis.text = element_text(size = 12),
        axis.line.x.top = element_blank(),
        axis.text.x = element_text(size = 8,angle = 30),
        plot.title = element_text(hjust = 0.5)) +
  theme(panel.grid = element_blank(),
        panel.background = element_blank(),
        panel.border = element_rect(fill = NA, color = "grey40"),
        axis.line = element_line(arrow = arrow(length = unit(0.2, "cm")),
                                 linewidth = 0.25),
        strip.text = element_text(size = 12),
        strip.background = element_blank(),
        legend.position =  c(1, 0.1)) +
  facet_wrap(~ Depth, ncol = 6)

MicroR2


PF1a <- plot_grid(prBac, prfun, MicroR2,
                  labels = c("a)", "b)", "c)"),
                  nrow = 3, ncol = 1,
                  label_x = 0,  
                  label_y = 0.85,  
                  align = "hv")  

PF1a 
ggsave("./supplement/Figure S12_stochastic and niche-based.pdf",
       width = 180, height = 240, units = "mm")

###########################################################
#                    End of Script                        #
###########################################################
