# Analysis 1: Elevation pattern
# MPL
# 2025.01.01
# This script is to plot and fit the quadratic equation about the elevational 
# distribution of soil bacterial and fungal species richness 



###########################################################


# load library

library(tidyverse)
library(cowplot)
library(stats)

# load data
dat <- read.table("clipboard",header=T)#load  data

bac_dat <- dat %>%filter(Microbe == "bacteria")
fun_dat <- dat %>%filter(Microbe == "fungi")


###########################################################
# calculate AIC Values  of the linear regression models and the quadratic regression models

#bacteria
bac_dat$Elevation.c <- bac_dat$Elevation/100


model1 <- lm(lnB ~ Elevation.c + I(Elevation.c^2), data = bac_dat[bac_dat$Depth == "Overall", ])
model2 <- lm(lnB ~ Elevation.c , data = bac_dat[bac_dat$Depth == "Overall", ])
AIC(model1)
AIC(model2)
summary(model1)

model1SD1 <- lm(lnB ~ Elevation.c + I(Elevation.c^2), data = bac_dat[bac_dat$Depth == "D1", ])
model2SD1 <- lm(lnB ~ Elevation.c , data = bac_dat[bac_dat$Depth == "D1", ])
AIC(model1SD1)
AIC(model2SD1)
summary(model1SD1)


model1SD2 <- lm(lnB ~ Elevation.c + I(Elevation.c^2), data = bac_dat[bac_dat$Depth == "D2", ])
model2SD2 <- lm(lnB ~ Elevation.c , data = bac_dat[bac_dat$Depth == "D2", ])
AIC(model2SD2)
AIC(model1SD2)
summary(model1SD2)

model1SD3 <- lm(lnB ~ Elevation.c + I(Elevation.c^2), data = bac_dat[bac_dat$Depth == "D3", ])
model2SD3 <- lm(lnB ~ Elevation.c , data = bac_dat[bac_dat$Depth == "D3", ])
AIC(model2SD3)
AIC(model1SD3)
summary(model1SD3)

model1SD4 <- lm(lnB ~ Elevation.c + I(Elevation.c^2), data = bac_dat[bac_dat$Depth == "D4", ])
model2SD4 <- lm(lnB ~ Elevation.c , data = bac_dat[bac_dat$Depth == "D4", ])
AIC(model2SD4)
AIC(model1SD4)
summary(model1SD4)

#fungi
fun_dat$Sdepth <- as.factor(fun_dat$Sdepth)
fun_dat$Elevation.c <- fun_dat$Elevation/100

Fmodel1 <- lm(lnB ~ Elevation.c + I(Elevation.c^2), data = fun_dat[fun_dat$Depth == "Overall", ])
Fmodel2 <- lm(lnB ~ Elevation.c , data = fun_dat[fun_dat$Depth == "Overall", ])
AIC(Fmodel1)
AIC(Fmodel2)
summary(Fmodel1)

Fmodel1SD1 <- lm(lnB ~ Elevation.c + I(Elevation.c^2), data = fun_dat[fun_dat$Depth == "D1", ])
Fmodel2SD1 <- lm(lnB ~ Elevation.c , data = fun_dat[fun_dat$Depth == "D1", ])
AIC(Fmodel1SD1)
AIC(Fmodel2SD1)
summary(Fmodel1SD1)

Fmodel1SD2 <- lm(lnB ~ Elevation.c + I(Elevation.c^2), data = fun_dat[fun_dat$Depth == "D2", ])
Fmodel2SD2 <- lm(lnB ~ Elevation.c , data = fun_dat[fun_dat$Depth == "D2", ])
AIC(Fmodel2SD2)
AIC(Fmodel1SD2)
summary(Fmodel1SD2)

Fmodel1SD3 <- lm(lnB ~ Elevation.c + I(Elevation.c^2), data = fun_dat[fun_dat$Depth == "D3", ])
Fmodel2SD3 <- lm(lnB ~ Elevation.c , data = fun_dat[fun_dat$Depth == "D3", ])
AIC(Fmodel2SD3)
AIC(Fmodel1SD3)
summary(Fmodel1SD3)

Fmodel1SD4 <- lm(lnB ~ Elevation.c + I(Elevation.c^2), data = fun_dat[fun_dat$Depth == "D4", ])
Fmodel2SD4 <- lm(lnB ~ Elevation.c , data = fun_dat[fun_dat$Depth == "D4", ])
AIC(Fmodel2SD4)
AIC(Fmodel1SD4)
summary(Fmodel1SD4)


# calculate the coefficients of the elevational quadratic regression model
Equ_values_PtternDepth <- dat %>%
  group_by(Microbe,Depth) %>%
  do({
    fit <- lm(lnB ~ poly(Elevation/100, 2), data = .)
    summary_fit <- summary(fit)
    p_value <- summary_fit$coefficients["poly(Elevation/100, 2)2", "Pr(>|t|)"]
    r_squared <- summary_fit$r.squared
    coefficients <- coef(fit)
    # 创建一个数据框来保存结果
    data.frame(
      p_value = p_value,
      r_squared = r_squared,
      intercept = coefficients[1],         
      slope1 = coefficients[2],           
      slope2 = coefficients[3]             
    )
  })
write.csv(Equ_values_PtternDepth, "./supplement/Equ_values_PtternDepth.csv", row.names = TRUE)

###########################################################
# Fig. 2 to plot the elevation patterns

p1 <- bac_dat %>% filter(Depth == "Overall")%>%
  ggplot(aes(Elevation, lnB)) +
  geom_point(size = 1.2, alpha = .4) +
  geom_smooth(formula = 'y ~ x + I(x^2)', 
              linewidth = 1,
              method = "lm",
              color = "red",
              se = TRUE) +
  scale_x_continuous(lim = c(400, 3100)) +
  scale_y_continuous(lim = c(7, 8.5), 
                     breaks = c(7.25, 7.75, 8.25)) +
  labs(x = "",
       y = "Observed no. of bacterial OTUs\n(in natural logarithm scale)",
       title = "All depths")+
  theme_bw(base_size = 11.5) +
  theme(panel.grid = element_blank(),
        plot.title = element_text(size = 12, hjust = 0.5),
        axis.text.x = element_blank(), # 移除 x 轴文本标签
        #axis.text.y = element_blank(), # 移除 y 轴文本标签
  )+
  theme(axis.line = element_line(arrow = arrow(length = unit(0.2, "cm")),
                                 linewidth = 0.25))
p1


p2 <- bac_dat %>% filter(Depth == "Overall")%>%
  mutate(Depth = factor(Sdepth,
                        levels = c("2.5", "10", "22.5", "40"),
                        labels = c("0-5", "5-15", "15-30", "30-50"))) %>% 
  ggplot(aes(Elevation, lnB, group = Depth, color = Depth)) +
  # geom_point(shape = 21, size = 1.2, alpha = .6) +
  geom_smooth(formula = 'y ~ x + I(x^2)', 
              linewidth = .8,
              method = "lm",
              se = FALSE) +
  scale_x_continuous(lim = c(400, 3100)) +
  scale_color_manual(values = c("#7f2704", "#d94801", "#fd8d3c", "#fdd0a2"),
                     name = "Depth (cm)") +
  scale_y_continuous(lim = c(7, 8.5), 
                     breaks = c(7.25, 7.75, 8.25)) +
  labs(x = "",
       y = "",
       title = "By soil depth") +
  theme_bw(base_size = 11.5) +
  theme(panel.grid = element_blank(),
        legend.position = c(.6, .3),
        legend.key.size = unit(5, "mm") ,
        plot.title = element_text(size = 12, hjust = 0.5),
        axis.text.x = element_blank(), # 移除 x 轴文本标签
        axis.text.y = element_blank(), # 移除 y 轴文本标签 
  )+
  theme(axis.line = element_line(arrow = arrow(length = unit(0.2, "cm")),
                                 linewidth = 0.25))
p2

p3 <- fun_dat %>% filter(Depth == "Overall")%>%
  ggplot(aes(Elevation, lnB)) +
  geom_point(size = 1.2, alpha = .4) +
  geom_smooth(formula = 'y ~ x + I(x^2)', 
              linewidth = 1,
              method = "lm",
              color = "red",
              se = TRUE) +
  scale_x_continuous(lim = c(400, 3100)) +
  scale_y_continuous(lim = c(4.0, 7.0),
                     breaks = c(4.5, 5.5, 6.5)) +
  labs(x = "Elevation (m)",
       y = "Observed no. of fungal OTUs\n(in natural logarithm scale)") +
  theme_bw(base_size = 11.5) +
  theme(panel.grid = element_blank())+
  theme(axis.line = element_line(arrow = arrow(length = unit(0.2, "cm")),
                                 linewidth = 0.25))
p3

p4 <- fun_dat %>% filter(Depth == "Overall")%>%
  mutate(Depth = factor(Sdepth,
                        levels = c("2.5", "10", "22.5", "40"),
                        labels = c("0-5", "5-15", "15-30", "30-50"))) %>% 
  ggplot(aes(Elevation, lnB, group = Depth, color = Depth)) +
  # geom_point(shape = 21, size = 1.2, alpha = .6) +
  geom_smooth(aes(lty = Depth),
              formula = 'y ~ x + I(x^2)', 
              linewidth = .8,
              method = "lm",
              se = FALSE) +
  scale_x_continuous(lim = c(400, 3100)) +
  scale_linetype_manual(values = c("dashed", "solid", "solid", "solid")) +
  scale_color_manual(values = c("#7f2704", "#d94801", "#fd8d3c", "#fdd0a2"),
                     name = "Depth (cm)") +
  scale_y_continuous(lim = c(4.0, 7.0),
                     breaks = c(4.5, 5.5, 6.5)) +
  labs(x = "Elevation (m)",
       y = "") +
  theme_bw(base_size = 11.5) +
  theme(panel.grid = element_blank(),
        legend.position = 'none',
        axis.text.y = element_blank(), # 移除 x 轴文本标签
  )+
  theme(axis.line = element_line(arrow = arrow(length = unit(0.2, "cm")),
                                 linewidth = 0.25))
p4

plot_grid(p1, p2, p3, p4,
          labels = c("a)", "b)", "c)", "d)"),
          label_x = .2,
          label_y = .95,
          align = "hv")

ggsave("./Figures/Fig.2 Pattern1.pdf",
       width = 180, height = 165, units = "mm")


###########################################################
#                    End of Script                        #
###########################################################