# Analysis 2: Calculate marginal R2 using bootstrap to assessing the impacts of environmental filters
# LMP
# 2025.01.01
# This script is to Calculate marginal R2 via bootstrap resampling (1000 iterations) 



###########################################################


# load library
library(tidyverse)
library(dplyr)
library(nlme)
library(glmm.hp)
library(boot)

library(ggplot2)
library(ggdist)
library(cowplot)


#____________________bootstrap of marginal r-squared_____________________
# load data
dat <- read.table("clipboard",header=T)#load  data

bac_dat <- dat %>%filter(Microbe == "bacteria")
fun_dat <- dat %>%filter(Microbe == "fungi")

#________________________________bacteria________________________________

#overall
#data Preparation
bac_datover<- filter(bac_dat, Depth == "Overall")
bac_datover1 <-bac_datover %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAT = scale(MAT),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP))

#building mixed-effects model
bacover <- lme(lnB ~ MAT + NPP + SOC + pH 
             + EC + ST + SWC +lnP,
             random = (~1|Replicate),
             data = bac_datover1)
r.squared.marginal <- r.squaredGLMM(bacover)

#bootstrap function for marginal r-squared
r_squared_boot <- function(data, indices) {
  data_boot <- data[indices, ]
  model_boot <- update(bacover, data = data_boot)
  r.squared.marginal <- r.squaredGLMM(model_boot)
  return(r.squared.marginal)
}
nboots <- 1000# set number of bootstrap replications
set.seed(123) # set seed
boot_results <- boot(data = bac_datover1, statistic = r_squared_boot, R = nboots)# perform bootstrap resampling

boot_results
bootresults.boot.out
write.csv(boot_results$t, file = paste0("./Marginal R2/lme_bac_over.csv"),row.names = TRUE)

#D1
#data Preparation
bac_datD1<- filter(bac_dat, Depth == "D1")
bac_datD11 <-bac_datD1 %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAT = scale(MAT),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP))

#building mixed-effects model
bacD1 <- lme(lnB ~ MAT + NPP + SOC + pH 
               + EC + ST + SWC +lnP,
               random = (~1|Replicate),
               data = bac_datD11)

r.squared.marginal <- r.squaredGLMM(bacD1)

#bootstrap function for marginal r-squared
r_squared_boot <- function(data, indices) {
  data_boot <- data[indices, ]
  model_boot <- update(bacD1, data = data_boot)
  r.squared.marginal <- r.squaredGLMM(model_boot)
  return(r.squared.marginal)
}
nboots <- 1000# set number of bootstrap replications
set.seed(123) # set seed
boot_results <- boot(data = bac_datD11, statistic = r_squared_boot, R = nboots)# perform bootstrap resampling

boot_results
bootresults.boot.out
write.csv(boot_results$t, file = paste0("./Marginal R2/alme_bac_D1.csv"),row.names = TRUE)

#D2
#data Preparation
bac_datD2<- filter(bac_dat, Depth == "D2")
bac_datD21 <-bac_datD2 %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAT = scale(MAT),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP))

#building mixed-effects model
bacD2 <- lme(lnB ~ MAT + NPP + SOC + pH 
             + EC + ST + SWC +lnP,
             random = (~1|Replicate),
             data = bac_datD21)

r.squared.marginal <- r.squaredGLMM(bacD2)

#bootstrap function for marginal r-squared
r_squared_boot <- function(data, indices) {
  data_boot <- data[indices, ]
  model_boot <- update(bacD2, data = data_boot)
  r.squared.marginal <- r.squaredGLMM(model_boot)
  return(r.squared.marginal)
}
nboots <- 1000# set number of bootstrap replications
set.seed(123) # set seed
boot_results <- boot(data = bac_datD21, statistic = r_squared_boot, R = nboots)# perform bootstrap resampling

boot_results
bootresults.boot.out
write.csv(boot_results$t, file = paste0("./Marginal R2/lme_bac_D2.csv"),row.names = TRUE)

#D3
#data Preparation
bac_datD3<- filter(bac_dat, Depth == "D3")
bac_datD31 <-bac_datD3 %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAT = scale(MAT),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP))

#building mixed-effects model
bacD3 <- lme(lnB ~ MAT + NPP + SOC + pH 
             + EC + ST + SWC +lnP,
             random = (~1|Replicate),
             data = bac_datD31)

r.squared.marginal <- r.squaredGLMM(bacD3)

#bootstrap function for marginal r-squared
r_squared_boot <- function(data, indices) {
  data_boot <- data[indices, ]
  model_boot <- update(bacD3, data = data_boot)
  r.squared.marginal <- r.squaredGLMM(model_boot)
  return(r.squared.marginal)
}
nboots <- 1000# set number of bootstrap replications
set.seed(123) # set seed
boot_results <- boot(data = bac_datD31, statistic = r_squared_boot, R = nboots)# perform bootstrap resampling

boot_results
bootresults.boot.out
write.csv(boot_results$t, file = paste0("./Marginal R2/lme_bac_D3.csv"),row.names = TRUE)

#D4
#data Preparation
bac_datD4<- filter(bac_dat, Depth == "D4")
bac_datD41 <-bac_datD4 %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAT = scale(MAT),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP))

#building mixed-effects model
bacD4 <- lme(lnB ~ MAT + NPP + SOC + pH 
             + EC + ST + SWC +lnP,
             random = (~1|Replicate),
             data = bac_datD41)

r.squared.marginal <- r.squaredGLMM(bacD4)

#bootstrap function for marginal r-squared
r_squared_boot <- function(data, indices) {
  data_boot <- data[indices, ]
  model_boot <- update(bacD4, data = data_boot)
  r.squared.marginal <- r.squaredGLMM(model_boot)
  return(r.squared.marginal)
}
nboots <- 1000# set number of bootstrap replications
set.seed(123) # set seed
boot_results <- boot(data = bac_datD41, statistic = r_squared_boot, R = nboots)# perform bootstrap resampling

boot_results
bootresults.boot.out
write.csv(boot_results$t, file = paste0("./Marginal R2/lme_bac_D4.csv"),row.names = TRUE)


#________________________________fungi________________________________

#overall
#data Preparation
fun_datover<- filter(fun_dat, Depth == "Overall")
fun_datover1 <-fun_datover %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAT = scale(MAT),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP))

#building mixed-effects model
funover <- lme(lnB ~ MAT + NPP + SOC + pH 
               + EC + ST + SWC +lnP,
               random = (~1|Elevation/Replicate),
               data = fun_datover1)

r.squared.marginal <- r.squaredGLMM(funover)

#bootstrap function for marginal r-squared
r_squared_boot <- function(data, indices) {
  data_boot <- data[indices, ]
  model_boot <- update(funover, data = data_boot)
  r.squared.marginal <- r.squaredGLMM(model_boot)
  return(r.squared.marginal)
}
nboots <- 1000# set number of bootstrap replications
set.seed(123) # set seed
boot_results <- boot(data = fun_datover1, statistic = r_squared_boot, R = nboots)# perform bootstrap resampling

boot_results
bootresults.boot.out
write.csv(boot_results$t, file = paste0("./Marginal R2/lme_fun_over.csv"),row.names = TRUE)

#D1
#data Preparation
fun_datD1<- filter(fun_dat, Depth == "D1")
fun_datD11 <-fun_datD1 %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAT = scale(MAT),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP))

#building mixed-effects model
funD1 <- lme(lnB ~ MAT + NPP + SOC + pH 
             + EC + ST + SWC +lnP,
             random = (~1|Replicate),
             data = fun_datD11)

r.squared.marginal <- r.squaredGLMM(funD1)

#bootstrap function for marginal r-squared
r_squared_boot <- function(data, indices) {
  data_boot <- data[indices, ]
  model_boot <- update(funD1, data = data_boot)
  r.squared.marginal <- r.squaredGLMM(model_boot)
  return(r.squared.marginal)
}
nboots <- 1000# set number of bootstrap replications
set.seed(123) # set seed
boot_results <- boot(data = fun_datD11, statistic = r_squared_boot, R = nboots)# perform bootstrap resampling

boot_results
bootresults.boot.out
write.csv(boot_results$t, file = paste0("./Marginal R2/lme_fun_D1.csv"),row.names = TRUE)

#D2
#data Preparation
fun_datD2<- filter(fun_dat, Depth == "D2")
fun_datD21 <-fun_datD2 %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAT = scale(MAT),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP))

#building mixed-effects model
funD2 <- lme(lnB ~ MAT + NPP + SOC + pH 
             + EC + ST + SWC +lnP,
             random = (~1|Replicate),
             data = fun_datD21)

r.squared.marginal <- r.squaredGLMM(funD2)

#bootstrap function for marginal r-squared
r_squared_boot <- function(data, indices) {
  data_boot <- data[indices, ]
  model_boot <- update(funD2, data = data_boot)
  r.squared.marginal <- r.squaredGLMM(model_boot)
  return(r.squared.marginal)
}
nboots <- 1000# set number of bootstrap replications
set.seed(123) # set seed
boot_results <- boot(data = fun_datD21, statistic = r_squared_boot, R = nboots)# perform bootstrap resampling

boot_results
bootresults.boot.out
write.csv(boot_results$t, file = paste0("./Marginal R2/lme_fun_D2.csv"),row.names = TRUE)

#D3
#data Preparation
fun_datD3<- filter(fun_dat, Depth == "D3")
fun_datD31 <-fun_datD3 %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAT = scale(MAT),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP))

#building mixed-effects model
funD3 <- lme(lnB ~ MAT + NPP + SOC + pH 
             + EC + ST + SWC +lnP,
             random = (~1|Replicate),
             data = fun_datD31)

r.squared.marginal <- r.squaredGLMM(funD3)

#bootstrap function for marginal r-squared
r_squared_boot <- function(data, indices) {
  data_boot <- data[indices, ]
  model_boot <- update(funD3, data = data_boot)
  r.squared.marginal <- r.squaredGLMM(model_boot)
  return(r.squared.marginal)
}
nboots <- 1000# set number of bootstrap replications
set.seed(123) # set seed
boot_results <- boot(data = fun_datD31, statistic = r_squared_boot, R = nboots)# perform bootstrap resampling

boot_results
bootresults.boot.out
write.csv(boot_results$t, file = paste0("./Marginal R2/lme_fun_D3.csv"),row.names = TRUE)

#D4
#data Preparation
fun_datD4<- filter(fun_dat, Depth == "D4")
fun_datD41 <-fun_datD4 %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAT = scale(MAT),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP))

#building mixed-effects model
funD4 <- lme(lnB ~ MAT + NPP + SOC + pH 
             + EC + ST + SWC +lnP,
             random = (~1|Replicate),
             data = fun_datD41)

r.squared.marginal <- r.squaredGLMM(funD4)

#bootstrap function for marginal r-squared
r_squared_boot <- function(data, indices) {
  data_boot <- data[indices, ]
  model_boot <- update(funD4, data = data_boot)
  r.squared.marginal <- r.squaredGLMM(model_boot)
  return(r.squared.marginal)
}
nboots <- 1000# set number of bootstrap replications
set.seed(123) # set seed
boot_results <- boot(data = fun_datD41, statistic = r_squared_boot, R = nboots)# perform bootstrap resampling

boot_results
bootresults.boot.out
write.csv(boot_results$t, file = paste0("./Marginal R2/lme_fun_D4.csv"),row.names = TRUE)



############################################################
#Fig. 3 to plot the depth-dependent variations in marginal R2
# load data
Marginal_dat <- read.table("clipboard",header=T)#load result data
#calculate mean value and data distribution
Marginal_plotdata <- Marginal_dat %>%
  group_by(Depth, Micro) %>%
  summarize(
    n = n(),
  
    y0 = min(MarginalR),
    Mean = mean(MarginalR),
    y100 = max(MarginalR),
    sd = sd(MarginalR),
    se = sd / sqrt(n),

    p66_lower = quantile(MarginalR, 0.17),  # (1 - 0.66) / 2 = 0.17
    p66_upper = quantile(MarginalR, 0.83),  # 1 - 0.17 = 0.83
    p95_lower = quantile(MarginalR, 0.025), # (1 - 0.95) / 2 = 0.025
    p95_upper = quantile(MarginalR, 0.975), # 1 - 0.025 = 0.975
  )
write.csv(Marginal_plotdata, "./Marginal_plotdata.csv", row.names = FALSE)

#merge mean values with the original data frame
mean_marginal_by_depth <- Marginal_dat %>%
  group_by(Depth, Micro) %>%
  summarise(Mean_Marginal = mean(MarginalR, na.rm = TRUE)) %>%
  ungroup()
Marginal_dat1 <- Marginal_dat %>%
  left_join(mean_marginal_by_depth, by = c("Depth", "Micro"))

#add a mean line
Marginal_Mean <- read.table("clipboard",header=T)#load result data
line_data_b <- Marginal_Mean %>%
  filter(Micro == "Bacteria") %>%
  select(Depth, Mean_Marginal) %>%
  mutate(Depth = factor(Depth,
                        levels = c("D1", "D2", "D3", "D4" ),
                        labels = c("0-5", "5-15", "15-30", "30-50" )))

#plot marginal r-squared
Marginal_b <- ggplot(Marginal_dat1 %>% 
                       filter(Micro == "Bacteria") %>%
                       mutate(Depth = factor(Depth,
                                             levels = c("Allover","D1", "D2", "D3", "D4"),
                                             labels = c("All depths","0-5", "5-15", "15-30", "30-50"))),
                     (aes(x = Depth, y = MarginalR,group = Depth))) +
  
  theme(panel.background = element_rect(color = "grey70"))+
  
  stat_slab(aes(fill = after_stat(level)), .width = c(.66, .95, 1)) +
  stat_pointinterval() +
  scale_fill_manual(values = c("grey80", "grey70", "grey65"))+
  
  geom_line(data = line_data_b,
            aes(y = Mean_Marginal, x = Depth, group = 1),
            color = "grey75", linewidth = 0.5)+
  scale_y_continuous(limits = c(15, 105), breaks = c( 30,60, 90)) +
  labs(y = "Variance explained (%)",
       x = "",
       title = "Bacteria") +
  theme_bw(base_size = 11.5) +
  theme(element_line(color = "grey80", linewidth = 0.25),
        legend.position = c(0.87,0.35),
        legend.key.size = unit(5, "mm")) +
  theme(panel.grid = element_blank())+
  theme(strip.background = element_rect(colour = NA, fill = NA),
        axis.line = element_line(arrow = arrow(length = unit(0.2, "cm")),
                                 linewidth = 0.25),
        axis.text.x = element_text(angle = 0, size = 10,hjust = 0.5),
        axis.text.y = element_text(angle = 0, size = 10),
        plot.title = element_text(size = 12, hjust = 0.5))

Marginal_b

#fungi
#add a mean line
line_data_f<- Marginal_Mean %>%
  filter(Micro == "Fungi") %>%
  select(Depth, Mean_Marginal) %>%
  mutate(Depth  = factor(Depth,
                         levels = c("D1", "D2", "D3", "D4" ),
                         labels = c("0-5", "5-15", "15-30", "30-50" )))

#plot marginal r-squared
Marginal_f <- ggplot(Marginal_dat %>% 
                       filter(Micro == "Fungi") %>%
                       mutate(Depth = factor(Depth,
                                             levels = c("Allover","D1", "D2", "D3", "D4"),
                                             labels = c("All depths","0-5", "5-15", "15-30", "30-50"))),
                     (aes(x = Depth, y = MarginalR,group = Depth))) +
  theme(panel.background = element_rect(color = "grey70"))+
  
  stat_slab(aes(fill = after_stat(level)), .width = c(.66, .95, 1)) +
  stat_pointinterval() +
  scale_fill_manual(values = c("grey80", "grey70", "grey65"))+

  geom_line(data = line_data_f,
            aes(y = Mean_Marginal, x = Depth, group = 1),
            color = "grey75", linewidth = 0.5)+
  scale_y_continuous(limits = c(7, 90), breaks = c( 30,60, 90)) +
  labs(y = "Variance explained (%)",
       x = "Soil depth (cm)",
       title = "Fungi") +
  theme_bw(base_size = 11.5) +
  theme(element_line(color = "grey80", linewidth = 0.25),
        legend.position = "none",
        legend.key.size = unit(5, "mm")) +
  theme(panel.grid = element_blank())+
  theme(strip.background = element_rect(colour = NA, fill = NA),
        axis.line = element_line(arrow = arrow(length = unit(0.2, "cm")),
                                 linewidth = 0.25),
        axis.text.x = element_text(angle = 0, size = 10,hjust = 0.5),
        axis.text.y = element_text(angle = 0, size = 10),
        plot.title = element_text(size = 12, hjust = 0.5))
Marginal_f

plot_grid(Marginal_b, Marginal_f,
          labels = c("a)", "b)"),
          label_x = 0,
          label_y = 1,
          nrow = 2,    
          align = "hv")

# save the plot
ggsave("./figure/Fig.3_Theoritical R2_density.pdf",
       width = 180, height = 165, units = "mm")

###########################################################
#                    End of Script                        #
###########################################################