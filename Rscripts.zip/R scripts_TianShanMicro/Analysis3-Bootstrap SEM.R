# Analysis 2: Calculate SEM  using bootstrap to compute the path coefficients 
# between environmental filters and microbial diversity
# LMP
# 2025.01.01
# This script is to Calculate the SEM path coefficients via bootstrap resampling (1000 iterations) 



###########################################################


# load library

library(tidyverse)
library(nlme)
library(piecewiseSEM)
library(boot)

library(ggplot2)
library(ggdist)
library(cowplot)


#construct composite variable
# load data
dat <- read.table("clipboard",header=T)#load  data

bac_dat <- dat %>%filter(Microbe == "bacteria")
fun_dat <- dat %>%filter(Microbe == "fungi")

#bacteria
#_________________________Overall______________________________
#data Preparation
bac_datover<- filter(bac_dat, Depth == "Overall")

bac_datover1 <-bac_datover %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAT = scale(MAT),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP))
#_________________abiotic soil filter_______________________________
SoilBOv <-lme(lnB ~  pH+EC+SWC,
              random= ~1 |Elevation/Replicate, 
               # control = lmerControl(optCtrl = list(maxfun = 2000)),
               data=bac_datover1)
summary(SoilBOv )

betaBOv_pH<-  summary(SoilBOv)$tTable["pH", "Value"]
betaBOv_EC<-  summary(SoilBOv)$tTable["EC", "Value"]
betaBOv_SWC<-  summary(SoilBOv)$tTable["SWC", "Value"]
BOvSoilCom <- betaBOv_pH*bac_datover1$pH+ betaBOv_EC*bac_datover1$EC+ 
  betaBOv_SWC*bac_datover1$SWC
bac_datover1$BOvSoilCom  <- BOvSoilCom
summary(lme(lnB ~ BOvSoilCom,
            random = ~1 |Elevation/Replicate, 
            # control = lmerControl(optCtrl = list(maxfun = 2000)),
            data =  bac_datover1))
print(BOvSoilCom)

#_________________Energy___________________________
EnerBOv <-lme(lnB ~ NPP+SOC+MAT+ST,random=~1 |Elevation/Replicate, 
               # control = lmerControl(optCtrl = list(maxfun = 2000)),
               data=bac_datover1)
summary(EnerBOv)

betaBOv_NPP<-  summary(EnerBOv)$tTable["NPP", "Value"]
betaBOv_SOC<-  summary(EnerBOv)$tTable["SOC", "Value"]
betaBOv_MAT<-  summary(EnerBOv)$tTable["MAT", "Value"]
betaBOv_ST<-  summary(EnerBOv)$tTable["ST", "Value"]
BOvEnerCom <- betaBOv_NPP*bac_datover1$NPP+ betaBOv_SOC*bac_datover1$SOC+
  betaBOv_MAT*bac_datover1$MAT+ betaBOv_ST*bac_datover1$ST
bac_datover1$BOvEnerCom  <- BOvEnerCom
summary(lme(lnB ~ BOvEnerCom,
            random = ~1 |Elevation/Replicate, 
            # control = lmerControl(optCtrl = list(maxfun = 2000)),
            data =  bac_datover1))
print(BOvEnerCom)
bac_datover1$SoilCom <- bac_datover1$BOvSoilCom
bac_datover1$EnerCom <- bac_datover1$BOvEnerCom

#_________________________BSD1______________________________
bac_datD1 = filter(bac_dat, Depth == "D1")
bac_datD11 <-bac_datD1 %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAT = scale(MAT),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP))
#_________________abiotic soil filter_______________________________
SoilBD1 <-lme(lnB ~  pH+EC+SWC,
              random= ~1 |Replicate, 
              # control = lmerControl(optCtrl = list(maxfun = 2000)),
              data=bac_datD11)
summary(SoilBD1 )

betaBD1_pH<-  summary(SoilBD1)$tTable["pH", "Value"]
betaBD1_EC<-  summary(SoilBD1)$tTable["EC", "Value"]
betaBD1_SWC<-  summary(SoilBD1)$tTable["SWC", "Value"]
BD1SoilCom <- betaBD1_pH*bac_datD11$pH+ betaBD1_EC*bac_datD11$EC+ 
  betaBD1_SWC*bac_datD11$SWC
bac_datD11$BD1SoilCom  <- BD1SoilCom
summary(lme(lnB ~ BD1SoilCom,
            random = ~1 |Replicate, 
            # control = lmerControl(optCtrl = list(maxfun = 2000)),
            data =  bac_datD11))
print(BD1SoilCom)

#_________________Energy___________________________
EnerBD1 <-lme(lnB ~ NPP+SOC+MAT+ST,random=~1 |Replicate, 
              # control = lmerControl(optCtrl = list(maxfun = 2000)),
              data=bac_datD11)
summary(EnerBD1)

betaBD1_NPP<-  summary(EnerBD1)$tTable["NPP", "Value"]
betaBD1_SOC<-  summary(EnerBD1)$tTable["SOC", "Value"]
betaBD1_MAT<-  summary(EnerBD1)$tTable["MAT", "Value"]
betaBD1_ST<-  summary(EnerBD1)$tTable["ST", "Value"]
BD1EnerCom <- betaBD1_NPP*bac_datD11$NPP+ betaBD1_SOC*bac_datD11$SOC+
  betaBD1_MAT*bac_datD11$MAT+ betaBD1_ST*bac_datD11$ST
bac_datD11$BD1EnerCom  <- BD1EnerCom
summary(lme(lnB ~ BD1EnerCom,
            random = ~1 |Replicate, 
            # control = lmerControl(optCtrl = list(maxfun = 2000)),
            data =  bac_datD11))
print(BD1EnerCom)
bac_datD11$SoilCom <- bac_datD11$BD1SoilCom
bac_datD11$EnerCom <- bac_datD11$BD1EnerCom


#_________________________BSD2______________________________
bac_datD2 = filter(bac_dat, Depth == "D2")
bac_datD21 <-bac_datD2 %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAT = scale(MAT),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP))
#_________________abiotic soil filter_______________________________
SoilBD2 <-lme(lnB ~  pH+EC+SWC,
              random= ~1 |Replicate, 
              # control = lmerControl(optCtrl = list(maxfun = 2000)),
              data=bac_datD21)
summary(SoilBD2 )

betaBD2_pH<-  summary(SoilBD2)$tTable["pH", "Value"]
betaBD2_EC<-  summary(SoilBD2)$tTable["EC", "Value"]
betaBD2_SWC<-  summary(SoilBD2)$tTable["SWC", "Value"]
BD2SoilCom <- betaBD2_pH*bac_datD21$pH+ betaBD2_EC*bac_datD21$EC+ 
  betaBD2_SWC*bac_datD21$SWC
bac_datD21$BD2SoilCom  <- BD2SoilCom
summary(lme(lnB ~ BD2SoilCom,
            random = ~1 |Replicate, 
            # control = lmerControl(optCtrl = list(maxfun = 2000)),
            data =  bac_datD21))
print(BD2SoilCom)

#_________________Energy___________________________
EnerBD2 <-lme(lnB ~ NPP+SOC+MAT+ST,random=~1 |Replicate, 
              # control = lmerControl(optCtrl = list(maxfun = 2000)),
              data=bac_datD21)
summary(EnerBD2)

betaBD2_NPP<-  summary(EnerBD2)$tTable["NPP", "Value"]
betaBD2_SOC<-  summary(EnerBD2)$tTable["SOC", "Value"]
betaBD2_MAT<-  summary(EnerBD2)$tTable["MAT", "Value"]
betaBD2_ST<-  summary(EnerBD2)$tTable["ST", "Value"]
BD2EnerCom <- betaBD2_NPP*bac_datD21$NPP+ betaBD2_SOC*bac_datD21$SOC+
  betaBD2_MAT*bac_datD21$MAT+ betaBD2_ST*bac_datD21$ST
bac_datD21$BD2EnerCom  <- BD2EnerCom
summary(lme(lnB ~ BD2EnerCom,
            random = ~1 |Replicate, 
            # control = lmerControl(optCtrl = list(maxfun = 2000)),
            data =  bac_datD21))
print(BD2EnerCom)
bac_datD21$SoilCom <- bac_datD21$BD2SoilCom
bac_datD21$EnerCom <- bac_datD21$BD2EnerCom

#_________________________BSD3______________________________
bac_datD3 = filter(bac_dat, Depth == "D3")
bac_datD31 <-bac_datD3 %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAT = scale(MAT),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP))
#_________________abiotic soil filter_______________________________
SoilBD3 <-lme(lnB ~  pH+EC+SWC,
              random= ~1 |Replicate, 
              # control = lmerControl(optCtrl = list(maxfun = 2000)),
              data=bac_datD31)
summary(SoilBD3 )

betaBD3_pH<-  summary(SoilBD3)$tTable["pH", "Value"]
betaBD3_EC<-  summary(SoilBD3)$tTable["EC", "Value"]
betaBD3_SWC<-  summary(SoilBD3)$tTable["SWC", "Value"]
BD3SoilCom <- betaBD3_pH*bac_datD31$pH+ betaBD3_EC*bac_datD31$EC+ 
  betaBD3_SWC*bac_datD31$SWC
bac_datD31$BD3SoilCom  <- BD3SoilCom
summary(lme(lnB ~ BD3SoilCom,
            random = ~1 |Replicate, 
            # control = lmerControl(optCtrl = list(maxfun = 2000)),
            data =  bac_datD31))
print(BD3SoilCom)

#_________________Energy___________________________
EnerBD3 <-lme(lnB ~ NPP+SOC+MAT+ST,random=~1 |Replicate, 
              # control = lmerControl(optCtrl = list(maxfun = 2000)),
              data=bac_datD31)
summary(EnerBD3)

betaBD3_NPP<-  summary(EnerBD3)$tTable["NPP", "Value"]
betaBD3_SOC<-  summary(EnerBD3)$tTable["SOC", "Value"]
betaBD3_MAT<-  summary(EnerBD3)$tTable["MAT", "Value"]
betaBD3_ST<-  summary(EnerBD3)$tTable["ST", "Value"]
BD3EnerCom <- betaBD3_NPP*bac_datD31$NPP+ betaBD3_SOC*bac_datD31$SOC+
  betaBD3_MAT*bac_datD31$MAT+ betaBD3_ST*bac_datD31$ST
bac_datD31$BD3EnerCom  <- BD3EnerCom
summary(lme(lnB ~ BD3EnerCom,
            random = ~1 |Replicate, 
            # control = lmerControl(optCtrl = list(maxfun = 2000)),
            data =  bac_datD31))
print(BD3EnerCom)
bac_datD31$SoilCom <- bac_datD31$BD3SoilCom
bac_datD31$EnerCom <- bac_datD31$BD3EnerCom

#_________________________BSD4______________________________
bac_datD4 = filter(bac_dat, Depth == "D4")
bac_datD41 <-bac_datD4 %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAT = scale(MAT),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP))
#_________________abiotic soil filter_______________________________
SoilBD4 <-lme(lnB ~  pH+EC+SWC,
              random= ~1 |Replicate, 
              # control = lmerControl(optCtrl = list(maxfun = 2000)),
              data=bac_datD41)
summary(SoilBD4 )

betaBD4_pH<-  summary(SoilBD4)$tTable["pH", "Value"]
betaBD4_EC<-  summary(SoilBD4)$tTable["EC", "Value"]
betaBD4_SWC<-  summary(SoilBD4)$tTable["SWC", "Value"]
BD4SoilCom <- betaBD4_pH*bac_datD41$pH+ betaBD4_EC*bac_datD41$EC+ 
  betaBD4_SWC*bac_datD41$SWC
bac_datD41$BD4SoilCom  <- BD4SoilCom
summary(lme(lnB ~ BD4SoilCom,
            random = ~1 |Replicate, 
            # control = lmerControl(optCtrl = list(maxfun = 2000)),
            data =  bac_datD41))
print(BD4SoilCom)

#_________________Energy___________________________
EnerBD4 <-lme(lnB ~ NPP+SOC+MAT+ST,random=~1 |Replicate, 
              # control = lmerControl(optCtrl = list(maxfun = 2000)),
              data=bac_datD41)
summary(EnerBD4)

betaBD4_NPP<-  summary(EnerBD4)$tTable["NPP", "Value"]
betaBD4_SOC<-  summary(EnerBD4)$tTable["SOC", "Value"]
betaBD4_MAT<-  summary(EnerBD4)$tTable["MAT", "Value"]
betaBD4_ST<-  summary(EnerBD4)$tTable["ST", "Value"]
BD4EnerCom <- betaBD4_NPP*bac_datD41$NPP+ betaBD4_SOC*bac_datD41$SOC+
  betaBD4_MAT*bac_datD41$MAT+ betaBD4_ST*bac_datD41$ST
bac_datD41$BD4EnerCom  <- BD4EnerCom
summary(lme(lnB ~ BD4EnerCom,
            random = ~1 |Replicate, 
            # control = lmerControl(optCtrl = list(maxfun = 2000)),
            data =  bac_datD41))
print(BD4EnerCom)
bac_datD41$SoilCom <- bac_datD41$BD4SoilCom
bac_datD41$EnerCom <- bac_datD41$BD4EnerCom


#Fungi
#_________________________FOver______________________________
fun_datover = filter(fun_dat, Depth == "Overall")
fun_datover1 <-fun_datover %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAT = scale(MAT),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP))
#_________________abiotic soil filter_______________________________
SoilFOv <-lme(lnB ~  pH+EC+SWC,
              random= ~1 |Elevation/Replicate, 
              # control = lmerControl(optCtrl = list(maxfun = 2000)),
              data=fun_datover1)
summary(SoilFOv )

betaFOv_pH<-  summary(SoilFOv)$tTable["pH", "Value"]
betaFOv_EC<-  summary(SoilFOv)$tTable["EC", "Value"]
betaFOv_SWC<-  summary(SoilFOv)$tTable["SWC", "Value"]
FOvSoilCom <- betaFOv_pH*fun_datover1$pH+ betaFOv_EC*fun_datover1$EC+ 
  betaFOv_SWC*fun_datover1$SWC
fun_datover1$FOvSoilCom  <- FOvSoilCom
summary(lme(lnB ~ FOvSoilCom,
            random = ~1 |Elevation/Replicate, 
            # control = lmerControl(optCtrl = list(maxfun = 2000)),
            data =  fun_datover1))
print(FOvSoilCom)

#_________________Energy___________________________
EnerFOv <-lme(lnB ~ NPP+SOC+MAT+ST,random=~1 |Elevation/Replicate, 
              # control = lmerControl(optCtrl = list(maxfun = 2000)),
              data=fun_datover1)
summary(EnerFOv)

betaFOv_NPP<-  summary(EnerFOv)$tTable["NPP", "Value"]
betaFOv_SOC<-  summary(EnerFOv)$tTable["SOC", "Value"]
betaFOv_MAT<-  summary(EnerFOv)$tTable["MAT", "Value"]
betaFOv_ST<-  summary(EnerFOv)$tTable["ST", "Value"]
FOvEnerCom <- betaFOv_NPP*fun_datover1$NPP+ betaFOv_SOC*fun_datover1$SOC+
  betaFOv_MAT*fun_datover1$MAT+ betaFOv_ST*fun_datover1$ST
fun_datover1$FOvEnerCom  <- FOvEnerCom
summary(lme(lnB ~ FOvEnerCom,
            random = ~1 |Elevation/Replicate, 
            # control = lmerControl(optCtrl = list(maxfun = 2000)),
            data =  fun_datover1))
print(FOvEnerCom)
fun_datover1$SoilCom <- fun_datover1$FOvSoilCom
fun_datover1$EnerCom <- fun_datover1$FOvEnerCom


#_________________________FSD1______________________________
fun_datD1 = filter(fun_dat, Depth == "D1")
fun_datD11 <-fun_datD1 %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAT = scale(MAT),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP))
#_________________abiotic soil filter_______________________________
SoilFD1 <-lme(lnB ~  pH+EC+SWC,
              random= ~1 |Replicate, 
              # control = lmerControl(optCtrl = list(maxfun = 2000)),
              data=fun_datD11)
summary(SoilFD1 )

betaFD1_pH<-  summary(SoilFD1)$tTable["pH", "Value"]
betaFD1_EC<-  summary(SoilFD1)$tTable["EC", "Value"]
betaFD1_SWC<-  summary(SoilFD1)$tTable["SWC", "Value"]
FD1SoilCom <- betaFD1_pH*fun_datD11$pH+ betaFD1_EC*fun_datD11$EC+ 
  betaFD1_SWC*fun_datD11$SWC
fun_datD11$FD1SoilCom  <- FD1SoilCom
summary(lme(lnB ~ FD1SoilCom,
            random = ~1 |Replicate, 
            # control = lmerControl(optCtrl = list(maxfun = 2000)),
            data =  fun_datD11))
print(FD1SoilCom)

#_________________Energy___________________________
EnerFD1 <-lme(lnB ~ NPP+SOC+MAT+ST,random=~1 |Replicate, 
              # control = lmerControl(optCtrl = list(maxfun = 2000)),
              data=fun_datD11)
summary(EnerFD1)

betaFD1_NPP<-  summary(EnerFD1)$tTable["NPP", "Value"]
betaFD1_SOC<-  summary(EnerFD1)$tTable["SOC", "Value"]
betaFD1_MAT<-  summary(EnerFD1)$tTable["MAT", "Value"]
betaFD1_ST<-  summary(EnerFD1)$tTable["ST", "Value"]
FD1EnerCom <- betaFD1_NPP*fun_datD11$NPP+ betaFD1_SOC*fun_datD11$SOC+
  betaFD1_MAT*fun_datD11$MAT+ betaFD1_ST*fun_datD11$ST
fun_datD11$FD1EnerCom  <- FD1EnerCom
summary(lme(lnB ~ FD1EnerCom,
            random = ~1 |Replicate, 
            # control = lmerControl(optCtrl = list(maxfun = 2000)),
            data =  fun_datD11))
print(FD1EnerCom)
fun_datD11$SoilCom <- fun_datD11$FD1SoilCom
fun_datD11$EnerCom <- fun_datD11$FD1EnerCom

#_________________________FSD2______________________________
fun_datD2 = filter(fun_dat, Depth == "D2")
fun_datD21 <-fun_datD2 %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAT = scale(MAT),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP))
#_________________abiotic soil filter_______________________________
SoilFD2 <-lme(lnB ~  pH+EC+SWC,
              random= ~1 |Replicate, 
              # control = lmerControl(optCtrl = list(maxfun = 2000)),
              data=fun_datD21)
summary(SoilFD2 )

betaFD2_pH<-  summary(SoilFD2)$tTable["pH", "Value"]
betaFD2_EC<-  summary(SoilFD2)$tTable["EC", "Value"]
betaFD2_SWC<-  summary(SoilFD2)$tTable["SWC", "Value"]
FD2SoilCom <- betaFD2_pH*fun_datD21$pH+ betaFD2_EC*fun_datD21$EC+ 
  betaFD2_SWC*fun_datD21$SWC
fun_datD21$FD2SoilCom  <- FD2SoilCom
summary(lme(lnB ~ FD2SoilCom,
            random = ~1 |Replicate, 
            # control = lmerControl(optCtrl = list(maxfun = 2000)),
            data =  fun_datD21))
print(FD2SoilCom)
fun_datD21$SoilCom <- fun_datD21$FD2SoilCom
fun_datD21$EnerCom <- fun_datD21$FD2EnerCom

#_________________Energy___________________________
EnerFD2 <-lme(lnB ~ NPP+SOC+MAT+ST,random=~1 |Replicate, 
              # control = lmerControl(optCtrl = list(maxfun = 2000)),
              data=fun_datD21)
summary(EnerFD2)

betaFD2_NPP<-  summary(EnerFD2)$tTable["NPP", "Value"]
betaFD2_SOC<-  summary(EnerFD2)$tTable["SOC", "Value"]
betaFD2_MAT<-  summary(EnerFD2)$tTable["MAT", "Value"]
betaFD2_ST<-  summary(EnerFD2)$tTable["ST", "Value"]
FD2EnerCom <- betaFD2_NPP*fun_datD21$NPP+ betaFD2_SOC*fun_datD21$SOC+
  betaFD2_MAT*fun_datD21$MAT+ betaFD2_ST*fun_datD21$ST
fun_datD21$FD2EnerCom  <- FD2EnerCom
summary(lme(lnB ~ FD2EnerCom,
            random = ~1 |Replicate, 
            # control = lmerControl(optCtrl = list(maxfun = 2000)),
            data =  fun_datD21))
print(FD2EnerCom)

#_________________________FSD3______________________________
fun_datD3 = filter(fun_dat, Depth == "D3")
fun_datD31 <-fun_datD3 %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAT = scale(MAT),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP))
#_________________abiotic soil filter_______________________________
SoilFD3 <-lme(lnB ~  pH+EC+SWC,
              random= ~1 |Replicate, 
              # control = lmerControl(optCtrl = list(maxfun = 2000)),
              data=fun_datD31)
summary(SoilFD3 )

betaFD3_pH<-  summary(SoilFD3)$tTable["pH", "Value"]
betaFD3_EC<-  summary(SoilFD3)$tTable["EC", "Value"]
betaFD3_SWC<-  summary(SoilFD3)$tTable["SWC", "Value"]
FD3SoilCom <- betaFD3_pH*fun_datD31$pH+ betaFD3_EC*fun_datD31$EC+ 
  betaFD3_SWC*fun_datD31$SWC
fun_datD31$FD3SoilCom  <- FD3SoilCom
summary(lme(lnB ~ FD3SoilCom,
            random = ~1 |Replicate, 
            # control = lmerControl(optCtrl = list(maxfun = 2000)),
            data =  fun_datD31))
print(FD3SoilCom)

#_________________Energy___________________________
EnerFD3 <-lme(lnB ~ NPP+SOC+MAT+ST,random=~1 |Replicate, 
              # control = lmerControl(optCtrl = list(maxfun = 2000)),
              data=fun_datD31)
summary(EnerFD3)

betaFD3_NPP<-  summary(EnerFD3)$tTable["NPP", "Value"]
betaFD3_SOC<-  summary(EnerFD3)$tTable["SOC", "Value"]
betaFD3_MAT<-  summary(EnerFD3)$tTable["MAT", "Value"]
betaFD3_ST<-  summary(EnerFD3)$tTable["ST", "Value"]
FD3EnerCom <- betaFD3_NPP*fun_datD31$NPP+ betaFD3_SOC*fun_datD31$SOC+
  betaFD3_MAT*fun_datD31$MAT+ betaFD3_ST*fun_datD31$ST
fun_datD31$FD3EnerCom  <- FD3EnerCom
summary(lme(lnB ~ FD3EnerCom,
            random = ~1 |Replicate, 
            # control = lmerControl(optCtrl = list(maxfun = 2000)),
            data =  fun_datD31))
print(FD3EnerCom)
fun_datD31$SoilCom <- fun_datD31$FD3SoilCom
fun_datD31$EnerCom <- fun_datD31$FD3EnerCom

#_________________________FSD4______________________________
fun_datD4 = filter(fun_dat, Depth == "D4")
fun_datD41 <-fun_datD4 %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = factor(Elevation),
         NPP = scale(NPP),
         MAT = scale(MAT),
         pH = scale(pH),
         EC = scale(EC),
         SWC = scale(SWC),
         SOC = scale(SOC),
         ST = scale(ST),
         lnP = scale(lnP))
#_________________abiotic soil filter_______________________________
SoilFD4 <-lme(lnB ~  pH+EC+SWC,
              random= ~1 |Replicate, 
              # control = lmerControl(optCtrl = list(maxfun = 2000)),
              data=fun_datD41)
summary(SoilFD4 )

betaFD4_pH<-  summary(SoilFD4)$tTable["pH", "Value"]
betaFD4_EC<-  summary(SoilFD4)$tTable["EC", "Value"]
betaFD4_SWC<-  summary(SoilFD4)$tTable["SWC", "Value"]
FD4SoilCom <- betaFD4_pH*fun_datD41$pH+ betaFD4_EC*fun_datD41$EC+ 
  betaFD4_SWC*fun_datD41$SWC
fun_datD41$FD4SoilCom  <- FD4SoilCom
summary(lme(lnB ~ FD4SoilCom,
            random = ~1 |Replicate, 
            # control = lmerControl(optCtrl = list(maxfun = 2000)),
            data =  fun_datD41))
print(FD4SoilCom)

#_________________Energy___________________________
EnerFD4 <-lme(lnB ~ NPP+SOC+MAT+ST,random=~1 |Replicate, 
              # control = lmerControl(optCtrl = list(maxfun = 2000)),
              data=fun_datD41)
summary(EnerFD4)

betaFD4_NPP<-  summary(EnerFD4)$tTable["NPP", "Value"]
betaFD4_SOC<-  summary(EnerFD4)$tTable["SOC", "Value"]
betaFD4_MAT<-  summary(EnerFD4)$tTable["MAT", "Value"]
betaFD4_ST<-  summary(EnerFD4)$tTable["ST", "Value"]
FD4EnerCom <- betaFD4_NPP*fun_datD41$NPP+ betaFD4_SOC*fun_datD41$SOC+
  betaFD4_MAT*fun_datD41$MAT+ betaFD4_ST*fun_datD41$ST
fun_datD41$FD4EnerCom  <- FD4EnerCom
summary(lme(lnB ~ FD4EnerCom,
            random = ~1 |Replicate, 
            # control = lmerControl(optCtrl = list(maxfun = 2000)),
            data =  fun_datD41))
print(FD4EnerCom)
fun_datD41$SoilCom <- fun_datD41$FD4SoilCom
fun_datD41$EnerCom <- fun_datD41$FD4EnerCom

####################################################################
#bootstrap 
#_________________________bacOver______________________________
#data Preparation
SEM_dat <- read.table("clipboard",header=T)
bac_dat = filter(SEM_dat, Micro == "Bacteria")
fun_dat = filter(SEM_dat, Micro == "Fungi")

bacOver_dat = filter(bac_dat, Depth == "Overall")
bacOver_dat1 <- bacOver_dat %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = as.vector(scale(Elevation)),
         MAT = as.vector(scale(MAT)),
         SoilCom = as.vector(SoilCom),
         EnerCom = as.vector(EnerCom),
         lnP = as.vector(scale(lnP)),
         lnB = as.vector(scale(lnB)))

bacOver_psem <- psem(
  lme(lnB ~Elevation+SoilCom+EnerCom+lnP,random = ~1|Replicate, 
      data = bacOver_dat1),
  lme(lnP~Elevation+SoilCom+EnerCom, random = ~1|Replicate, 
      data = bacOver_dat1),
  lme(EnerCom~Elevation,random = ~1|Replicate, 
      data = bacOver_dat1),
  lme(SoilCom~Elevation,random = ~1|Replicate, 
      data = bacOver_dat1))


fixed_BO <- fixef(bacOver_psem[[1]])
summary(bacOver_psem, standardized = T, rsq = T)

boot_BO <- function(data, indices) {
 
  data_boot_BO <- data[indices, ]
 
  model_boot_BO <- update(bacOver_psem, data = data_boot_BO)
 
  fixed_BO <- fixef(model_boot_BO[[1]])
  return(fixed_BO)
}
nboots <- 1000
set.seed(123) # 
boot_SEM_BO <- boot(data = bacOver_dat1, statistic = boot_BO, R = nboots)# 

boot_SEM_BO <- boot_SEM_BO$t# 
SEM_BO <- as.data.frame(boot_SEM_BO)# 

write.csv(SEM_BO, 
          file = "./semboot/semboot__bacOver.csv", 
          row.names = TRUE)
#_________________________bacD1___________________________________
bacD1_dat <- filter(bac_dat , Depth == "D1")

bacD1_dat1 <- bacD1_dat %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = as.vector(scale(Elevation)),
         MAT = as.vector(scale(MAT)),
         SoilCom = as.vector(SoilCom),
         EnerCom = as.vector(EnerCom),
         lnP = as.vector(scale(lnP)),
         lnB = as.vector(scale(lnB)))

bacD1_psem <- psem(
  lme(lnB ~Elevation+SoilCom+EnerCom+lnP,random = ~1|Replicate, 
      data = bacD1_dat1),
  lme(lnP~Elevation+SoilCom+EnerCom, random = ~1|Replicate, 
      data = bacD1_dat1),
  lme(EnerCom~Elevation,random = ~1|Replicate, 
      data = bacD1_dat1),
  lme(SoilCom~Elevation,random = ~1|Replicate, 
      data = bacD1_dat1))
summary(bacD1_psem, standardized = T, rsq = T)

boot_BD1 <- function(data, indices) {
  data_boot_BD1 <- data[indices, ]
  model_boot_BD1 <- update(bacD1_psem, data = data_boot_BD1)
  fixed_BD1 <- fixef(model_boot_BD1[[1]])
  return(fixed_BD1)
}
nboots <- 1000
set.seed(123) # 
boot_SEM_BD1 <- boot(data = bacD1_dat1, statistic = boot_BD1, R = nboots)# 
boot_SEM_BD1 <- boot_SEM_BD1$t# 
SEM_BD1 <- as.data.frame(boot_SEM_BD1)# 

write.csv(SEM_BD1, 
          file = "./semboot/semboot__bacD1.csv", 
          row.names = TRUE)

#_________________________bacD2___________________________________
bacD2_dat <- filter(bac_dat , Depth == "D2")
bacD2_dat1 <- bacD2_dat %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = as.vector(scale(Elevation)),
         MAT = as.vector(scale(MAT)),
         SoilCom = as.vector(SoilCom),
         EnerCom = as.vector(EnerCom),
         lnP = as.vector(scale(lnP)),
         lnB = as.vector(scale(lnB)))

bacD2_psem <- psem(
  lme(lnB ~Elevation+SoilCom+EnerCom+lnP,random = ~1|Replicate, 
      data = bacD2_dat1),
  lme(lnP~Elevation+SoilCom+EnerCom, random = ~1|Replicate, 
      data = bacD2_dat1),
  lme(EnerCom~Elevation,random = ~1|Replicate, 
      data = bacD2_dat1),
  lme(SoilCom~Elevation,random = ~1|Replicate, 
      data = bacD2_dat1))
summary(bacD2_psem, standardized = T, rsq = T)

boot_BD2 <- function(data, indices) {
 
  data_boot_BD2 <- data[indices, ]
 
  model_boot_BD2 <- update(bacD2_psem, data = data_boot_BD2)
 
  fixed_BD2 <- fixef(model_boot_BD2[[1]])
  return(fixed_BD2)
}
nboots <- 1000
set.seed(123) # 
boot_SEM_BD2 <- boot(data = bacD2_dat1, statistic = boot_BD2, R = nboots)# 

boot_SEM_BD2 <- boot_SEM_BD2$t# 
SEM_BD2 <- as.data.frame(boot_SEM_BD2)# 

write.csv(SEM_BD2, 
          file = "./semboot/semboot__bacD2.csv", 
          row.names = TRUE)

#_________________________bacD3___________________________________
bacD3_dat <- filter(bac_dat , Depth == "D3")

bacD3_dat1 <- bacD3_dat %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = as.vector(scale(Elevation)),
         MAT = as.vector(scale(MAT)),
         SoilCom = as.vector(SoilCom),
         EnerCom = as.vector(EnerCom),
         lnP = as.vector(scale(lnP)),
         lnB = as.vector(scale(lnB)))

bacD3_psem <- psem(
  lme(lnB ~Elevation+SoilCom+EnerCom+lnP,random = ~1|Replicate, 
      data = bacD3_dat1),
  lme(lnP~Elevation+SoilCom+EnerCom, random = ~1|Replicate, 
      data = bacD3_dat1),
  lme(EnerCom~Elevation,random = ~1|Replicate, 
      data = bacD3_dat1),
  lme(SoilCom~Elevation,random = ~1|Replicate, 
      data = bacD3_dat1))
summary(bacD3_psem, standardized = T, rsq = T)

boot_BD3 <- function(data, indices) {
 
  data_boot_BD3 <- data[indices, ]
 
  model_boot_BD3 <- update(bacD3_psem, data = data_boot_BD3)
 
  fixed_BD3 <- fixef(model_boot_BD3[[1]])
  return(fixed_BD3)
}
nboots <- 1000
set.seed(123) # 
boot_SEM_BD3 <- boot(data = bacD3_dat1, statistic = boot_BD3, R = nboots)# 

boot_SEM_BD3 <- boot_SEM_BD3$t# 
SEM_BD3 <- as.data.frame(boot_SEM_BD3)# 

write.csv(SEM_BD3, 
          file = "./semboot/semboot__bacD3.csv", 
          row.names = TRUE)
#_________________________bacD4___________________________________
bacD4_dat <- filter(bac_dat , Depth == "D4")

bacD4_dat1 <- bacD4_dat %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = as.vector(scale(Elevation)),
         MAT = as.vector(scale(MAT)),
         SoilCom = as.vector(SoilCom),
         EnerCom = as.vector(EnerCom),
         lnP = as.vector(scale(lnP)),
         lnB = as.vector(scale(lnB)))

bacD4_psem <- psem(
  lme(lnB ~Elevation+SoilCom+EnerCom+lnP,random = ~1|Replicate, 
      data = bacD4_dat1),
  lme(lnP~Elevation+SoilCom+EnerCom, random = ~1|Replicate, 
      data = bacD4_dat1),
  lme(EnerCom~Elevation,random = ~1|Replicate, 
      data = bacD4_dat1),
  lme(SoilCom~Elevation,random = ~1|Replicate, 
      data = bacD4_dat1))
summary(bacD4_psem, standardized = T, rsq = T)


boot_BD4 <- function(data, indices) {
 
  data_boot_BD4 <- data[indices, ]
 
  model_boot_BD4 <- update(bacD4_psem, data = data_boot_BD4)
 
  fixed_BD4 <- fixef(model_boot_BD4[[1]])
  return(fixed_BD4)
}
nboots <- 1000
set.seed(123) # 
boot_SEM_BD4 <- boot(data = bacD4_dat1, statistic = boot_BD4, R = nboots)# 

boot_SEM_BD4 <- boot_SEM_BD4$t# 
SEM_BD4 <- as.data.frame(boot_SEM_BD4)# 

write.csv(SEM_BD4, 
          file = "./semboot/semboot__bacD4.csv", 
          row.names = TRUE)

#__________________funOver_____________________________________
funOver_dat <- filter(fun_dat , Depth == "Overall")
##
funOver_dat1 <- funOver_dat %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = as.vector(scale(Elevation)),
         MAT = as.vector(scale(MAT)),
         SoilCom = as.vector(SoilCom),
         EnerCom = as.vector(EnerCom),
         lnP = as.vector(scale(lnP)),
         lnB = as.vector(scale(lnB)))

funOver_psem <- psem(
  lme(lnB ~Elevation+SoilCom+EnerCom+lnP,random = ~1|Replicate, 
      data = funOver_dat1),
  lme(lnP~Elevation+SoilCom+EnerCom, random = ~1|Replicate, 
      data = funOver_dat1),
  lme(EnerCom~Elevation,random = ~1|Replicate, 
      data = funOver_dat1),
  lme(SoilCom~Elevation,random = ~1|Replicate, 
      data = funOver_dat1))

summary(funOver_psem, standardized = T, rsq = T)

boot_FO <- function(data, indices) {
 
  data_boot_FO <- data[indices, ]
 
  model_boot_FO <- update(funOver_psem, data = data_boot_FO)
 
  fixed_FO <- fixef(model_boot_FO[[1]])
  return(fixed_FO)
}
nboots <- 1000
set.seed(123) # 
boot_SEM_FO <- boot(data = funOver_dat1, statistic = boot_FO, R = nboots)# 

boot_SEM_FO <- boot_SEM_FO$t# 
SEM_FO <- as.data.frame(boot_SEM_FO)# 

write.csv(SEM_FO, 
          file = "./semboot/semboot__funOver.csv", 
          row.names = TRUE)




summary(funOver_psem, standardized = T, rsq = T)


#_________________________funD1___________________________________
funD1_dat <- filter(fun_dat , Depth == "D1")
##
funD1_dat1 <- funD1_dat %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = as.vector(scale(Elevation)),
         MAT = as.vector(scale(MAT)),
         SoilCom = as.vector(SoilCom),
         EnerCom = as.vector(EnerCom),
         lnP = as.vector(scale(lnP)),
         lnB = as.vector(scale(lnB)))

funD1_psem <- psem(
  lme(lnB ~Elevation+SoilCom+EnerCom+lnP,random = ~1|Replicate, 
      data = funD1_dat1),
  lme(lnP~Elevation+SoilCom+EnerCom, random = ~1|Replicate, 
      data = funD1_dat1),
  lme(EnerCom~Elevation,random = ~1|Replicate, 
      data = funD1_dat1),
  lme(SoilCom~Elevation,random = ~1|Replicate, 
      data = funD1_dat1))

summary(funD1_psem, standardized = T, rsq = T)

fixed_FD1 <- fixef(funD1_psem[[1]])


boot_FD1 <- function(data, indices) {
 
  data_boot_FD1 <- data[indices, ]
 
  model_boot_FD1 <- update(funD1_psem, data = data_boot_FD1)
 
  fixed_FD1 <- fixef(model_boot_FD1[[1]])
  return(fixed_FD1)
}
nboots <- 1000
set.seed(123) # 
boot_SEM_FD1 <- boot(data = funD1_dat1, statistic = boot_FD1, R = nboots)# 

boot_SEM_FD1 <- boot_SEM_FD1$t# 
SEM_FD1 <- as.data.frame(boot_SEM_FD1)# 

write.csv(SEM_FD1, 
          file = "./semboot/semboot__funD1.csv", 
          row.names = TRUE)
#_________________________funD2___________________________________
funD2_dat <- filter(fun_dat , Depth == "D2")
##
funD2_dat1 <- funD2_dat %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = as.vector(scale(Elevation)),
         MAT = as.vector(scale(MAT)),
         SoilCom = as.vector(SoilCom),
         EnerCom = as.vector(EnerCom),
         lnP = as.vector(scale(lnP)),
         lnB = as.vector(scale(lnB)))

funD2_psem <- psem(
  lme(lnB ~Elevation+SoilCom+EnerCom+lnP,random = ~1|Replicate, 
      data = funD2_dat1),
  lme(lnP~Elevation+SoilCom+EnerCom, random = ~1|Replicate, 
      data = funD2_dat1),
  lme(EnerCom~Elevation,random = ~1|Replicate, 
      data = funD2_dat1),
  lme(SoilCom~Elevation,random = ~1|Replicate, 
      data = funD2_dat1))

summary(funD2_psem, standardized = T, rsq = T)

boot_FD2 <- function(data, indices) {
 
  data_boot_FD2 <- data[indices, ]
 
  model_boot_FD2 <- update(funD2_psem, data = data_boot_FD2)
 
  fixed_FD2 <- fixef(model_boot_FD2[[1]])
  return(fixed_FD2)
}
nboots <- 1000
set.seed(123) # 
boot_SEM_FD2 <- boot(data = funD2_dat1, statistic = boot_FD2, R = nboots)# 

boot_SEM_FD2 <- boot_SEM_FD2$t# 
SEM_FD2 <- as.data.frame(boot_SEM_FD2)# 

write.csv(SEM_FD2, 
          file = "./semboot/semboot__funD2.csv", 
          row.names = TRUE)
#_________________________funD3___________________________________
funD3_dat <- filter(fun_dat , Depth == "D3")

funD3_dat1 <- funD3_dat %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = as.vector(scale(Elevation)),
         MAT = as.vector(scale(MAT)),
         SoilCom = as.vector(SoilCom),
         EnerCom = as.vector(EnerCom),
         lnP = as.vector(scale(lnP)),
         lnB = as.vector(scale(lnB)))

funD3_psem <- psem(
  lme(lnB ~Elevation+SoilCom+EnerCom+lnP,random = ~1|Replicate, 
      data = funD3_dat1),
  lme(lnP~Elevation+SoilCom+EnerCom, random = ~1|Replicate, 
      data = funD3_dat1),
  lme(EnerCom~Elevation,random = ~1|Replicate, 
      data = funD3_dat1),
  lme(SoilCom~Elevation,random = ~1|Replicate, 
      data = funD3_dat1))
summary(funD3_psem, standardized = T, rsq = T)



boot_FD3 <- function(data, indices) {
 
  data_boot_FD3 <- data[indices, ]
 
  model_boot_FD3 <- update(funD3_psem, data = data_boot_FD3)
 
  fixed_FD3 <- fixef(model_boot_FD3[[1]])
  return(fixed_FD3)
}
nboots <- 1000
set.seed(123) # 
boot_SEM_FD3 <- boot(data = funD3_dat1, statistic = boot_FD3, R = nboots)# 

boot_SEM_FD3 <- boot_SEM_FD3$t# 
SEM_FD3 <- as.data.frame(boot_SEM_FD3)# 

write.csv(SEM_FD3, 
          file = "./semboot/semboot__funD3.csv", 
          row.names = TRUE)
#_________________________funD4___________________________________
funD4_dat <- filter(fun_dat , Depth == "D4")
funD4_dat1 <- funD4_dat %>% 
  mutate(Replicate = factor(Replicate),
         Elevation = as.vector(scale(Elevation)),
         MAT = as.vector(scale(MAT)),
         SoilCom = as.vector(SoilCom),
         EnerCom = as.vector(EnerCom),
         lnP = as.vector(scale(lnP)),
         lnB = as.vector(scale(lnB)))

funD4_psem <- psem(
  lme(lnB ~Elevation+SoilCom+EnerCom+lnP,random = ~1|Replicate, 
      data = funD4_dat1),
  lme(lnP~Elevation+SoilCom+EnerCom, random = ~1|Replicate, 
      data = funD4_dat1),
  lme(EnerCom~Elevation,random = ~1|Replicate, 
      data = funD4_dat1),
  lme(SoilCom~Elevation,random = ~1|Replicate, 
      data = funD4_dat1))
summary(funD4_psem, standardized = T, rsq = T)


boot_FD4 <- function(data, indices) {
  data_boot_FD4 <- data[indices, ]
  model_boot_FD4 <- update(funD4_psem, data = data_boot_FD4)
  fixed_FD4 <- fixef(model_boot_FD4[[1]])
  return(fixed_FD4)
}
nboots <- 1000# 
set.seed(123) # 
boot_SEM_FD4 <- boot(data = funD4_dat1, statistic = boot_FD4, R = nboots)# 

boot_SEM_FD4 <- boot_SEM_FD4$t# 
SEM_FD4 <- as.data.frame(boot_SEM_FD4)# 

write.csv(SEM_FD4, 
          file = "./semboot/semboot__funD4.csv", 
          row.names = TRUE)


############################################################
#Fig. 4 to plot the depth-dependent variations in sem pathway
# load data
Path_dat <- read.table("clipboard",header=T)#load result data

#calculate mean value and data distribution
Path_plotdata <- Path_dat %>%
  group_by(Depth, Micro) %>%
  summarize(
    n = n(),
    
    y0 = min(Path),
    Mean = mean(Path),
    y100 = max(Path),
    sd = sd(Path),
    se = sd / sqrt(n),
    
    p66_lower = quantile(Path, 0.17),  # (1 - 0.66) / 2 = 0.17
    p66_upper = quantile(Path, 0.83),  # 1 - 0.17 = 0.83
    p95_lower = quantile(Path, 0.025), # (1 - 0.95) / 2 = 0.025
    p95_upper = quantile(Path, 0.975), # 1 - 0.025 = 0.975
  )
write.csv(Path_plotdata, "./Path_plotdata.csv", row.names = FALSE)


#plot
Path_plot <- read.table("clipboard",header=T)#load plot data
Path_bac <- ggplot(Path_plot %>% filter(Micro == "Bacteria") %>%
                     mutate(Depth = factor(Depth,
                                           levels = c("D1", "D2", "D3", "D4"),
                                           labels = c("0-5", "5-15", "15-30", "30-50"))) %>%
                     mutate(Theory = factor(Theory,
                                            levels = c("Energy", "Plant", "Soil"),
                                            labels = c("Energy", "Plant SR", "Soil"))),
                   aes(SDepth1, Mean, group = Theory)) +
  
  geom_vline(xintercept = 3, linetype = "dashed", color = "gray", size = 0.2) +
  geom_vline(xintercept = 7, linetype = "dashed", color = "gray", size = 0.2) +
  geom_vline(xintercept = 11, linetype = "dashed", color = "gray", size = 0.2) +
  
  geom_hline(yintercept = 0, linetype = "dashed", color = "gray", size = 0.5) +

  geom_line(aes(color = "gray"), size = 0.5) +
  #geom_errorbar(data = . %>% filter(conf_level == "0.95"),
                #aes(ymin = ci_lower, ymax = ci_upper), 
                #color = "gray30",
                #width = 0.2) +
  geom_linerange(data = . %>% filter(conf_level == "0.66"), 
                 aes(ymin = ci_lower, ymax = ci_upper),
                 color = "black", 
                 size = 1.3) +
  
  geom_linerange(data = . %>% filter(conf_level == "0.95"), 
                 aes(ymin = ci_lower, ymax = ci_upper), 
                 color = "gray30",
                 size = 0.3) +
  geom_point(aes(color = Theory, shape = Depth, fill = Theory), 
             size = 2, alpha = 0.8, stroke = 1.2) +
  
  scale_color_manual(values = c("Energy" = "#C73E6B", 
                                "Plant SR" = "#23A883", 
                                "Soil" = "#7f2704"),
                     name = "Theory") +
  
  scale_fill_manual(values = c("Energy" = "#C73E6B", 
                               "Plant SR" = "#23A883", 
                               "Soil" = "#7f2704"),
                    name = "Theory") +
  
  scale_shape_manual(values = c(21, 21, 21, 21), # 建议用不同形状以更好区分
                     name = "Depth (cm)") +
  
  scale_y_continuous(limits = c(-1.2, 0.91), breaks = c(-0.8, 0.0, 0.8)) +
  scale_x_continuous(limits = c(0, 14), breaks = c(3, 7, 11)) +
  labs(x = "",
       y = "Standardized path coefficient ",
       title = "Bacteria") +
  theme_bw(base_size = 11.5) +
  theme(panel.grid = element_blank(),
        legend.position = "none", 
        legend.key.size = unit(5, "mm")) +
  theme(strip.background = element_rect(colour = NA, fill = NA),
        axis.line = element_line(arrow = arrow(length = unit(0.2, "cm")),
                                 linewidth = 0.25),
        axis.text.x = element_text(angle = 45, size = 9, hjust = 0.5),
        plot.title = element_text(size = 12, hjust = 0.5))
Path_bac

#___________________________fungi_________________________________________
Path_fun <- ggplot(Path_plot %>% filter(Micro == "Fungi") %>%
                     mutate(Depth = factor(Depth,
                                           levels = c("D1", "D2", "D3", "D4"),
                                           labels = c("0-5", "5-15", "15-30", "30-50"))) %>%
                     mutate(Theory = factor(Theory,
                                            levels = c("Energy", "Plant", "Soil"),
                                            labels = c("Energy", "Plant SR", "Soil"))),
                   aes(SDepth1, Mean, group = Theory)) +
  
  geom_vline(xintercept = 3, linetype = "dashed", color = "gray", size = 0.2) +
  geom_vline(xintercept = 7, linetype = "dashed", color = "gray", size = 0.2) +
  geom_vline(xintercept = 11, linetype = "dashed", color = "gray", size = 0.2) +
  
  geom_hline(yintercept = 0, linetype = "dashed", color = "gray", size = 0.5) +
  
  geom_line(aes(color = "gray"), size = 0.5) +
  #geom_errorbar(data = . %>% filter(conf_level == "0.95"),
  #aes(ymin = ci_lower, ymax = ci_upper), 
  #color = "gray30",
  #width = 0.2) +
  geom_linerange(data = . %>% filter(conf_level == "0.66"), 
                 aes(ymin = ci_lower, ymax = ci_upper),
                 color = "black", 
                 size = 1.3) + 
  
  geom_linerange(data = . %>% filter(conf_level == "0.95"), 
                 aes(ymin = ci_lower, ymax = ci_upper), 
                 color = "gray30",
                 size = 0.3) + 
  geom_point(aes(color = Theory, shape = Depth, fill = Theory), 
             size = 2, alpha = 0.8, stroke = 1.2) +
  
  scale_color_manual(values = c("Energy" = "#C73E6B", 
                                "Plant SR" = "#23A883", 
                                "Soil" = "#7f2704"),
                     name = "Theory") +
  
  scale_fill_manual(values = c("Energy" = "#C73E6B", 
                               "Plant SR" = "#23A883", 
                               "Soil" = "#7f2704"),
                    name = "Theory") +
  
  scale_shape_manual(values = c(21, 21, 21, 21), # 建议用不同形状以更好区分
                     name = "Depth (cm)") +
  
  scale_y_continuous(limits = c(-0.9, 0.91), breaks = c(-0.8, 0.0, 0.8)) +
  scale_x_continuous(limits = c(0, 14), breaks = c(3, 7, 11)) +
  labs(x = "Soil depth (cm)",
       y = "Standardized path coefficient ",
       title = "Fungi") +
  theme_bw(base_size = 11.5) +
  theme(panel.grid = element_blank(),
        legend.position = "none", 
        legend.key.size = unit(5, "mm")) +
  theme(strip.background = element_rect(colour = NA, fill = NA),
        axis.line = element_line(arrow = arrow(length = unit(0.2, "cm")),
                                 linewidth = 0.25),
        axis.text.x = element_text(angle = 45, size = 9, hjust = 0.5),
        plot.title = element_text(size = 12, hjust = 0.5))
Path_fun

plot_grid(Path_bac, Path_fun,
          labels = c("b)", "d)"),
          label_x = 0,
          label_y = 1,
          nrow = 2,    # 指定行数
          align = "hv")

ggsave("./Fig.4_SEM pathway_百分位.pdf",
       width = 80, height = 175, units = "mm")


###########################################################
#                    End of Script                        #
###########################################################